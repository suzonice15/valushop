<div class="form-group">
<!--	<label for="" class="col-sm-4 control-label">Class and Section Name</label>-->

	<div class="col-sm-6">
		<input name="classreg_section_name" value="<?php if( isset($ClassRelation) ) echo $ClassRelation[0]->classreg_section_name; ?>" type="hidden" id="class_section" placeholder="Text" class="form-control"/>
	</div>
</div>


<div class="form-group">
	<label for="" class="col-sm-4 control-label">Class Name</label>

	<div class="col-sm-6">

		<select required name="classreg_id" id="class_id" class="form-control select2">
			<option value="0"> Select class name </option>

			<option
			<?php if (isset($class)):
				foreach ($class as $class_row):
					?>
					<option <?php
					if (isset($ClassRelation)) {
						if ($ClassRelation[0]->classreg_id == $class_row->classreg_id) {
							echo 'selected';
						} else {
							echo '';
						}
					}
					?> value="<?php echo $class_row->classreg_id; ?>" > <?php echo $class_row->classreg_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="0">Registration first class name</option>
			<?php endif; ?>
		</select>
		<input type="hidden" name="classreg_section_id"
			   value="<?php if (isset($ClassRelation)) echo $ClassRelation[0]->classreg_section_id; ?>">

	</div>
</div>

<div class="form-group">
	<label for="" class="col-sm-4 control-label">Section Name</label>

	<div class="col-sm-6">
		<select required name="section_id" id="section_id" class="form-control select2">
			<option value="0">Select section name</option>
			<option
			<?php if (isset($section)):
				foreach ($section as $section_row):
					?>
					<option  <?php
					if (isset($ClassRelation)) {
						if ($ClassRelation[0]->section_id == $section_row->section_id) {
							echo 'selected';
						} else {
							echo '';
						}
					}

					?> value="<?php echo $section_row->section_id; ?>" > <?php echo $section_row->section_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first section name</option>
			<?php endif; ?>
		</select>
	</div>
</div>
<script>


	$("#class_id,#section_id").change(function () {
		var class_id = $("#class_id option:selected ").text();
		var section_id = $("#section_id option:selected ").text();
		var combinationClassSection = class_id + '-' + section_id;
		$("#class_section").val(combinationClassSection);
	});


</script>
