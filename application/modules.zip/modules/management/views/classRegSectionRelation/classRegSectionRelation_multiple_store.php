<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>class-section-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="className" class="col-sm-3 control-label">Class Name</label>

					<div class="col-sm-8">
						<h4><label id="className" class="label label-success">
							<?php

							echo $classSectionRelations[0]->classreg_name;

							?></label></h4>

						<input type="hidden" name="classreg_id" value="<?php echo $classSectionRelations[0]->classreg_id; ?>">

					</div>
				</div>
				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Section Name</th>

					</tr>
					</thead>
					<tbody>
					<?php foreach ($sections

					as $section ) { ?>
					<tr>

						<td><input <?php
							foreach ($classSectionRelations  as $classSectionRelation) {
								if ($classSectionRelation->section_id == $section->section_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="section_id<?php echo $section->section_id; ?>"
							   name="section_id[]" value="<?php echo $section->section_id; ?>"
							/></td>
						<td><label
								for="section_id<?php echo $section->section_id; ?>"><?php echo $section->section_name; ?></label>
						<input type="text" name="classreg_section_name[]"
									value="<?php
									foreach ($classSectionRelations  as $classSection) {
										if ($classSection->section_id == $section->section_id) {
											echo $classSection->classreg_section_name;
										} else {
											//  echo $classSectionRelations['teacher_shift_name'];
										}
									}

									?>

"
									id="classreg_section_name<?php echo $section->section_id; ?>">
						</td>
					</tr>
						<?php

					} ?>
					<tr>


						<td><a  class="btn btn-info  " href="<?php echo base_url(); ?>class-list">Back</a></td>

						<td><input type="submit" class="btn btn-success pull-right" value="Save"/></td>


					</tr>
					</tbody>
				</table>
<!--				<div class="form-group">-->
<!--					<label class="col-sm-3 control-label">Session Name</label>-->

<!--					<div class="col-md-9">-->
<!---->
<!--						--><?php //foreach ($sections
//
//						as $section ) { ?>
<!--						<div class="checkbox">-->
<!--							<input --><?php
//							foreach ($classSectionRelations  as $classSectionRelation) {
//								if ($classSectionRelation->section_id == $section->section_id) {
//									echo 'checked';
//								} else {
//									echo '';
//								}
//							}
//
//							?><!-- type="checkbox" class="check"-->
<!--							   id="section_id--><?php //echo $section->section_id; ?><!--"-->
<!--							   name="section_id[]" value="--><?php //echo $section->section_id; ?><!--"-->
<!--							/>-->
<!--							<label-->
<!--								for="section_id--><?php //echo $section->section_id; ?><!--">--><?php //echo $section->section_name; ?><!--</label>-->
<!--							<input type="hidden" name="classreg_section_name[]"-->
<!--								   value="--><?php
//								   foreach ($classSectionRelations  as $classSection) {
//									   if ($classSection->section_id == $section->section_id) {
//										   echo $classSection->classreg_section_name;
//									   } else {
//										   //  echo $classSectionRelations['teacher_shift_name'];
//									   }
//								   }
//
//								   ?>
<!---->
<!--"-->
<!--								   id="classreg_section_name--><?php //echo $section->section_id; ?><!--">-->
<!---->
<!---->
<!--							<br>-->
<!---->
<!--							--><?php
//
//							} ?>
<!--						</div>-->
<!--					</div>-->

<!--					<div class="box-footer">-->
<!--						<input type="submit" class="btn btn-success pull-right" value="Save"/>-->
<!--						<a style="margin-left: -139px;" class="btn btn-info pull-left " href="--><?php //echo base_url(); ?><!--class-list">Back</a>-->
<!---->
<!--					</div>-->
			</form>
		</div>
	</div>
	</div>

	<script>

		$(".check").click(function () {
			if (this.checked) {
				var label = $("#"+ this.id).prop("labels");
				checkBoxText = $(label).text();
				className  = $("#className").text();
				$("#classreg_section_name"+this.value).val(className.trim()+"-"+checkBoxText.trim());

			} else {
				$("#classreg_section_name"+this.value).val("");


			}

		});

	</script>
