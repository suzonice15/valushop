<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title">
<!--			<a class="btn btn-success" href="--><?php //echo base_url();?><!--class-section-create"><i class="fa fa-plus-circle"></i>Add new</span></a>-->
			<select required name="shift_id" id="classId" class="form-control select2">
				<option value="" >Select Class </option>
				<?php if(isset($classes)):
					foreach ($classes as $class):
						?>
						<option value="<?php echo $class->classreg_id;?>"><?php echo $class->classreg_name;?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first class </option>
				<?php endif;?>
			</select>


		</h3>
	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
<!--				<th>ClassSectionName</th>-->
				<th>Class</th>
				<th>Section</th>
<!--				<th>AddStudent</th>-->
			</tr>
			</thead>
			<tbody>
			<?php if (isset($classRelation)):

				$count = 1;
				foreach ($classRelation as $class_data):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $class_data->class_name; ?></td>
						<td><?php echo $class_data->section_name; ?></td>


					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>
<!--			<tfoot>-->
<!--			<tr>-->
<!--				<th>Serial</th>-->
<!--				<th>ClassSectionName</th>-->
<!--				<th>ClassName</th>-->
<!--				<th>SectionName</th>-->
<!--				<th>Action</th>-->
<!--			</tr>-->
<!--			</tfoot>-->
		</table>


	</div>

</div>
</div>
