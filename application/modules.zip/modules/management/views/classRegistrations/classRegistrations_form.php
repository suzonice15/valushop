
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Class name</label>
                        
						<div class="col-sm-8">
							<input  required type="text" id="field-1"  class="form-control" name="classreg_name"
							value="<?php   if(isset($class) ) echo $class->classreg_name;?>" placeholder="enter class name : five">
							<input  type="hidden"  name="classreg_id" 	value="<?php   if(isset($class) ) echo $class->classreg_id;?>" >
						</div>
					</div>
					
