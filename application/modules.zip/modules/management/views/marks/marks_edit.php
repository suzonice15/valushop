<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url() ?>mark-update" class="form-horizontal" method="post">

				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">Examination &  Session Name:</label>

					<div class="col-md-6">

						<select required name="exam_session_id" id="examsession_id" class="form-control select2">
							<option value="">Select examination and session name</option>
							<?php if (isset($examSessions)):
								foreach ($examSessions as $examSession):

									?>
									<option
										<?php $selectedData=isset($markdata) ? $markdata->exam_session_id==$examSession->exam_session_id ? 'selected="selected"': "":""; echo $selectedData; ?>
										value="<?php echo $examSession->exam_session_id; ?>"><?php echo $examSession->exam_session_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first exam and session name</option>
							<?php endif; ?>
						</select>
						<input type="hidden" name="mark_id"
							   value="<?php if (isset($markdata)) echo $markdata->mark_id; ?>">

					</div>
				</div>

				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">Subject Name</label>

					<div class="col-md-6">
						<select onchange="return StudentSelection()" required name="subject_id" id="subject_id" class="form-control select2 ">
							<option value="">Select subject name</option>
							<?php if (isset($subjects)):
								foreach ($subjects as $subject):

									?>
									<option
										<?php $selectedData=isset($markdata) ? $markdata->subject_id==$subject->classreg_id ? 'selected="selected"': "":""; echo $selectedData; ?>

										value="<?php echo $subject->classreg_id; ?>" > <?php echo $subject->subject_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first session name</option>
							<?php endif; ?>
						</select>
					</div>
				</div>


				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">Student Name</label>

					<div class="col-md-6">
						<select required name="student_id" id="student_id" class="form-control select2 ">
							<option value="">Select student  name</option>
							<?php if (isset($students)):
								foreach ($students as $student):

									?>
									<option

										<?php $selectedData=isset($markdata) ? $markdata->student_id==$student->student_id ? 'selected="selected"': "":""; echo $selectedData; ?>
										value="<?php echo $student->student_id; ?>" > <?php echo $student->student_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first student name</option>
							<?php endif; ?>

						</select>
					</div>
				</div>


				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">Obtained Mark</label>

					<div class="col-md-6">

						<input required value="<?php echo $markdata->mark_obtained; ?>" type="number" min="0" max="100" name="mark_obtained" id="obtained_mark"  onchange="return Mark()" placeholder=" enter exam mark:80" class="form-control "/>
					</div>
				</div>



				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">Grade point</label>

					<div class="col-md-6">

						<input required type="text" value="<?php echo $markdata->mark_grade_point; ?>" name="mark_grade_point" id="grade_point" readonly class="form-control "/>
					</div>
				</div>

				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">GPA </label>

					<div class="col-md-6">

						<input required type="text" value="<?php echo $markdata->mark_gpa; ?>" name="mark_gpa" id="gpa" readonly class="form-control "/>
					</div>
				</div>

				<script>

					function StudentSelection() {
						var subject_id = $('#subject_id').val();


						$.ajax({
							type: "POST",
							data: {subject_id : subject_id},
							url: '<?php echo base_url() ;?>Management/MarksController/StudentSelection',
							success: function (result) {
								if (result) {
									$('#student_id').html(result);
									return false;
								} else {
									return false;
								}
							}
						});
						return false;
					}

					function Mark() {
						var obtained_mark = $('#obtained_mark').val();
						if(obtained_mark >80){
							var gpa='A+';
							var grade_point='5.00';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else if( obtained_mark >=70 &&  obtained_mark<= 79){

							var gpa='A';
							var grade_point='4.00';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else if(obtained_mark >=60 && obtained_mark <= 69){

							var gpa='A-';
							var grade_point='3.50';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else if(obtained_mark >=50 && obtained_mark <= 59){

							var gpa='B';
							var grade_point='3';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else if(obtained_mark >=40 && obtained_mark <= 49){

							var gpa='C';
							var grade_point='2';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else if(obtained_mark >=33 && obtained_mark <= 39){

							var gpa='D';
							var grade_point='1';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						}
						else {
							var gpa='F';
							var grade_point='0';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);

						}


					}
				</script>








		</div>



		<div class="box-footer">
			<input type="submit" class="btn btn-success pull-right" value="Update"/>
			<a class="btn btn-default " href="<?php echo base_url();?>mark-list">Cancel</a>

		</div>
		</form>
	</div>
