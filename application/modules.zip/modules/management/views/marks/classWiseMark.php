<h1>Monipur school </h1>
<p>Report for</p>
<h3>Class:<?php echo $marks[0]->classreg_name; ?> </h3>
<h3>Subject:<?php echo $marks[0]->subject_name; ?> </h3>
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">


<table   class="table table-bordered table-striped table-responsive ">
					<thead>
					<tr>
						<th>Id</th>
						<th>Student</th>

						<th>Class</th>
						<th>Subject</th>
						<th>ExamSession</th>
						<th>Mark</th>
						<th>GradePoint</th>
						<th>Grade</th>
					</tr>
					</thead>
					<tbody>
									<?php if (isset($marks)):

										$count = 1;
										//var_dump($count);exit();
										foreach ($marks as $mark):

											?>
											<tr>
												<td><?php echo $count; ?></td>

												<td><?php echo $mark->student_name.'-'.$mark->student_roll; ?></td>

												<td><?php echo $mark->classreg_name; ?></td>
												<td><?php echo $mark->subject_name; ?></td>
												<td><?php echo $mark->exam_session_name; ?></td>
												<td><?php echo $mark->mark_obtained; ?></td>
												<td><?php echo $mark->mark_grade_point; ?></td>
												<td><?php echo $mark->mark_gpa; ?></td>


											</tr>

											<?php
											$count++;
										endforeach;
									endif; ?>

					</tbody>

				</table>

