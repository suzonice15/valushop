<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
	<div class="box-header with-border">

<!--        <h3 class="box-title"><a class="btn btn-success" href="--><?php //echo base_url();?><!--mark-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>-->



			<table class="table table-bordered" id="hidetable">
				<thead>
				<tr>
					<th scope="col">Class And Section </th>
					<th scope="col">Subject</th>
					<th scope="col">Exam And Session</th>
					<th scope="col">GPA</th>
					<th scope="col"></th>
				</tr>
				</thead>
				<tbody>
<!--				<form action="--><?php //echo base_url();?><!--class-wise-mark" method="post">-->

					<td>
						<select   id="classSectionId" name="classreg_section_id" class="form-control select2">
							<option value="" >Select Class </option>
							<?php if(isset($classsections)):
								foreach ($classsections as $class):
									?>
		<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class </option>
							<?php endif;?>
						</select>
					</td>
					<td>
						<select   id="subjectId" name="subject_id" class="form-control select2">
									<option value=""> select first class and section </option>
					      	</select>

					</td>
					<td>
						<select   id="examSessionId" name="exam_session_id" class="form-control select2">
							<option value="" >Select Exam Session </option>
							<?php if(isset($examSessions)):
								foreach ($examSessions as $examSession):
									?>
									<option value="<?php echo $examSession->exam_session_id;?>"><?php echo $examSession->exam_session_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first examsession </option>
							<?php endif;?>
						</select>

					</td>

					<td>			<select  name="shift_id" id="gpaId" class="form-control select2">
							<option value="" >Select GPA  </option>

									<option value="A+"> A+</option>
									<option value="A"> A</option>
									<option value="A-"> A-</option>
									<option value="B">B</option>
									<option value="C"> C</option>
									<option value="D"> D</option>
									<option value="F"> F</option>

						</select>
					</td>

					<td>
<!--						<input type="button"  value="Hide search ber" id="printId" class="btn btn-success"/>-->
						<input type="submit" onclick="window.print()" value="Print" class="btn btn-success"/>
					</td>
<!--				</form>-->
				</tr>
				</tbody>
			</table>

		<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-4 bg-success">
			<h4>Class    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  :<span id="dateShow1"></span></h4>
			<h4>Subject &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   :<span id="dateShow2"></span></h4>
			<h4>Examination:<span id="dateShow3"></span></h4>
			<h4>GPA    &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    :<span id="dateShow4"></span></h4>
		</div>





	</div>
	<div class="box-body">
		<div class="table-responsive" id="marklistId">
			<table id="example1"  class="table table-bordered table-striped table-responsive ">
				<thead>
				<tr>
					<th>Id</th>
					<th>Student</th>

					<th>Class</th>
					<th>Subject</th>
					<th>ExamSession</th>
					<th>Mark</th>
					<th>GradePoint</th>
					<th>Grade</th>
				</tr>
				</thead>
				<tbody>
<!--				--><?php //if (isset($marks)):
//
//					$count = 1;
//					//var_dump($count);exit();
//					foreach ($marks as $mark):
//
//						?>
<!--						<tr>-->
<!--							<td>--><?php //echo $count; ?><!--</td>-->
<!---->
<!--							<td>--><?php //echo $mark->student_name.'-'.$mark->student_roll; ?><!--</td>-->
<!---->
<!--							<td>--><?php //echo $mark->classreg_name; ?><!--</td>-->
<!--							<td>--><?php //echo $mark->subject_name; ?><!--</td>-->
<!--							<td>--><?php //echo $mark->exam_session_name; ?><!--</td>-->
<!--							<td>--><?php //echo $mark->mark_obtained; ?><!--</td>-->
<!--							<td>--><?php //echo $mark->mark_grade_point; ?><!--</td>-->
<!--							<td>--><?php //echo $mark->mark_gpa; ?><!--</td>-->
<!---->
<!---->
<!--						</tr>-->
<!---->
<!--						--><?php
//						$count++;
//					endforeach;
//				endif; ?>

				</tbody>

			</table>
		</div>
	</div>

</div>
</div>



<script>


	$("#classSectionId,#examSessionId,#subjectId,#gpaId").change(function () {

		var classSectionId = $("#classSectionId option:selected").text();
		var subjectId = $("#subjectId option:selected").text();
		var examSessionId = $("#examSessionId option:selected").text();
		var gpaId = $("#gpaId option:selected").text();
		$("#resultShow").show();
		$("#dateShow1").text(classSectionId);
		$("#dateShow2").text(subjectId);
		$("#dateShow3").text(examSessionId);
		$("#dateShow4").text(gpaId);
	});

	$("#classSectionId").change(function () {
	var classreg_section_id=$("#classSectionId").val();
	$.ajax({
		type: "POST",
		data: {classreg_section_id: classreg_section_id},
		url: '<?php echo base_url();?>Management/MarksController/classSectionData',
			success: function (results) {
			$("#subjectId").html(results);
			}
		});
	});

	$("#classSectionId").change(function () {
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id},
			url: '<?php echo base_url();?>Management/MarksController/studentSelectionData',
			success: function (results) {
				$("#studentId").html(results);
			}
		});
	});

$("#printId").click(function () {
	$("#hidetable").hide();
});

	$("#studentId").change(function () {
		var student_id=$("#studentId").val();
		var classreg_section_id=$("#classSectionId").val();
		var exam_session_id=$("#examSessionId").val();
		$.ajax({
			type: "POST",
			data: {student_id: student_id,classreg_section_id:classreg_section_id,exam_session_id:exam_session_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/MarksController/studentData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results['students'], function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['mark_obtained']+'</td>'+
						'<td>'+result['mark_grade_point']+'</td>'+
						'<td>'+result['mark_gpa']+'</td>'+

						'</tr>';
					str1=str1+str;

				});
				str1 +='<tr><td></td><td></td><td>'+results['finalmark']+'</td><td>'+results['finalGpa']+'</td><td>'+results['gradePoint']+'</td></tr>';

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});


	$("#examSessionId").change(function () {
		var exam_session_id=$("#examSessionId").val();
		var classreg_section_id=$("#classSectionId").val();
		var subject_id=$("#subjectId").val();

		$.ajax({
			type: "POST",
			data: {exam_session_id: exam_session_id,classreg_section_id:classreg_section_id,subject_id:subject_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/MarksController/examSessionData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['student_name']+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['exam_session_name']+'</td>'+
						'<td>'+result['mark_obtained']+'</td>'+
						'<td>'+result['mark_grade_point']+'</td>'+
						'<td>'+result['mark_gpa']+'</td>'+
						'</tr>';
					str1=str1+str;
				});
				 str1 +='</tbody></table>';
				// $("#marklistId").append(str1);
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#gpaId").change(function () {
		var exam_session_id=$("#examSessionId").val();
		var subjectId=$("#subjectId").val();
		var gpa=$("#gpaId").val();

		$.ajax({
			type: "POST",
			data: {subject_id: subjectId,exam_session_id:exam_session_id,gpa:gpa},
			dataType: "json",
			url: '<?php echo base_url();?>Management/MarksController/gpaData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['student_name']+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['exam_session_name']+'</td>'+
						'<td>'+result['mark_obtained']+'</td>'+
						'<td>'+result['mark_grade_point']+'</td>'+
						'<td>'+result['mark_gpa']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});



</script>



