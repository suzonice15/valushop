<div class="col-md-offset-1 col-md-10">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">
			<form id="add_thana_frm" action="<?php echo base_url() ?>mark-multiple-save"
				  class="form-horizontal" method="post">

<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
					<tr>

						<th scope="col">
							 Subject
						</th>
						<th scope="col"> Examination</th>
						<th scope="col"></th>
					</tr>
					</thead>
					<tbody>
					<tr>

						<td>
							<select required name="subject_id" id="subjectId"
									class="form-control select2">
								<?php
								if ($subjects):
									?>
									<option value="">Select class and subject name</option>
									<?php
									foreach ($subjects as $subject):?>
										<option

											value="<?php echo $subject->subject_id; ?>">


											<?php echo $subject->subject_name . '-' . $subject->classreg_name; ?></option>

									<?php endforeach;

								else : ?>
									<option value="">There are no class data registration please</option>
								<?php endif; ?>
							</select>

						</td>
						<td>

							<select name="exam_session_id" id="examsessionId" class="form-control select2 ">
								<option value="">Select exam and session name</option>
								<?php if (isset($examSessions)):
									foreach ($examSessions as $examSession):
										?>
										<option
											value="<?php echo $examSession->exam_session_id; ?>"> <?php echo $examSession->exam_session_name; ?>                                    </option>
									<?php endforeach; else : ?>
									<option value="">Registration first exam and session name</option>
								<?php endif; ?>
							</select>
						</td>
						<td><input type="button" class="btn btn-success" id="studentData"
								   click="return MultipleStudentSelection()"
								   value="studentdataList">
						</td>
					</tr>

					</tbody>
				</table>
</div>


				<table id="studentList" class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Student Name</th>
						<th scope="col">Mark</th>
						<th scope="col">GPA</th>
						<th scope="col">Grade</th>
					</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
				<div class="box-footer">
					<input type="submit" class="btn btn-success pull-right" value="Save"/>
					<a class="btn btn-default " href="<?php echo base_url(); ?>mark-list">Cancel</a>

				</div>
			</form>


		</div>
	</div>
</div>

<script>
$(document).ready(function () {
	$(document).on('input', '.obtainedMark', function () {

		// $(".obtainedMark").on('input', function () {
		var markId = this.id;
		var mark = $(this).val();
		var id = markId.split("d_");
		//alert(id)
		if (isNaN(mark)) {
			alert(mark + " is not number please enter valid number between 0 and 100");
			$("#mark_gpa_" + id[1]).val("");
			$("#mark_obtained_" + id[1]).val("");
			$("#mark_grade_point_" + id[1]).val("");
		} else {

			if (mark > 100) {
				alert(mark + " is not number please enter valid number between 0 and 100");
				$("#mark_gpa_" + id[1]).val("");
				$("#mark_grade_point_" + id[1]).val("");
				$("#mark_obtained_" + id[1]).val("");

			} else if (mark < 0) {
				alert(mark + " is not number please enter valid number between 0 and 100");
				$("#mark_gpa_" + id[1]).val("");
				$("#mark_grade_point_" + id[1]).val("");
				$("#mark_obtained_" + id[1]).val("");


			} else if (mark <= 100 && mark >= 80) {
				var gpa = 'A+';
				var grade_point = '5.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 79 && mark >= 70) {
				var gpa = 'A';
				var grade_point = '4.00';
				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 69 && mark >= 60) {
				var gpa = 'A-';
				var grade_point = '3.50';
				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 59 && mark >= 50) {
				var gpa = 'B';
				var grade_point = '3.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 49 && mark >= 40) {
				var gpa = 'C';
				var grade_point = '2.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 39 && mark >= 33) {
				var gpa = 'D';
				var grade_point = '1.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else {
				var gpa = 'F';
				var grade_point = '0.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			}

		}
	});
});

	$(function () {


		$("#studentData").click(function () {

			var subject_id = $('#subjectId').val();
			var exam_session_id = $('#examsessionId').val();
			$.ajax({
				type: "POST",
				data: {exam_session_id: exam_session_id, subject_id: subject_id},
				dataType: "json",
				url: "<?php echo base_url();?>management/MarksController/MultipleStudentSelection",
				success: function (results) {
					var str = "";
					var str1 = "";
					$.each(results['students'], function (key, result) {

						if (result['student_id'] == result['mark_student_id']) {
							str = '<tr>' + '<td><input type="checkbox"  checked  id="student_id_' + key + '" name="student_id[]"  value="' + result['student_id'] + '" /></td>' +
								'<td><label for="student_id_' + key + '">' + result['student_name'] + ' </label></td>' +
								'<td><input type="text" name="mark_obtained[]" class="obtainedMark form-control" id= "mark_obtained_' + key + '" value = "' + result['mark_obtained'] + '" / > </td>' +
								'<td><input name="mark_grade_point[]" readonly class="grade form-control" id="mark_grade_point_' + key + '"   value="' + result['mark_grade_point'] + '"></td>' +
								'<td> <input	name = "mark_gpa[]"	readonly class= "gpa form-control"  id = "mark_gpa_' + key + '" value = "' + result['mark_grade_point'] + '" ></td></tr>';
						} else {
							str = '<tr>' + '<td><input type="checkbox"   id="student_id_' + key + '" name="student_id[]"  value="' + result['student_id'] + '" /></td>' +
								'<td><label for="student_id_' + key + '">' + result['student_name'] + ' </label></td>' +
								'<td><input type="text" name="mark_obtained[]" class="obtainedMark form-control" id= "mark_obtained_' + key + '" value = "" / > </td>' +
								'<td><input name="mark_grade_point[]" readonly class="grade form-control" id="mark_grade_point_' + key + '"   value=""></td>' +
								'<td> <input	name = "mark_gpa[]"	readonly class= "gpa form-control"  id = "mark_gpa_' + key + '" value = "" ></td></tr>';
						}
						str1 = str1 + str;
					});

					$("#studentList tbody").empty();
					$("#studentList tbody").append(str1);

				}


			});
		});




	});


</script>


