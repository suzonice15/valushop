<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Examination & Session Name:</label>

	<div class="col-md-6">

		<select required name="exam_session_id" class="form-control select2">
			<option value="">Select examination and session name</option>
			<?php if (isset($examSessions)):
				foreach ($examSessions as $examSession):


					?>
					<option
						value="<?php echo $examSession->exam_session_id; ?>"><?php echo $examSession->exam_session_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first exam and session name</option>
			<?php endif; ?>
		</select>

	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Subject Name</label>

	<div class="col-md-6">
		<select required name="subject_id" id="subject_id" class="form-control select2 ">
			<option value="">Select subject name</option>
			<?php if (isset($subjects)):
				foreach ($subjects as $subject):

					?>
					<option value="<?php echo $subject->subject_id; ?>"> <?php echo $subject->subject_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first session name</option>
			<?php endif; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class & Section Name:</label>

	<div class="col-md-6">

		<select onchange="return StudentSelection()" required name="classreg_section_id" id="classregsection_id"
				class="form-control">
			<option value="">Select class & section name</option>
			<?php
			foreach ($classSectionRelations as $classSectionRelation):
				?>
				<!--<?php $classData = isset($class_id) ? ($class_id == $classSectionRelation->classreg_id) ? 'selected="selected"' : "" : "";
				echo $classData; ?>-->

				<option
					value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
			<?php endforeach; ?>
		</select>


	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Student Name</label>

	<div class="col-md-6">
		<select required name="student_id" id="student_id" class="form-control select2 ">
			<option value="">Select student name</option>
			<?php if (isset($students)):
				foreach ($students as $student):

					?>
					<option value="<?php echo $student->student_id; ?>"> <?php echo $student->student_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first student name</option>
			<?php endif; ?>

		</select>
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Obtained Mark</label>

	<div class="col-md-6">

		<input required type="number" min="0" max="100" name="mark_obtained" id="obtained_mark" oninput="return Mark()"
			   placeholder=" enter exam mark:80" class="form-control "/>
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Grade point</label>

	<div class="col-md-6">

		<input required type="text" name="mark_grade_point" id="grade_point" readonly class="form-control "/>
	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">GPA </label>

	<div class="col-md-6">

		<input required type="text" name="mark_gpa" id="gpa" readonly class="form-control "/>
	</div>
</div>

			<script>

				function StudentSelection() {
					var subject_id = $('#classregsection_id').val();


					$.ajax({
						type: "POST",
						data: {subject_id: subject_id},
						url: '<?php echo base_url();?>Management/MarksController/StudentSelection',
						success: function (result) {
							if (result) {
								$('#student_id').html(result);
								return false;
							} else {
								return false;
							}
						}
					});
					return false;
				}

				function Mark() {
					var obtained_mark = $('#obtained_mark').val();

					if(isNaN(obtained_mark) ){

						alert(obtained_mark +" is not number please enter valid number between 0 and 100");
						$("#grade_point").val("");
						$("#gpa").val("");
						$('#obtained_mark').val("");

					}
					else {
						if(obtained_mark>100){

							alert(obtained_mark+ " is not valid number please enter number less than 100 ");
							$("#grade_point").val("");
							$("#gpa").val("");
							$('#obtained_mark').val("");

						}
					else if(obtained_mark<0){

							alert(obtained_mark+ " is not valid number please enter number greater than 0 or equal to 0  ");
							$("#grade_point").val("");
							$("#gpa").val("");
							$('#obtained_mark').val("");
						}
						else if (obtained_mark<=100 && obtained_mark >= 80) {
							var gpa = 'A+';
							var grade_point = '5.00';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else if (obtained_mark >= 70 && obtained_mark <= 79) {

							var gpa = 'A';
							var grade_point = '4.00';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else if (obtained_mark >= 60 && obtained_mark <= 69) {

							var gpa = 'A-';
							var grade_point = '3.50';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else if (obtained_mark >= 50 && obtained_mark <= 59) {

							var gpa = 'B';
							var grade_point = '3';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else if (obtained_mark >= 40 && obtained_mark <= 49) {

							var gpa = 'C';
							var grade_point = '2';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else if (obtained_mark >= 33 && obtained_mark <= 39) {

							var gpa = 'D';
							var grade_point = '1';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);
						} else {
							var gpa = 'F';
							var grade_point = '0';
							$("#grade_point").val(grade_point);
							$("#gpa").val(gpa);

						}


					}



				}
			</script>

