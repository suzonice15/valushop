<div class="col-md-offset-1 col-md-10">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">
			<?php if (isset($studentSubjectRelations[0])): ?>
				<form id="add_thana_frm" action="<?php echo base_url() ?>mark-multiple-save"
					  class="form-horizontal" method="post">
					<div class="form-group">
						<label for="examName" class="col-sm-3 control-label">Subject Name:</label>

						<div class="col-md-8">
							<h4><label id="examName" class="label label-success">
									<?php

									echo $studentSubjectRelations[0]->subject_name;

									?></label></h4>

							<input type="hidden" name="subject_id"
								   value="<?php echo $studentSubjectRelations[0]->subject_id; ?>">

						</div>
					</div>
					<div class="form-group">
						<label for="examName" class="col-sm-3 control-label">Subject Code:</label>

						<div class="col-md-8">
							<h4><label id="examName" class="label label-success">
									<?php

									echo $studentSubjectRelations[0]->subject_code;

									?></label></h4>


						</div>
					</div>

					<div class="form-group">
						<label for="shiftName" class="col-md-3 control-label">Examination And Session Name:</label>

						<div class="col-md-3">
							<select required name="exam_session_id" id="exam_session_id" class="form-control select2 ">
								<option value="">Select examination and section name</option>
								<?php if (isset($examSessionRelations)):
									foreach ($examSessionRelations as $examSessionRelation):

											?>
											<option
												<?php
												$selected=isset($studentMarkRelations[0]) ? $studentMarkRelations[0]->exam_session_id==$examSessionRelation->exam_session_id ? 'selected="selected"':"" :"";
													echo $selected;

													?>
												value="<?php echo $examSessionRelation->exam_session_id; ?>"> <?php echo $examSessionRelation->exam_session_name; ?> </option>
										<?php  endforeach; else : ?>
									<option value="">Registration first exam and session name</option>
								<?php endif; ?>

							</select>
						</div>
					</div>


					<table class="table table-bordered">
						<thead>
						<tr>
							<th scope="col"></th>
							<th scope="col">Student Name</th>
							<th scope="col">Mark</th>
							<th scope="col">GPA</th>
							<th scope="col">Grade</th>
						</tr>
						</thead>
						<tbody>

						<?php foreach ($studentSubjectRelations

									   as $studentSubjectRelation) { ?>
							<tr>

								<td>
									<input

										<?php
									foreach ($studentSubjectRelations as $examSessionRelation) {
										$checked = $examSessionRelation->student_id == $studentSubjectRelation->student_id ? 'checked="checked"' : "";
										echo $checked;


									}

									?> type="checkbox"
									   id="student_id_<?php echo $studentSubjectRelation->student_id; ?>"
									   name="student_id[]" value="<?php echo $studentSubjectRelation->student_id; ?>"
									/>

								</td>
								<td>

									<label
										for="student_id_<?php echo $studentSubjectRelation->student_id; ?>"><?php echo $studentSubjectRelation->student_name . '-' . $studentSubjectRelation->student_roll; ?></label>&ensp;&ensp;

								</td>
								<td>

									<input type="text" name="mark_obtained[]" class="obtainedMark form-control"
										   id="mark_obtained_<?php echo $studentSubjectRelation->student_id; ?>"

										   value="

<?php foreach ($studentMarkRelations as $studentMarkRelation) :
											   if ($studentMarkRelation->student_id == $studentSubjectRelation->student_id) {
												   echo $studentMarkRelation->mark_obtained;
											   }
										   endforeach;
										   ?>"/>

								</td>
								<td>

									<input name="mark_grade_point[]" readonly class="grade form-control"
										   id="mark_grade_point_<?php echo $studentSubjectRelation->student_id; ?>"

										   value="

<?php foreach ($studentMarkRelations as $studentMarkRelation) :
											   if ($studentMarkRelation->student_id == $studentSubjectRelation->student_id) {
												   echo $studentMarkRelation->mark_grade_point;
											   }
										   endforeach;
										   ?>

"
									>

								</td>

								<td>

									<input name="mark_gpa[]" readonly class="gpa form-control"
										   id="mark_gpa_<?php echo $studentSubjectRelation->student_id; ?>"

										   value="

<?php foreach ($studentMarkRelations as $studentMarkRelation) :
											   if ($studentMarkRelation->student_id == $studentSubjectRelation->student_id) {
												   echo $studentMarkRelation->mark_gpa;
											   }
										   endforeach;
										   ?>

"
									>

								</td>
							</tr>
							<?php

						} ?>
						<tr>
							<td colspan="4">
								<a class="btn btn-danger " href="<?php echo base_url(); ?>subject-list">Cancel</a>


							</td>


							<td>
								<input type="submit" class="btn btn-success pull-right " value="Save"/>


							</td>

						</tr>

						</tbody>
					</table>

				</form>


			<?php endif; ?>




		</div>
	</div>
</div>

<script>



	$(".obtainedMark").on('input', function () {
		var markId = this.id;
		var mark = $(this).val();
		var id = markId.split("d_");
		//alert(id);
		if (isNaN(mark)) {
			alert(mark + " is not number please enter valid number between 0 and 100");
			$("#mark_gpa_" + id[1]).val("");
			$("#mark_obtained_" + id[1]).val("");
			$("#mark_grade_point_" + id[1]).val("");
		} else {

			if (mark > 100) {
				alert(mark + " is not number please enter valid number between 0 and 100");
				$("#mark_gpa_" + id[1]).val("");
				$("#mark_grade_point_" + id[1]).val("");
				$("#mark_obtained_" + id[1]).val("");

			} else if (mark < 0) {
				alert(mark + " is not number please enter valid number between 0 and 100");
				$("#mark_gpa_" + id[1]).val("");
				$("#mark_grade_point_" + id[1]).val("");
				$("#mark_obtained_" + id[1]).val("");


			} else if (mark <= 100 && mark >= 80) {
				var gpa = 'A+';
				var grade_point = '5.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 79 && mark >= 70) {
				var gpa = 'A';
				var grade_point = '4.00';
				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 69 && mark >= 60) {
				var gpa = 'A-';
				var grade_point = '3.50';
				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 59 && mark >= 50) {
				var gpa = 'B';
				var grade_point = '3.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 49 && mark >= 40) {
				var gpa = 'C';
				var grade_point = '2.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else if (mark <= 39 && mark >= 33) {
				var gpa = 'D';
				var grade_point = '1.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			} else {
				var gpa = 'F';
				var grade_point = '0.00';

				$("#mark_gpa_" + id[1]).val(gpa);
				$("#mark_grade_point_" + id[1]).val(grade_point);

			}

		}
	});
</script>


