
<h3>Class:<?php  if(isset($teacherRelations)){ echo $teacherRelations[0]->classreg_name; }?> </h3>
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped ">
					<thead>
					<tr>
						<th>Serial</th>
						<th>Class</th>
						<th>Subject</th>
						<th>Teacher</th>
						<th>Contact number</th>


					</tr>
					</thead>
					<tbody>
					<?php if (isset($teacherRelations)):

						$count = 1;
						//var_dump($count);exit();
						foreach ($teacherRelations as $teacher):

							?>
							<tr>
								<td><?php echo $count; ?></td>
								<td><?php echo $teacher->classreg_name; ?></td>
								<td><?php echo $teacher->subject_name; ?></td>
								<td><?php echo $teacher->teacher_full_name; ?></td>
								<td><?php echo $teacher->teacher_contact_no; ?></td>

							</tr>

							<?php
							$count++;
						endforeach;
					endif; ?>

					</tbody>

				</table>


			</div>
		</div>
	</div>
</div>
