



<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>teacher-subject-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="teacherName" class="col-sm-3 control-label">Teacher Name:</label>

					<div class="col-sm-8">
						<h4><label id="teacherName" class="label label-success">
							<?php

							echo $teacher->teacher_full_name;

							?></label></h4>

						<input type="hidden" name="teacher_id" value="<?php echo $teacher->teacher_id; ?>" >

					</div>
				</div>
				<table class="table table-bordered">
					<thead>

					<tr>
						<th scope="col"></th>
						<th scope="col">Subject Name:</th>

					</tr>
					</thead>
					<tbody>

					<?php foreach ($subjects

					as $subject) { ?>


					<tr>
						<td>

							<input <?php
							foreach ($teacherRelations as $teacherRelation) {
								if ($teacherRelation->subject_id == $subject->subject_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="subject_id_<?php echo $subject->subject_id; ?>"
							   name="subject_id[]" value="<?php echo $subject->subject_id; ?>"
							/>

						</td>
						<td>
							<label style="font-weight: normal"
								for="subject_id_<?php echo $subject->subject_id; ?>"><?php echo $subject->subject_name; ?></label>
							<label
							><?php echo $subject->classreg_name; ?></label>

							<input type="text" name="teacher_subject_name[]" readonly
								   value="<?php
								   foreach ($teacherRelations as $teacherRelation) {
									   if ($teacherRelation->subject_id == $subject->subject_id) {
										   echo $teacherRelation->teacher_subject_name;
									   } else {
										   $teacherRelation->teacher_subject_name;
									   }
								   }

								   ?>"
								   id="teacher_subject_name_<?php echo $subject->subject_id; ?>">


						</td>
					</tr>
						<?php

					} ?>
					<tr>
						<td>
							<a class="btn btn-info " href="<?php echo base_url(); ?>teacher-list">Back</a>


						</td>

						<td>

							<input type="submit" class="btn btn-success pull-right" value="Save"/>

						</td>
					</tr>

					</tbody>
				</table>

			</form>


					</div>

		</div>
	</div>

	<script>

		$(".check").click(function () {
			if (this.checked) {
				var label = $("#" + this.id).prop("labels");
				checkBoxText = $(label).text();
				teacherName = $("#teacherName").text();
				$("#teacher_subject_name_" + this.value).val(teacherName.trim() + "-" + checkBoxText.trim());

			} else {
				$("#teacher_subject_name_" + this.value).val("");


			}

		});

	</script>
