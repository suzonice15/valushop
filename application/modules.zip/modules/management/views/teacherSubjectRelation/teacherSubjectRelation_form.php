<div class="form-group">
<!--	<label for="shiftName" class="col-sm-4 control-label">Teacher Subject  Name</label>-->

	<div class="col-sm-6">
		<input name="teacher_subject_name"  type="hidden" value="<?php if( isset($teacherRelation) ) echo $teacherRelation->teacher_subject_name; ?>" id ="teacher_subject_name"    placeholder="Text" class="form-control"/>
	</div>
</div>


<div class="form-group">
    <label for="shiftName" class="col-sm-4 control-label">Teacher Name</label>

    <div class="col-sm-6">

		<select required name="teacher_id" id="teacher_id" class="form-control select2">
			<option value="" >Select teacher name</option>
			<?php if(isset($teachers)):
				foreach ($teachers as $teacher):


				?>
			<option <?php if(isset($teacherRelation->teacher_id )): if($teacherRelation->teacher_id == $teacher->teacher_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $teacher->teacher_id; ?>" ><?php echo $teacher->teacher_full_name;?> </option>
			<?php endforeach; else : ?>
			<option value="">Registration first teacher name</option>
			<?php endif;?>
		</select>
		<input type="hidden"  name="teacher_subject_id" value="<?php if (isset($teacherRelation)) echo $teacherRelation->teacher_subject_id; ?>">

          </div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Subject Name</label>

	<div class="col-sm-6">
		<select required name="subject_id"  id="subject_id" class="form-control select2 ">
			<option value="" >Select subject name</option>
			<?php if(isset($subjects)):
				foreach ($subjects as $subject):

					?>
					<option <?php if(isset($teacherRelation->subject_id )) : if($teacherRelation->subject_id == $subject->subject_id ):  echo 'selected="selected"'; else : echo '';endif;endif; ?> value="<?php echo $subject->subject_id; ?>" > <?php echo $subject->subject_name.'-'.$subject->subject_code;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first subject  name</option>
			<?php endif;?>
		</select>
	</div>
</div>

<script>


	$("#teacher_id , #subject_id").change(function () {
		var teacher_id = $("#teacher_id option:selected ").text();
		var subject_id = $("#subject_id option:selected ").text();
		var comTeacherSubject = teacher_id + '-' + subject_id;
		$("#teacher_subject_name").val(comTeacherSubject);
	});


</script>

