<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<table class="table table-bordered col-md-offset-3 col-md-6">
			<thead>
			<tr>
				<th scope="col" width="200">Class</th>
<!--				<th scope="col" width="250">Subject</th>-->
				<th scope="col" ></th>
			</tr>
			</thead>
			<form action="<?php echo base_url()?>subject-report" method="post">
				<tr>

				<td>

					<select required name="classreg_id" id="classId" class="form-control select2">
						<option value="" >Select Class </option>
						<?php if(isset($classes)):
							foreach ($classes as $class):
								?>
								<option value="<?php echo $class->classreg_id;?>"><?php echo $class->classreg_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first class name</option>
						<?php endif;?>
					</select>
				</td>
<!--				<td>-->
<!---->
<!--					<select required name="subjectId" id="subjectId" class="form-control select2">-->
<!--						<option value="" >Select subject</option>-->
<!--						--><?php //if(isset($subjects)):
//							foreach ($subjects as $subject):
//
//
//								?>
<!--								<option value="--><?php //echo $subject->subject_id; ?><!--"> --><?php //echo $subject->subject_name.'-'.$subject->subject_code;?><!-- </option>-->
<!--							--><?php //endforeach; else : ?>
<!--							<option value="">Registration first subject name</option>-->
<!--						--><?php //endif;?>
<!--					</select>-->
<!--				</td>-->
				<td><input type="submit"  class="btn btn-success" value="Print"></td>
<!--				<td>-->
<!--					<select required name="teacher_id" id="teacherId" class="form-control select2">-->
<!--						<option value="" >Select teacher</option>-->
<!--						--><?php //if(isset($teachers)):
//							foreach ($teachers as $teacher):
//
//
//								?>
<!--								<option value="--><?php //echo $teacher->teacher_id; ?><!--"> --><?php //echo $teacher->teacher_full_name;?><!-- </option>-->
<!--							--><?php //endforeach; else : ?>
<!--							<option value="">Registration first teacher name</option>-->
<!--						--><?php //endif;?>
<!--					</select>-->
<!---->
<!--				</td>-->
				</form>
			</tr>

			</tbody>
		</table>

		<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-4 bg-success">
			<h4>Class :<span id="dateShow1"></span></h4>
		</div>



	</div>
	<div class="box-body">
<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped ">
			<thead>
			<tr>
				<th>Serial</th>
<!--				<th>TeacherSubjectName </th>-->

				<th>Class</th>
				<th>Subject</th>
				<th>Teacher</th>
				<th>Contact number</th>


			</tr>
			</thead>
			<tbody>
			<?php if (isset($teacherRelations)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($teacherRelations as $teacher):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $teacher->classreg_name; ?></td>
						<td><?php echo $teacher->subject_name; ?></td>
						<td><?php echo $teacher->teacher_full_name; ?></td>
						<td><?php echo $teacher->teacher_contact_no; ?></td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>
	</div>
</div>
</div>
<script>

	$("#classId").change(function () {

		var classId = $("#classId option:selected").text();
		$("#resultShow").show();

		$("#dateShow1").text(classId);
	});

	$("#classId").change(function () {
		var classId=$("#classId").val();
		$.ajax({
			type: "POST",
			data: {classreg_id: classId},
			dataType: "json",
			url: '<?php echo base_url();?>Management/TeacherSubjectRelationController/classData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#subjectId").change(function () {
		var subjectId=$("#subjectId").val();
		$.ajax({
			type: "POST",
			data: {subject_id: subjectId},
			dataType: "json",
			url: '<?php echo base_url();?>Management/TeacherSubjectRelationController/subjectData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#teacherId").change(function () {
		var teacher_id=$("#teacherId").val();
		$.ajax({
			type: "POST",
			data: {teacher_id: teacher_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/TeacherSubjectRelationController/teacherData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>

