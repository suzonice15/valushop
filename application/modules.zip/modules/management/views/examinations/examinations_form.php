
					<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Examination Name</label>
                        
						<div class="col-sm-6">
							<input  required type="text" id="field-1"  class="form-control" name="examination_name"   
							value="<?php   if(isset($examination) ) echo $examination->examination_name;?>" placeholder="enter examination name : final">
							<input  type="hidden"  name="examination_id" 	value="<?php   if(isset($examination) ) echo $examination->examination_id;?>" >
						</div>
					</div>
					
