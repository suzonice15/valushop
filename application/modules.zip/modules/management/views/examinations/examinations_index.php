<div class="col-md-offset-0 col-md-12">

<div class="box  box-success">
        <div class="box-header with-border">
			<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>examination-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


        </div>
        <div class="box-body">
         
		   <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Serial</th>
                  <th>ExaminationName</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php if(isset($examinations)):
				
				$count=count($examinations);
					foreach($examinations as $result):
					
					?>
                <tr>
                  <td><?php echo $count; ?></td>
                  <td><?php echo $result->examination_name;?></td>
                  <td>
					  <a href="<?php echo base_url() ?>examination-edit/<?php echo $result->examination_id; ?>"
					  <span class="glyphicon glyphicon-edit btn btn-success"></span>
					  </a>
					  <a href="<?php echo base_url() ?>examination-delete/<?php echo $result->examination_id; ?>"
						 onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
						  <span class="glyphicon glyphicon-trash btn btn-danger"></span>
					  </a>
					  




				  </td>                 
                               
                </tr>
               
                <?php 
				$count--;
				endforeach;
				endif;?>
                
                </tbody>
				 <tfoot>
                <tr>
                  <th>Serial</th>
                  <th>ExaminationName</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
        
		
		</div>		
		
        </div>
        </div>
