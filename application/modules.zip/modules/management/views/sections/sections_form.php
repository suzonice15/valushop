
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Section name</label>
                        
						<div class="col-sm-8">
							<input  required  type="text" id="field-1"  class="form-control" name="section_name"
							value="<?php   if(isset($section) ) echo $section->section_name;?>" placeholder="enter section name : A">
							<input  type="hidden"  name="section_id" 	value="<?php   if(isset($section) ) echo $section->section_id;?>" >
						</div>
					</div>
					
