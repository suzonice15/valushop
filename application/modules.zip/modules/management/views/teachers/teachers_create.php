
<div class="col-md-offset-1 col-md-10">
<div class="box box-success ">
        <div class="box-header with-border">
         <h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


        </div>
        <div class="box-body">


		<form action="<?php echo base_url()?>teacher-save" class="form-horizontal"  method="post" enctype="multipart/form-data" >
		<span style="text-align:center;color:red"><?php echo validation_errors(); ?></span>


			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher name<span style="color:red"> *</span></label>

				<div class="col-md-7">
					<input required type="text" id="field-1" class="form-control" name="teacher_full_name"
						   value="<?php if (isset($teacher)) echo $teacher->teacher_full_name; ?>"
						   placeholder="enter teacher name :shahinul islam">
					<input type="hidden" name="teacher_id" value="<?php if (isset($teacher)) echo $teacher->teacher_id; ?>">
				</div>
			</div>

			<div class="form-group">
				<label for="teacher_contact_no" class="col-sm-3 control-label">Teacher mobile<span style="color:red"> *</span></label>

				<div class="col-md-7">
					<input required type="number" id="teacher_contact_no" class="form-control" name="teacher_contact_no"
						   value="<?php if (isset($teacher)) echo $teacher->teacher_contact_no; ?>"
						   placeholder="enter teacher mobile :01738306670">
					<span id="mobileEerror" style="color:red"></span>
					<?php form_error('teacher_contact_no','<span style="color:red">','</span>')?>
				</div>
			</div>
			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher address<span style="color:red"> *</span></label>

				<div class="col-md-7">
					<input required type="text" id="field-1" class="form-control" name="teacher_address"
						   value="<?php if (isset($teacher)) echo $teacher->teacher_address; ?>"
						   placeholder="enter teacher address :dhaka,bangladesh">
				</div>
			</div>

			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher's email</label>

				<div class="col-md-7">
					<input  type="email"  class="form-control" name="teacher_email" id="teacher_email"
							value="<?php if (isset($teacher)) echo $teacher->teacher_email; ?>"
							placeholder="enter teacher name :shahinul@gmail.com">
					<span id="emailEerror" style="color:red"></span>

				</div>
			</div>
			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher National Id Card</label>

				<div class="col-md-7">
					<input type="text" id="field-1" class="form-control" name="teacher_nid" id="teacher_nid"
						   value="<?php if (isset($teacher)) echo $teacher->teacher_nid; ?>"
						   placeholder="enter teacher nid :1991968226644868">
					<span id="nidEerror" style="color:red"></span>

				</div>
			</div>
			<div class="form-group">
				<label  class="col-sm-3 control-label">Job title<span style="color:red"> </span></label>
				<div class="col-md-7">
					<select required name="designation_id" class="form-control select2" id="teacher_title" class="form-control">
						<option value="">Select Job title</option>
						<?php if(isset($designations)): foreach ($designations as $designation):?>
							<option value="<?php echo $designation->designation_id;?>"><?php echo $designation->designation_name;?></option>
						<?php endforeach;endif;?>



					</select>
				</div>

			</div>

			<div class="form-group">
				<label for="field-2" class="col-sm-3 control-label">Gender<span style="color:red"> *</span></label>
				<div class="col-md-7">
					<select required name="teacher_sex" class="form-control select2" id="gender_id" class="form-control">
						<option value="">Select Gender</option>
						<option <?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Female" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Female">Female
						</option>
						<option<?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Male" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Male">Male</option>
						<option <?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Other" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Other">Other</option>

					</select>
				</div>

			</div>


			<div class="form-group">
				<label for="field-2" class="col-sm-3 control-label">Religion <span style="color:red"> *</span></label>
				<div class="col-md-7">
					<select required name="teacher_religion" class="form-control select2" id="religion_id" class="form-control">

						<option value="">Select Religion</option>
						<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Muslim" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Muslim">Muslim
						</option>
						<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Buddist" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Buddist">
							Buddist
						</option>
						<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Christian" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Christian">
							Christian
						</option>
						<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Hindu" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Hindu">Hindu
						</option>
					</select>
				</div>
			</div>


			<div class="form-group">
				<label for="field-2" class="col-sm-3 control-label">Blood Group </label>
				<div class="col-md-7">
					<select name="teacher_blood_group" class="form-control select2" id="blood_group_id" class="form-control">
						<option value="">Select blood group</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "AB-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="AB-">AB-
						</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "AB+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="AB+">AB+
						</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "B-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="B-">B-</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "B+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="B+">B+</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "A-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="A-">A-</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "A+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="A+">A+</option>
						<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "O-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="O-">O-</option>
						<option<?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "O+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="O+">O+</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher Joining  date</label>

				<div class="col-sm-7">
					<div class="input-group date">
						<input required="" type="text" id="field-1" class="form-control datepicker" name="teacher_joining_date" value="" placeholder=" session start : 1-1-2019">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-th"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Teacher MPO  date</label>

				<div class="col-sm-7">
					<div class="input-group date">
						<input required="" type="text" id="field-1" class="form-control datepicker" name="teacher_mpo_date" value="" placeholder=" session start : 1-1-2019">
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-th"></span>
						</div>
					</div>
				</div>
			</div>

			<?php if(!empty($teacher->teacher_picture_path)):?>

				<div class="form-group">
					<label for="field-1" class="col-sm-3 control-label">Teacher picture</label>
					<div class="col-md-7">
						<img width="70" height="60" src="<?php echo base_url(); if(isset($teacher)){ echo $teacher->teacher_picture_path;} ?>"/>

						<input type="hidden"  class="form-control" name="old_teacher_picture_path" value="<?php  if(isset($teacher)){ echo $teacher->teacher_picture_path;} ?>">
					</div>
				</div>
			<?php else :?>

			<?php endif;?>

			<div class="form-group">
				<label for="field-1" class="col-sm-3 control-label">Class Assign  </label>
				<div class="col-md-7">

					<input type="text" name="class_name" class="form-control" value="<?php if(isset($teacher)): echo $teacher->class_name;endif;?>">

				</div>
				<br/>
				<br/>
				<br/>

				<div class="form-group">
					<label for="field-1" class="col-sm-3 control-label">Teacher picture</label>

					<div class="col-md-7">
						<input type="file" id="field-1" class="form-control" name="teacher_picture_path">
					</div>
				</div>

				<table id="qualification" class="table table-bordered ">
					<caption class="text-center bg-info">Educational Qualification</caption>
					<thead>
					<tr>
						<th>Class</th>
						<th>Passing Year</th>
						<th>Result </th>
						<th>Board</th>
					</tr>
					</thead>
					<tbody>
						<tr>
							<td><input class="form-control" type="text" name="qualification_name[]"></td>
							<td>
								<input class="form-control"  type="text" name="qualification_year[]">


							</td>
							<td><input class="form-control" type="text" name="qualification_result[]"></td>
							<td><input class="form-control"  type="text" name="qualification_board[]"></td>
						</tr>
					</tbody>


				</table>
				<input class="form-control btn-success" id="addRow" type="button"  value="add row">

				<input class="form-control btn-danger"  id="deleteRow" type="button" value="remove row">


				<table id="qualification" class="table table-bordered ">
					<caption class="text-center bg-info">Training Information</caption>
					<thead>
					<tr>
						<th>Training Name</th>
						<th>Durations</th>
						<th>Starting date </th>
						<th>Ending date</th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td><input class="form-control" type="text" name="teacher_training_name[]"></td>
						<td><input class="form-control"  type="text" name="teacher_training_duration[]"></td>
						<td><input class="form-control" type="text" name="teacher_training_starting_date[]"></td>
						<td><input class="form-control"  type="text" name="teacher_training_endingdate[]"></td>
					</tr>
					</tbody>


				</table>
				<input class="form-control btn-success" id="addTraingRow" type="button"  value="add row">

				<input class="form-control btn-danger"  id="deleteTraingRow" type="button" value="remove row">


				<table id="qualification" class="table table-bordered ">
					<caption class="text-center bg-info">Training service provider</caption>
					<thead>
					<tr>
						<th>Venue Name</th>
						<th>Durations</th>
						<th>Starting date </th>
						<th>Ending date</th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td><input class="form-control" type="text" name="trainging_service_name[]"></td>
						<td><input class="form-control"  type="text" name="trainging_service_duration[]"></td>
						<td><input class="form-control" type="text" name="trainging_service_starting_date[]"></td>
						<td><input class="form-control"  type="text" name="trainging_service_ending_date[]"></td>
					</tr>
					</tbody>


				</table>
				<input class="form-control btn-success" id="addServiceRow" type="button"  value="add row">

				<input class="form-control btn-danger"  id="deleteServiceRow" type="button" value="remove row">


			</div>

			<div class="box-footer">
				<input type="submit" class="btn btn-success pull-right" value="Save"/>
				<a class="btn btn-danger " href="<?php echo base_url();?>teacher-list">Cancel</a>

			</div>
		</form>
        </div>
        </div>

<script>

	$(document).ready(function () {
		$('input[type="submit"]').attr('disabled','disabled');
		$(document).on('blur','#teacher_contact_no',function () {
			checkMobile();
		});
		$(document).on('input','#teacher_nid',function () {
			checkNid();
		});
		$(document).on('input','#teacher_email',function () {
			teacherEmailCheck();
		});

	});

</script>

<script>
	function checkMobile() {
		var teacher_contact_no = $('#teacher_contact_no').val();
		if(teacher_contact_no.length<11){
			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;

		}
		else if(teacher_contact_no.length>11){

			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;
		}
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url()?>management/TeachersController/teacherMobile/' + teacher_contact_no,
			success: function (result) {
				if (result) {
					$('#mobileEerror').html(result);
					return false;
				} else {
					$('#mobileEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});
		return false;
	}

	function checkNid() {
		var teacher_nid = $('#teacher_nid').val();
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url()?>management/TeachersController/teacherNid/' + teacher_nid,
			success: function (result) {
				if (result) {
					$('#nidEerror').html(result);
					$('input[type="submit"]').attr('disabled','disabled');
					return false;
				} else {
					$('#nidEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});


		return false;
	}

	function teacherEmailCheck() {
		var teacher_email = $('#teacher_email').val();
		debugger;
		$.ajax({
			type: 'POST',
			data:{teacher_email:teacher_email},
			url: '<?php echo base_url()?>management/TeachersController/teacherEmailCheck',
			success: function (result) {
				if (result) {
					$('#emailEerror').html(result);
					$('input[type="submit"]').attr('disabled','disabled');
					return false;
				} else {
					$('#emailEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});


		return false;
	}
</script>

<script>

	$("#addRow").click(function () {

		var markup = '<tr>'+'<td><input class="form-control" type="text" name="qualification_name[]"></td>'+
			'<td><input class="form-control"  type="text" name="qualification_year[]"></td>'+
			'<td><input class="form-control" type="text" name="qualification_result[]"></td>'+

			'<td><input class="form-control"  type="text" name="qualification_board[]"></td>'+
		'</tr>';

		$("table tbody").first().append(markup);

	});
	$("#deleteRow").click(function () {



		$("table tbody tr").eq(0).remove();

	});


	$("#addTraingRow").click(function () {

		var markup = '<tr>'+'<td><input class="form-control" type="text" name="teacher_training_name[]"></td>'+
			'<td><input class="form-control"  type="text" name="teacher_training_duration[]"></td>'+
			'<td><input class="form-control" type="text" name="teacher_training_starting_date[]"></td>'+

			'<td><input class="form-control"  type="text" name="teacher_training_endingdate[]"></td>'+
			'</tr>';

		$("table tbody").eq(1).append(markup);

	});
	$("#deleteTraingRow").click(function () {
		$("table tbody tr").eq(1).remove();
	});
	$("#addServiceRow").click(function () {

		var markup = '<tr>'+'<td><input class="form-control" type="text" name="trainging_service_name[]"></td>'+
			'<td><input class="form-control"  type="text" name="trainging_service_duration[]"></td>'+
			'<td><input class="form-control" type="text" name="trainging_service_starting_date[]"></td>'+

			'<td><input class="form-control"  type="text" name="trainging_service_ending_date[]"></td>'+
			'</tr>';

		$("table tbody").eq(2).append(markup);

	});
	$("#deleteServiceRow").click(function () {

		$("table tbody tr").eq(2).remove();

	});


</script>






