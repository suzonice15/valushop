
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Class room number</label>
                        
						<div class="col-sm-8">
							<input  required  type="text" id="field-1"  class="form-control" name="class_room_name"
							value="<?php   if(isset($classRoom) ) echo $classRoom->class_room_name;?>" placeholder="enter class room name : 101">
							<input  type="hidden"  name="class_room_id" 	value="<?php   if(isset($classRoom) ) echo $classRoom->class_room_id;?>" >
						</div>
					</div>
					
