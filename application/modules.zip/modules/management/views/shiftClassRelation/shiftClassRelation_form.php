<div class="form-group">
<!--	<label for="shiftName" class="col-md-4 control-label">Class , Shift and Section Name</label>-->

	<div class="col-md-6">

		<input required type="hidden" name="shift_classreg_section_name" id="shiftReg_section_name"
			   placeholder=" enter exam name"
			   value="<?php if (isset($shiftClassSectionRelations)) echo $shiftClassSectionRelations->shift_classreg_section_name; ?>"
			   class="form-control "/>
		<input type="hidden" name="shift_classreg_section_id"
			   value="<?php if (isset($shiftClassSectionRelations)) echo $shiftClassSectionRelations->shift_classreg_section_id; ?>">

	</div>
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class and Section Name</label>

	<div class="col-sm-6">

		<select required name="classreg_section_id" id="classReg_section_id" class="form-control select2">
			<option value="">Select class and section name</option>
			<?php if (isset($classSections)):
				foreach ($classSections as $classSection):


					?>
					<option <?php if (isset($shiftClassSectionRelations)): if ($shiftClassSectionRelations->classreg_section_id == $classSection->classreg_section_id)  : echo 'selected'; else : endif; endif; ?>
						value="<?php echo $classSection->classreg_section_id; ?>"><?php echo $classSection->classreg_section_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class name</option>
			<?php endif; ?>
		</select>

	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Shift Name</label>

	<div class="col-sm-6">
		<select required name="shift_id" id="shift_id" class="form-control select2 ">
			<option value="">Select shift name</option>
			<?php if (isset($shift)):
				foreach ($shift as $shift_row):

					?>
					<option <?php if (isset($shiftClassSectionRelations->shift_id)) : if ($shiftClassSectionRelations->shift_id == $shift_row->shift_id): echo 'selected'; else : echo '';endif;endif; ?>
						value="<?php echo $shift_row->shift_id; ?>"> <?php echo $shift_row->shift_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first shift name</option>
			<?php endif; ?>
		</select>
	</div>
</div>

<script>


	$("#classReg_section_id , #shift_id").change(function () {
		var shift_id = $("#shift_id option:selected ").text();
		var classReg_section_id = $("#classReg_section_id option:selected ").text();
		var classShiftRelation = classReg_section_id + '-' + shift_id;
		$("#shiftReg_section_name").val(classShiftRelation);
	});


</script>




