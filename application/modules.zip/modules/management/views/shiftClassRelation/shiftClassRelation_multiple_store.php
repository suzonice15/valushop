<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>teacher-shift-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Class Name</label>

					<div class="col-sm-8">
						<label id="shiftName" class="control-label">
							<?php

							echo $shiftClassRelations[0]->classreg_name;

							?></label>

						<input type="hidden" name="shift_id" value="<?php echo $shiftClassRelations[0]->classreg_id; ?>">

					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-3 control-label">Shift Name</label>

					<div class="col-md-9">

						<?php foreach ($shifts

						as $shift) { ?>
						<div class="checkbox">
							<input <?php
							foreach ($shiftClassRelations as $shiftClassRelation) {
								if ($shiftClassRelation->shift_id == $shift->shift_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="shift_id_<?php echo $shift->shift_id; ?>"
							   name="shift_id[]" value="<?php echo $shift->shift_id; ?>"
							/>
							<label
								for="shift_id_<?php echo $shift->shift_id; ?>"><?php echo $shift->shift_name; ?></label>
							<input type="hidden" name="shift_classreg_name[]" readonly
								   value="<?php
								   foreach ($shiftClassRelations as $shiftClassRelation) {
									   if ($shiftClassRelation->shift_id == $shift->shift_id) {
										   echo $shiftClassRelation->shift_classreg_name;
									   } else {
										   //  echo $shift['teacher_shift_name'];
									   }
								   }

								   ?>

"
								   id="shift_classreg_name_<?php echo $shift->shift_id; ?>">


							<br>

							<?php

							} ?>
						</div>
					</div>

					<div class="box-footer">
						<input type="submit" class="btn btn-success pull-right" value="Save"/>
						<a class="btn btn-danger " href="<?php echo base_url(); ?>teacher-shift-list">Cancel</a>

					</div>
			</form>
		</div>
	</div>

	<script>

		$(".check").click(function () {
			if (this.checked) {
				var label = $("#" + this.id).prop("labels");
				checkBoxText = $(label).text();
				shiftName = $("#shiftName").text();
				$("#teacher_shift_name_" + this.value).val(checkBoxText.trim() + "-" + shiftName.trim());

			} else {
				$("#teacher_shift_name_" + this.value).val("");


			}

		});

	</script>
