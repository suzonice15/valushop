<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">

<!--		<h3 class="box-title">-->
<!--		<a class="btn btn-success" href="--><?php //echo base_url(); ?><!--class-section-shift-create"><i-->
<!--			class="fa fa-plus-circle"></i>Add new</span></a>-->
<!--		</h3>-->
	<div class="box-header with-border col-md-offset-3 col-md-6">
		<table  class="table table-bordered ">
			<thead>
			<tr>
				<th scope="col">Shift </th>
				<th scope="col">Class</th>
			</tr>
			</thead>
			<tbody>
			<tr>

				<td>

					<select   id="shiftId" class="form-control select2">
						<option value="" >Select shift </option>
						<?php if(isset($shifts)):
							foreach ($shifts as $class):
								?>
			<option value="<?php echo $class->shift_id;?>"><?php echo $class->shift_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first shift </option>
						<?php endif;?>
					</select>
				</td>

				<td>

					<select   id="classId" class="form-control select2">
						<option value="" >Select class  </option>
						<?php if(isset($classes)):
							foreach ($classes as $examSession):
								?>
			<option value="<?php echo $examSession->classreg_id;?>"><?php echo $examSession->classreg_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first class </option>
						<?php endif;?>
					</select>

				</td>


			</tr>

			</tbody>
		</table>
	</div>


	<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
		<h4>Shift :<span id="dateShow1"></span></h4>
		<h4>Class :<span id="dateShow2"></span></h4>
	</div>

	<div class="box-body">
		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
<!--				<th>ClassShiftSectionName</th>-->
				<th>Shift</th>

				<th>Class</th>
				<th>Section</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($shiftClassSectionRelations)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($shiftClassSectionRelations as $shiftClassSectionRelation):

					?>
					<tr>
						<td><?php echo $count; ?></td>
<!--						<td>--><?php //echo $shiftClassSectionRelation->shift_classreg_section_name; ?><!--</td>-->
						<?php foreach ($shifts as $shift) : if ($shift->shift_id == $shiftClassSectionRelation->shift_id): ?>
							<td><?php echo $shift->shift_name; ?></td>
						<?php endif;endforeach; ?>

						<?php foreach ($classes as $class) : if ($class->classreg_id == $shiftClassSectionRelation->classreg_id): ?>
							<td><?php echo $class->classreg_name; ?></td>
						<?php endif;endforeach; ?>



						<?php foreach ($sections as $section) : if ($section->section_id == $shiftClassSectionRelation->section_id): ?>
							<td><?php echo $section->section_name; ?></td>
						<?php endif;endforeach; ?>


<!--						<td>-->
<!--							<a href="--><?php //echo base_url() ?><!--class-section-shift/--><?php //echo $shiftClassSectionRelation->shift_classreg_section_id; ?><!--"-->
<!--							<span class="glyphicon glyphicon-edit btn btn-success"></span>-->
<!--							</a>-->
<!--							<a href="--><?php //echo base_url() ?><!--shift-class-delete/--><?php //echo $shiftClassSectionRelation->shift_classreg_section_id; ?><!--"-->
<!--							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">-->
<!--								<span class="glyphicon glyphicon-trash btn btn-danger"></span>-->
<!--							</a>-->
<!---->
<!---->
<!--						</td>-->

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>

<script>


	$("#shiftId,#classId").change(function () {
		var dateId1 = $("#classId option:selected").text();
		var dateId2 = $("#shiftId option:selected").text();
		$("#resultShow").show();
		$("#dateShow1").text(dateId2);
		$("#dateShow2").text(dateId1);
	});


	$("#classId").change(function () {
		var shift_id=$("#shiftId").val();
		var class_id=$("#classId").val();
		$.ajax({
			type: "POST",
			data: {shift_id: shift_id,class_id:class_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/ShiftClassRelationController/shiftClassSelection',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['shift_name']+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['section_name']+'</td>'+
						'</tr>';
					str1=str1+str;

				});


				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>
