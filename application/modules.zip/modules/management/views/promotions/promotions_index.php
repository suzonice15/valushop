<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>teacher-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped table-responsive ">
			<thead>
			<tr>
				<th>Serial</th>
				<th>Picture</th>
				<th>TeacherName</th>
				<th>Address</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Nid</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($teachers)):

				$count = sizeof($teachers);
				//var_dump($count);exit();
				foreach ($teachers as $teacher):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php
							if(!empty($teacher->teacher_picture_path)):
							?>
							<img width="70" height="50" src="<?php echo base_url();echo $teacher->teacher_picture_path; ?>"/>
							<?php
							else:
							?>
							<img width="70" height="50"  src="<?php echo base_url() ?>uploads/teachers/teacher.png"/>
							<?php endif;
							?></td>
						<td><?php echo $teacher->teacher_full_name; ?></td>
						<td><?php echo $teacher->teacher_address; ?></td>
						<td><?php echo $teacher->teacher_email; ?></td>
						<td><?php echo $teacher->teacher_contact_no; ?></td>
						<td><?php echo $teacher->teacher_nid; ?></td>
						<td>
							<a title="profile" href="<?php echo base_url() ?>teacher-view/<?php echo $teacher->teacher_id;  ?>"
							<span class="glyphicon glyphicon-user btn btn-primary"></span>
							</a>
							<a title="edit" href="<?php echo base_url() ?>teacher-edit/<?php echo $teacher->teacher_id;  ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a title="delete" href="<?php echo base_url() ?>teacher-delete/<?php echo $teacher->teacher_id;  ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>
							<a title="subject" href="<?php echo base_url() ?>teacher-subject-multiple/<?php echo $teacher->teacher_id;  ?>"
							<span class="glyphicon glyphicon-plus-sign btn btn-primary"></span>Subjects
							</a>

						</td>

					</tr>

					<?php
					$count--;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
