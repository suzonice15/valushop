<div class="col-md-offset-0 col-md-12">
<div class="table-responsive">
<table class="table table-bordered ">
	<thead>
	<tr>
		<th scope="col">From Class</th>
		<th scope="col">From Section</th>
		<th scope="col">Transfer To Class</th>
		<th scope="col">Transfer To Session</th>
	</tr>
	</thead>
	<tbody>
	<tr>

		<td>

			<select  required name="classreg_id" class="form-control select2" id="classreg_id" class="form-control">
				<option value="">Select Class Name</option>
				<?php foreach ($classes as $class): ?>
					<option value="<?php echo $class->classreg_id ?>"><?php echo $class->classreg_name; ?>
					</option>
				<?php endforeach; ?>
			</select>

		</td>
		<td>

			<select  name="section_id" class="form-control select2" id="section_id" class="form-control">
				<option value="">Select Section Name</option>
				<?php foreach ($sections as $section): ?>
					<option value="<?php echo $section->section_id ?>"><?php echo $section->section_name; ?>
					</option>
				<?php endforeach; ?>
			</select>
		</td>
		<td>

			<select required name="class_section_id" class="form-control select2" id="class_section_id" class="form-control">
				<option value="">Select Class and Section Name</option>
				<?php foreach ($classSections as $classSection): ?>
					<option value="<?php echo $classSection->classreg_section_id ?>"><?php echo $classSection->classreg_section_name; ?>
					</option>
				<?php endforeach; ?>
			</select>
		</td>
		<td>

			<select required name="session_id" class="form-control select2" id="session_id" class="form-control">
				<option value="">Select Session Name</option>
				<?php foreach ($sessions as $session): ?>
					<option value="<?php echo $session->session_id; ?>"><?php echo $session->session_name; ?>
					</option>
				<?php endforeach; ?>
			</select>
		</td>


	</tr>

	</tbody>
</table>
	<div class="row">
	<div  style="display:none"  id="resultShow1" class="col-md-offset-1 col-md-3 bg-info">
		<h4>From </h4>
		<h4>Class :<span id="dateShow1"></span></h4>
		<h4>Section :<span id="dateShow2"></span></h4>

	</div>
		<div  style="display:none"  id="resultShow2" class="col-md-offset-2 col-md-3 bg-success">

			<h4>To </h4>
			<h4>Class :<span id="dateShow3"></span></h4>
			<h4>Session :<span id="dateShow4"></span></h4>

		</div>
	</div>
</div>






<div class="table-responsive col-md-offset-1 col-md-8">
    <table id="studentList" class="table table-bordered  ">
        <thead>
        <tr>
            <th scope="col"> <input disabled type="checkbox" class="check" id="checkAll"	/>
                All</th>
            <th scope="col">Student Name</th>
            <th scope="col">Roll</th>

        </tr>
        </thead>
        <tbody>



        </tbody>
    </table>
</div>
</div>


