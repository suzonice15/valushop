<div class="box box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><?php echo $title; ?></h3>


	</div>
	<div class="box-body">
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-7">
				<table class="table ">
					<tbody>
					<tr>
						<td style="padding: 33px 15px;">Teacher picture</td>
						<td > <?php
							if (!empty($teacher->teacher_picture_path)>0) {
								?>
								<img width="80" height="80"  src="<?php echo base_url(); ?><?php echo $teacher->teacher_picture_path; ?>"/>
								<?php
							} else {
								?>
								<img width="80" height="80" src="<?php echo base_url(); ?>/uploads/teachers/teacher.png"/>
							<?php } ?>

						</td>
					</tr>

					<tr>
						<td>Teacher Name</td>
						<td> <?php echo $teacher->teacher_full_name; ?></td>
					</tr>
					<tr>
						<td>Teacher mobile</td>
						<td> <?php echo $teacher->teacher_contact_no; ?></td>
					</tr>
					<tr>
						<td>Teacher address</td>
						<td> <?php echo $teacher->teacher_address; ?></td>
					</tr>
					<tr>
						<td>Teacher's email</td>
						<td> <?php echo $teacher->teacher_email; ?></td>
					</tr>

					<tr>
						<td>
							Teacher nid
						</td>
						<td> <?php echo $teacher->teacher_nid; ?></td>
					</tr>
					<tr>
						<td>Gender </td>
						<td> <?php echo $teacher->teacher_sex; ?></td>
					</tr>
					<tr>
						<td>Blood Group </td>
						<td> <?php echo $teacher->teacher_blood_group; ?></td>
					</tr>
					<tr>
						<td>Religion </td>
						<td> <?php echo $teacher->teacher_religion; ?></td>
					</tr>
					<tr>
						<td><a class="btn btn-info pull-left" href="<?php echo base_url(); ?>teacher-list">Back</a> </td>
						<td> </td>
					</tr>

					</tbody>

				</table>
			</div>


		</div>
	</div>


</div>
