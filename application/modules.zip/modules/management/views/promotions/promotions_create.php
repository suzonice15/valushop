<div class="col-md-offset-0 col-md-12">

	<div class="box box-success ">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">


			<form id="formId" action="<?php echo base_url(); ?>promotion-transfer" class="form-horizontal" method="post"
				  enctype="multipart/form-data">
				<span style="text-align:center;color:red"><?php echo validation_errors(); ?></span>
				<?php $this->load->view('promotions_form'); ?>

		</div>

		<div class="box-footer">
			<input type="submit" id="" class="btn btn-success pull-right" value="Save"/>
			<a class="btn btn-danger " href="<?php echo base_url(); ?>teacher-list">Cancel</a>

		</div>
		</form>
	</div>
</div>


<script>

	$("#classreg_id,#section_id").change(function () {

		var classreg_id = $("#classreg_id option:selected").text();
		var section_id = $("#section_id option:selected").text();

		$("#resultShow1").show();
		$("#dateShow1").text(classreg_id);
		$("#dateShow2").text(section_id);

	});
	$("#class_section_id,#session_id").change(function () {


		var class_section_id = $("#class_section_id option:selected").text();
		var session_id = $("#session_id option:selected").text();
		$("#resultShow2").show();

		$("#dateShow3").text(class_section_id);
		$("#dateShow4").text(session_id);
	});
	$(function () {

		$("#checkAll").change(function () {

			if ($(this).is(":checked")) {
				$(".check").prop('checked', true);
				var classSectionName = $("#class_section_id option:selected").text();
				$(".checkAllStudent").each(function (detailRowKey, detailRowValue) {

					var studentName = $("#student_name_" + detailRowKey).html();
					$("#student_class_section_" + detailRowKey).val(studentName + '-' + classSectionName);
				});
			} else {

				$(".check").prop('checked', false);
				$(".checkAllStudent").each(function (detailRowKey, detailRowValue) {

					var studentName = $("#student_name_" + detailRowKey).html();
					$("#student_class_section_" + detailRowKey).val("");


				});

			}
		});
		$("#session_id").change(function () {

			$(".check").prop('disabled', false);

		});


		$(document).on('click change ', '.check', function () {


			if ($(this).is(":checked")) {

				var student_id = this.id;
				var id = student_id.split("d_");
				var studentName = $("#student_name_" + id[1]).text();
				var classSectionName = $("#class_section_id option:selected").text();
				$("#student_class_section_" + id[1]).val(studentName + '-' + classSectionName);


			} else {
				var student_id = this.id;
				var id = student_id.split("d_");
				var chec = $("#student_class_section_" + id[1]).val("");


			}

		});

		$("#classreg_id,#section_id").change(function () {

			var classreg_id = $('#classreg_id').val();
			var section_id = $('#section_id').val();
			if (section_id.length == 0) {
				section_id = 0;
			}

			$.ajax({
				type: "POST",
				data: {section_id: section_id, classreg_id: classreg_id},
				dataType: "json",
				url: '<?php echo base_url();?>Management/PromotionsController/StudentSelection',
				success: function (results) {
					var str = "";
					var str1 = "";
					$.each(results, function (key, result) {
						str = '<tr>' +
							'<td><input  type="checkbox"  disabled class="check" id="student_id_' + key + '" name="student_id[]" value="' + result['student_id'] + '"	/>	</td>' +
							'<td class="checkAllStudent" id="student_name_' + key + '" >' + result['student_name'] + '</td>' + '<input type="hidden" name="student_class_section_name[]" id="student_class_section_' + key + '" value="" /><td><input type="text" class="form-controll" name="student_roll[]" id="student_roll' + key + '" value=""></td>'+
							'</tr>';
						str1 = str1 + str;
					});
					$("#studentList tbody").empty();
					$("#studentList tbody").append(str1);
				}
			});
		});
	});


	function StudentSelection() {

		// return false;
	}


	function StudentTransfer() {
		var classreg_id = $('#classreg_id').val();
		var section_id = $('#section_id').val();

		$.ajax({
			type: "POST",
			data: {section_id: section_id, classreg_id: classreg_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/PromotionsController/StudentTransfer',
			success: function (results) {

				var str = "";
				$.each(results, function (key, result) {
					str = '<tr>' +
						'<td><input  type="checkbox" class="check" id="student_id_' + key + '" name="student_id[]" value="' + result['student_id'] + '"	/>	</td>' +
						'<td>' + result['student_name'] + '</td>' +
						'</tr>';
					$("#classreg_id").val("");
					$("#section_id").val("");
					$("#studentList tbody").append(str);

				});

			}

		});
		// return false;
	}

</script>



