
<div class="form-group">
<!--	<label for="shiftName" class="col-md-4 control-label">Student ,  Class and Section Name:</label>-->

	<div class="col-md-6">

		<input  type="text" readonly name="student_classreg_section_name" id="student_class_name" placeholder=" Student  and Class Namee" value="<?php if (isset($studentClassRelation)) echo $studentClassRelation->student_classreg_section_name; ?>" class="form-control "/>
	</div>
</div>



<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class and Section Name:</label>

	<div class="col-sm-6">
		<select required name="classreg_section_id" id="classreg_section_id" class="form-control select2 ">
			<option value="">Select class and section name</option>
			<?php if (isset($classSectionRelations)):
				foreach ($classSectionRelations as $classSectionRelation):

					?>
					<option <?php if (isset($studentClassRelation)) : if ($studentClassRelation->classreg_section_id == $classSectionRelation->classreg_section_id): echo 'selected'; else : echo '';endif;endif; ?>
						value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class and section name</option>
			<?php endif; ?>
		</select>
	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Session Name</label>

	<div class="col-sm-6">
		<select required name="session_id" id="session_id" class="form-control select2 ">
			<option value="">Select session name</option>
			<?php if (isset($sessions)):
				foreach ($sessions as $session):

					?>
					<option
						value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first session name</option>
			<?php endif; ?>
		</select>

	</div>
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Student Name:</label>

	<div class="col-sm-6">

		<select required name="student_id" id="student_id" class="form-control select2">
			<option value="">Select student name</option>
			<?php

		//	var_dump($students);exit();
			if (isset($students)):
				foreach ($students as $student):


					?>
					<option <?php if (isset($studentClassRelation->student_id)): if ($studentClassRelation->student_id == $student->student_id)  : echo 'selected'; else : endif; endif; ?>
						value="<?php echo $student->student_id;?>" > <?php echo $student->student_name ;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first student name</option>
			<?php endif; ?>
		</select>
		<input type="hidden" name="student_classreg_section_id"
			   value="<?php if (isset($studentClassRelation)) echo $studentClassRelation->student_classreg_section_id; ?>">

	</div>
</div>



<script>


	$("#classreg_section_id , #student_id").change(function () {
		var classreg_section_id = $("#classreg_section_id option:selected ").text();
		var student_id = $("#student_id option:selected ").text();
		var studentClassSection= classreg_section_id + '-' + student_id;
		$("#student_class_name").val(studentClassSection);
	});


</script>
