
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box  ">
		<div class="box-header with-border">
			<div class="row">
				<div    class="col-md-offset-3 col-md-4 bg-success">
					<h4>Class :<b><?php
						if(isset($studentClassSectionRelations[0])){
							echo $studentClassSectionRelations[0]->classreg_name;
						}


						?>
						</b>

					</h4>
					<h4>Section :<b><?php if(isset($studentClassSectionRelations[0])){
							echo $studentClassSectionRelations[0]->section_name;} ?>
							</b> </h4>
					<h4>Session :<b> <?php if(isset($studentClassSectionRelations[0])){
							echo $studentClassSectionRelations[0]->session_name;
					}
							?>
							</b> </h4>
					<h4>Total :<b><?php if(isset($total)) echo $total; ?></b> </h4>
				</div>
				<div class="col-md-4">
					<a  onclick="window.print()" class="btn btn-info btn-lg">
						<span  class="glyphicon glyphicon-print"></span> Print
					</a>

				</div>
			</div>
		</div>

		<div class="table-responsive">
			<table  class="table table-bordered table-striped">
				<thead>
				<tr>
					<th>Serial</th>
					<!--				<th>StudentClassSectionName </th>-->

					<th>Class</th>
					<th>Section</th>
					<th>Student</th>
					<th>Gerdian</th>
					<th>Contact number</th>
					<th>Session</th>
					<!--				<th>Action</th>-->
				</tr>
				</thead>
				<tbody>
				<?php if (isset($studentClassSectionRelations)):

					$count = 1;
					//var_dump($count);exit();
					foreach ($studentClassSectionRelations as $studentClassSectionRelation):

						?>
						<tr>
							<td><?php echo $count; ?></td>
							<!--						<td>--><?php //echo $studentClassSectionRelation->student_classreg_section_name; ?><!--</td>-->


							<?php foreach($classes as $class):
								if($class->classreg_id==$studentClassSectionRelation->classreg_id): ?>
									<td><?php echo $class->classreg_name; ?></td>
								<?php endif;endforeach;?>
							<?php foreach($sections as $section):
								if($section->section_id==$studentClassSectionRelation->section_id): ?>
									<td><?php echo $section->section_name; ?></td>
								<?php endif;endforeach;?>

							<?php foreach($students as $student):
								if($student->student_id==$studentClassSectionRelation->student_id): ?>
									<td><?php echo $student->student_name; ?></td>
								<?php endif;endforeach;?>
							<?php foreach($students as $student):
								if($student->student_id==$studentClassSectionRelation->student_id): ?>
									<td><?php echo $student->student_father_name; ?></td>
								<?php endif;endforeach;?>

							<?php foreach($students as $student):
								if($student->student_id==$studentClassSectionRelation->student_id): ?>
									<td><?php echo $student->student_phone; ?></td>
								<?php endif;endforeach;?>


							<?php foreach($sessions as $session):
								if($session->session_id==$studentClassSectionRelation->session_id): ?>
									<td><?php echo $session->session_name; ?></td>
								<?php endif;endforeach;?>


						</tr>

						<?php
						$count++;
					endforeach;
				endif; ?>

				</tbody>

			</table>
		</div>
	</div>
</div>
