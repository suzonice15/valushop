<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<table class="table table-bordered">
			<thead>
			<tr>
				<th scope="col">Class</th>
				<th scope="col">Section</th>
				<th scope="col">Session</th>
				<th scope="col"></th>
			</tr>
			</thead>
			<tbody>
			<form action="<?php echo base_url()?>student-report" method="post">

			<tr>
				<td>
					<select required name="classreg_id" id="classId" class="form-control select2">
						<option value="" >Select Class </option>
						<?php if(isset($classes)):
							foreach ($classes as $class):
								?>
								<option value="<?php echo $class->classreg_id;?>"><?php echo $class->classreg_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first class name</option>
						<?php endif;?>
					</select>
				</td>
				<td>

					<select required  name="section_id"  id="sectionId" class="form-control select2">
						<option value="" >Select section </option>
						<?php if(isset($sections)):
							foreach ($sections as $section):
								?>
								<option value="<?php echo $section->section_id;?>"><?php echo $section->section_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first section</option>
						<?php endif;?>
					</select>

				</td>
				<td>
					<select required name="session_id" id="sessionId" class="form-control select2">
						<option value="" >Select session </option>
						<?php if(isset($sessions)):
							foreach ($sessions as $session):
								?>
								<option value="<?php echo $session->session_id;?>"><?php echo $session->session_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first session</option>
						<?php endif;?>
					</select>

				</td>
				<td> <input type="submit" class="btn-success" value="Print"/></td>
			</tr>
			</form>

			</tbody>
		</table>



		<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
			<h4>Class   :<span id="ClassIdData"></h4>
			<h4>Section :<span id="dateShow1"></span></h4>
			<h4>Session  :<span id="dateShow2"></span></h4>
			<h4>Total  :<span id="totalStudent"></span></h4>
		</div>




	</div>
	<div class="box-body">
		<div class="table-responsive">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
<!--				<th>StudentClassSectionName </th>-->

				<th>Class</th>
				<th>Section</th>
				<th>Student</th>
				<th>Gerdian</th>
				<th>Contact number</th>
				<th>Session</th>
<!--				<th>Action</th>-->
			</tr>
			</thead>
			<tbody>
			<?php if (isset($studentClassSectionRelations)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($studentClassSectionRelations as $studentClassSectionRelation):

					?>
					<tr>
						<td><?php echo $count; ?></td>
<!--						<td>--><?php //echo $studentClassSectionRelation->student_classreg_section_name; ?><!--</td>-->


						<?php foreach($classes as $class):
							if($class->classreg_id==$studentClassSectionRelation->classreg_id): ?>
								<td><?php echo $class->classreg_name; ?></td>
							<?php endif;endforeach;?>
						<?php foreach($sections as $section):
							if($section->section_id==$studentClassSectionRelation->section_id): ?>
								<td><?php echo $section->section_name; ?></td>
							<?php endif;endforeach;?>

						<?php foreach($students as $student):
							if($student->student_id==$studentClassSectionRelation->student_id): ?>
								<td><?php echo $student->student_name; ?></td>
							<?php endif;endforeach;?>
						<?php foreach($students as $student):
							if($student->student_id==$studentClassSectionRelation->student_id): ?>
								<td><?php echo $student->student_father_name; ?></td>
							<?php endif;endforeach;?>

						<?php foreach($students as $student):
							if($student->student_id==$studentClassSectionRelation->student_id): ?>
								<td><?php echo $student->student_phone; ?></td>
							<?php endif;endforeach;?>


						<?php foreach($sessions as $session):
							if($session->session_id==$studentClassSectionRelation->session_id): ?>
								<td><?php echo $session->session_name; ?></td>
							<?php endif;endforeach;?>


					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>
	</div>

</div>
</div>


<script>

	$("#classId").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var classId = $("#classId option:selected").text();
		var sectionId = $("#sectionId option:selected").text();
		var sessionId = $("#sessionId option:selected").text();
		$("#resultShow").show();
		$("#ClassIdData").text(classId);
		$("#dateShow1").text(sectionId);
		$("#dateShow2").text(sessionId);
	});

	$("#classId").change(function () {
		var classId=$("#classId").val();
		$.ajax({
			type: "POST",
			data: {classreg_id: classId},
			dataType: "json",
			url: '<?php echo base_url();?>management/StudentClassRelationController/classData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['section_name']+'</td>'+
						'<td>'+result['student_name']+'</td>'+
						'<td>'+result['student_father_name']+'</td>'+

						'<td>'+result['student_phone']+'</td>'+
						'<td>'+result['session_name']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#sectionId").change(function () {
		var section_id=$("#sectionId").val();
		var classreg_id=$("#classId").val();
		$.ajax({
			type: "POST",
			data: {classreg_id:classreg_id,section_id:section_id},
			dataType: "json",
			url: '<?php echo base_url();?>management/StudentClassRelationController/sectionData',
			success: function (results) {
				$("#totalStudent").text(results['total']);
				var str = "";
				var str1 = "";
				$.each(results['students'], function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['section_name']+'</td>'+
						'<td>'+result['student_name']+'</td>'+
						'<td>'+result['student_father_name']+'</td>'+

						'<td>'+result['student_phone']+'</td>'+
						'<td>'+result['session_name']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});


	$("#sessionId").change(function () {
		var section_id=$("#sectionId").val();
		var classreg_id=$("#classId").val();
		var session_id=$("#sessionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_id:classreg_id,section_id:section_id,session_id:session_id},
			dataType: "json",
			url: '<?php echo base_url();?>management/StudentClassRelationController/sessionData',
			success: function (results) {
				$("#totalStudent").text(results['total']);
				var str = "";
				var str1 = "";
				$.each(results['subjects'], function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['section_name']+'</td>'+
						'<td>'+result['student_name']+'</td>'+
						'<td>'+result['student_father_name']+'</td>'+

						'<td>'+result['student_phone']+'</td>'+
						'<td>'+result['session_name']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});






</script>




