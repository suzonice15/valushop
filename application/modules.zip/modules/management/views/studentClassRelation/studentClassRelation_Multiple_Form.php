<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url()?>student-class-section-multiple-save"
				  class="form-horizontal" method="post">
<div class="table-responsive">
				<table class="table table-bordered ">
					<thead>
					<tr>

						<th scope="col" width="200">
							Class and section name
						</th>
						<th scope="col" width="200">Session Name</th>
						<th scope="col"></th>
					</tr>
					</thead>
					<tbody>
					<tr>

						<td>
							<select required name="classreg_section_id" id="classregsectionId" class="form-control select2">
								<?php
								if($classSections):
									?>
									<option value="">Select class and section name</option>
									<?php
									foreach($classSections as $classSection):?>
										<option

											value="<?php echo $classSection->classreg_section_id;?>">


											<?php echo $classSection->classreg_section_name;?></option>

									<?php endforeach;

								else : ?>
									<option value="">There are no class data registration please</option>
								<?php endif; ?>
							</select>

						</td>
						<td>

							<select  name="session_id" id="sessionId" class="form-control select2 ">
								<option value="">Select session name</option>
								<?php if (isset($sessions)):
									foreach ($sessions as $session):
										?>
										<option		value="<?php echo $session->session_id;?>"> <?php echo $session->session_name;?> 									</option>
									<?php endforeach; else : ?>
									<option value="">Registration first session name</option>
								<?php endif; ?>
							</select>
						</td>

					</tr>

					</tbody>
				</table>

	<div  style="display:none"  id="resultShow" class="col-md-offset-1 col-md-4 bg-success">
		<h4>Class &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow1"></span></h4>
		<h4>Session :<span id="dateShow2"></span></h4>
	</div>

</div>




				<table id="studentList" class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"> <input disabled type="checkbox" class="check" id="checkAll"	/>
							All</th>
						<th scope="col">Student Name</th>

					</tr>
					</thead>
					<tbody>



					</tbody>
				</table>

				<div class="box-footer">
					<input type="submit"  class="btn btn-success pull-right" value="Save"/>
					<a class="btn btn-danger " href="<?php echo base_url(); ?>class-section-list">Cancel</a>

				</div>
			</form>
		</div>
	</div>
</div>

<script>

	$("#classregsectionId,#sessionId").change(function () {

		var classSectionName = $("#classregsectionId option:selected").text();
		var session_id = $("#sessionId option:selected").text();
		$("#resultShow").show();
		$("#dateShow1").text(classSectionName);
		$("#dateShow2").text(session_id);
	});
	$(function () {
		$("#checkAll").change(function () {

			if ($(this).is(":checked")) {
				$(".check").prop('checked', true);
				var classSectionName = $("#classregsectionId option:selected").text();
				$(".checkAllStudent").each(function (detailRowKey, detailRowValue) {

					var studentName = $("#student_name_"+detailRowKey).text();
					$("#student_class_section_"+detailRowKey).val(studentName.trim()+'-'+classSectionName.trim());


				});

			}
			else {

				$(".check").prop('checked', false);
				$(".checkAllStudent").each(function (detailRowKey, detailRowValue) {

					var studentName = $("#student_name_"+detailRowKey).text();
					$("#student_class_section_"+detailRowKey).val("");


				});

			}
		});

		$(document).on('click change ', '.check', function () {


			if ($(this).is(":checked")) {

				var student_id = this.id;
				var id = student_id.split("d_");
				var studentName = $("#student_name_" + id[1]).text();
				var classSectionName = $("#classregsectionId option:selected").text();

				$("#student_class_section_" + id[1]).val(studentName.trim()+'-'+classSectionName.trim());


			} else {
				var student_id = this.id;
				var id = student_id.split("d_");
				var chec=$("#student_class_section_" + id[1]).val("");


			}

		});

		 $("#sessionId").change(function () {
			 $(".check").prop('disabled', false);
			 var classreg_section_id = $('#classregsectionId').val();
			 var session_id = $('#sessionId').val();
			 $.ajax({
				 type: "POST",
				 data: {session_id: session_id, classreg_section_id: classreg_section_id},
				 dataType: "json",
				 url: '<?php echo base_url();?>Management/StudentClassRelationController/MultipleStudentSelection',
				 success: function (results) {
					 var str = "";
					 var str1 = "";
					 $.each(results, function (key, result) {
						 if(result['student_com_id']==result['student_id']) {
							 str = '<tr>' +
								 '<td><input  type="checkbox" checked  class="check" id="student_id_' + key + '" name="student_id[]" value="' + result['student_id'] + '"	/>	</td>' +
								 '<td class="checkAllStudent" id="student_name_' + key + '" >' + result['student_name'] + '</td>' + '<td><input type="text" name="student_classreg_section_name[]" id="student_class_section_' + key + '" value="' + result['student_classreg_section_name'] + '" /></td>' +
								 '</tr>';
						 }
						 else {

							 str = '<tr>' +
								 '<td><input  type="checkbox"   class="check" id="student_id_' + key + '" name="student_id[]" value="' + result['student_id'] + '"	/>	</td>' +
								 '<td class="checkAllStudent" id="student_name_' + key + '" >' + result['student_name'] + '</td>' + '<td><input type="text" name="student_classreg_section_name[]" id="student_class_section_' + key + '" value="" /></td>' +
								 '</tr>';

						 }
						 str1=str1+str;
					 });
					 $("#studentList tbody").empty();
					 $("#studentList tbody").append(str1);
				 }
			 });		});

	});



</script>
