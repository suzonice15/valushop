<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>student-class-section-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Class and Section Name</label>

					<div class="col-sm-8">
						<h4><label id="classSectionName" class="label label-success">
								<?php

								echo $studentRelations[0]->classreg_section_name;

								?></label></h4>

						<input type="hidden" name="classreg_section_id" id="classreg_section_id"
							   value="<?php echo $studentRelations[0]->classreg_section_id; ?>">


					</div>
				</div>


				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Session Name</label>

					<div class="col-sm-5">
						<select required name="session_id" id="sessionId" class="form-control select2 ">
							<option value="">Select session name</option>
							<?php if (isset($sessions)):
								foreach ($sessions as $session):

									?>
									<option
										value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first session name</option>
							<?php endif; ?>
						</select>

					</div>
				</div>


				<table id="studentList" class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Students Name</th>
					</tr>
					</thead>
					<tbody>

					<?php foreach ($students

								   as $student) { ?>
						<tr>
							<td>

								<input <?php
								foreach ($studentRelations as $studentRelation) {
									if ($studentRelation->student_id == $student->student_id) {
										echo 'checked';
									} else {
										echo '';
									}
								}

								?> type="checkbox" class="check"
								   id="student_id_<?php echo $student->student_id; ?>"
								   name="student_id[]" value="<?php echo $student->student_id; ?>"
								/>

							</td>
							<td>

								<label style="font-weight: normal"
									   for="student_id_<?php echo $student->student_id; ?>"><?php echo $student->student_name; ?></label>


								<input type="text" name="student_classreg_section_name[]" readonly
									   value="<?php
									   foreach ($studentRelations as $studentRelation) {
										   if ($studentRelation->student_id == $student->student_id) {
											   echo $studentRelation->student_classreg_section_name;
										   } else {
											   //  echo $studentRelation['student_classreg_name'];
										   }
									   }

									   ?>

"
									   id="student_classreg_name_<?php echo $student->student_id; ?>">


							</td>
						</tr>
						<?php

					} ?>
<!--					<tr>-->
<!--						<td>-->
<!--							<a class="btn btn-info pull-left"-->
<!--							   href="--><?php //echo base_url(); ?><!--class-section-list">Back</a>-->
<!---->
<!--						</td>-->
<!---->
<!--						<td>-->
<!--							<input type="submit" class="btn btn-success pull-right" value="Save"/>-->
<!---->
<!---->
<!--						</td>-->
<!---->
<!--					</tr>-->

					</tbody>
				</table>


				<div class="box-footer">
					<input type="submit"  class="btn btn-success pull-right" value="Save"/>
					<a class="btn btn-danger " href="<?php echo base_url(); ?>class-section-list">Cancel</a>

				</div>
			</form>
		</div>
	</div>
</div>

<script>

	$(function () {

$("#studentList").on('click','.check',function () {

		if (this.checked) {
			var label = $("#" + this.id).prop("labels");
			checkBoxText = $(label).text();
			classSectionName = $("#classSectionName").text();
			$("#student_classreg_name_" + this.value).val(classSectionName.trim() + "-" + checkBoxText.trim());

		} else {
			$("#student_classreg_name_" + this.value).val("");
		}

});

		$("#sessionId").change(function () {

			StudentSelection();
		});

	});

	function StudentSelection() {

		var classreg_section_id = $('#classreg_section_id').val();
		var session_id = $('#sessionId').val();


		$.ajax({
			type: "POST",
			data: {session_id: session_id, classreg_section_id: classreg_section_id},
			dataType: "json",

			url: '<?php echo base_url();?>Management/StudentClassRelationController/StudentSelection',
			success: function (results) {
				debugger;
				var str = "";
				var str2 = "";
				var str1 = "";
				$.each(results, function (key, result) {
					if (result['studentId'] == result['student_classId']) {
						str = '<tr>' + '<td> <input	type = "checkbox"	checked class="check" id ="student_id_' + result['student_id'] + '" name="student_id[]"	value="' + result['student_id'] + '" >' +
							'<td><label style="font-weight: normal" for="student_id_' + result['student_id'] + '">' + result['student_name'] + '</label><input type="text" name="student_classreg_section_name[]" readonly value="' + result['student_classreg_section_name'] + '" id="student_classreg_name_' + result['student_id'] + '"> ' + '</td>' + '</tr>';
					} else {
						str = '<tr>' + '<td> <input	type = "checkbox"	 class="check" id ="student_id_' + result['student_id'] + '" name="student_id[]"	value="' + result['student_id'] + '" >' +
							'<td><label style="font-weight: normal" for="student_id_' + result['student_id'] + '">' + result['student_name'] + '</label><input type="text" name="student_classreg_section_name[]" readonly value="' + result['student_classreg_section_name'] + '" id="student_classreg_name_' + result['student_id'] + '"> ' + '</td>' + '</tr>';


					}
					str1 = str1 + str;
					// str2 =+'<tr><td><a	class="btn btn-info pull-left"> Back </a>
					// 	< /td>
					// 	< td >
					// 	<input	type = "submit"	class="btn btn-success pull-right"	value = "Save" />
					// 	</td>< /tr>';

				});
				//str1=+ str2;

				$("#studentList tbody").empty();
				$("#studentList tbody").append(str1);
			}
		});
	}


</script>
