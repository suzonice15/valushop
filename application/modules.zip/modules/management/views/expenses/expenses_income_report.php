
<div class="col-md-offset-0 col-md-12">
	<div class="table table-responsive">
		<div class="box  box-success ">
			<div class="box-header with-border">
				<table class="table table-bordered hidden-print">
					<thead>
					<tr>
						<th scope="col">From</th>
						<th scope="col">To</th>
					</tr>
					</thead>
					<tbody>


					<form action="" method="post">
					<tr>
						<td>
							<div class="input-group date" >
								<input id="dateId1" name="dateId1" required type="text" class="form-control withoutFixedDate" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th" id="datepicker" ></span>
								</div>
							</div>

						</td>
						<td>
							<div class="input-group date" >
								<input id="dateId2" name="dateId2"  required type="text" class="form-control withoutFixedDate" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th" id="datepicker" ></span>
								</div>
							</div>

						</td>
						<td>

							<a onclick="window.print()" class="btn btn-info btn-lg">
								<span class="glyphicon glyphicon-print"></span> Print
							</a>
						</td>
					</tr>
					</form>
					</tbody>
				</table>

				<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
					<h4>From :<span id="dateShow1"></span></h4>
					<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow2"></span></h4>
					<h4>Profit &nbsp;:৳ <span id="profitId"></span></h4>
					<h4>Loss &nbsp;&nbsp;:৳ <span id="lossId"></span></h4>
				</div>



			</div>
			<div class="box-body">

				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>
						<th>Sl</th>
						<th>Income</th>
						<th>Expense</th>
						<th>profit   </th>
						<th>Loss   </th>
					</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
</div>



<script>

	function myprint() {
		window.print();
	}
	$("#dateId2").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();

		$("#resultShow").show();
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});

	$("#dateId2,#dateId1").change(function () {
		var dateId1=$("#dateId1").val();
		var dateId2=$("#dateId2").val();
		$.ajax({
			type: "POST",
			data: {dateId1:dateId1,dateId2:dateId2},
			dataType: "json",
			url: '<?php echo base_url();?>management/ExpenseController/incomeExpenseReport',
			success: function (results) {
				var str = "";
				var str1 = "";
					var key=1;
                $("#profitId").text(results.gain);
                $("#lossId").text(results.los);

                if(results['totalIncome']>=results['expense']) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + results['totalIncome'] + '</td>' +
							'<td>' + results['expense'] + '</td>' +
							'<td>' + results['gain'] + '</td>' +
							'<td></td>' +

							'</tr>';
					}

					else {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + results['totalIncome'] + '</td>' +
							'<td>' + results['expense'] + '</td>' +
							'<td></td>' +
							'<td>' + results['los'] +'</td>' +
							'</tr>';
					}
					str1=str1+str;

	

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});
</script>

