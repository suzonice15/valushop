
<div class="col-md-offset-0 col-md-12">
        <div class="box  box-success ">
            <div class="box-header with-border">

                <h3 class="box-title">
                    <a class="btn btn-info" href="<?php echo base_url();?>expenses-create"><i class="fa fa-plus-circle"></i>Add new</span></a>


                </h3>


            </div>
            <div class="box-body table-responsive">

                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Serial</th>
                        <th>Category   </th>
                        <th>Amount   </th>

                        <th>Date   </th>


                    </tr>
                    </thead>
                    <tbody>
                    <?php if (isset($expenses)):

                        $count = 0;
                        //var_dump($count);exit();
                        foreach ($expenses as $expense):

                            ?>
                            <tr>
                                <td><?php echo ++$count; ?></td>
                                <td><?php echo $expense->expense_category_name; ?></td>
                                <td><?php echo $expense->expense_amount; ?></td>

                                <td><?php echo date('d-m-Y ',strtotime($expense->expense_date)) ?></td>

<!---->
<!--                                <td>-->
<!--                                    <a href="--><?php //echo base_url() ?><!--expenses-edit/--><?php //echo $expense->expense_id; ?><!--"-->
<!--                                    <span class="glyphicon glyphicon-edit btn btn-success"></span>-->
<!--                                    </a>-->
<!--                                    <a href="--><?php //echo base_url() ?><!--expenses-delete/--><?php //echo $expense->expense_id; ?><!--"-->
<!--                                       onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">-->
<!--                                        <span class="glyphicon glyphicon-trash btn btn-danger"></span>-->
<!--                                    </a>-->
<!---->
<!---->
<!---->
<!--                                </td>-->

                            </tr>

                            <?php

                        endforeach;
                    endif; ?>

                    </tbody>

                </table>


            </div>

        </div>
    </div>

</div>
