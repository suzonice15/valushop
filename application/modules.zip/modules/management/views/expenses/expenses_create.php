<div class="col-md-offset-1 col-md-10">
	<div class="box box-success">
		<div class="box-header with-border">
			<h5 class="text-center"> ভান্ডারিয়া    সিদ্দিকিয়া  কামিল মাদ্রাসা </h5>
			<h6 class="text-center">পোস্ট মুকুন্দিয়া , রাজবাড়ী সদর ,রাজবাড়ী  </h6>
			<h6 class="text-center">মাদ্রাসার ব্যয়ের   রশিদ   </h6>
			<p ><b> রশিদ  নংঃ#<span id="invoiceId"></span></b></p>
			<p class="pull-right" ><b> তারিখ :<?php echo date('d-m-Y');?></b></p>
			<h1 class="text-center text-success"id="studentFeeResult" ></h1>


		</div>
		<div class="box-body">

			<form action="" class="form-inline" method="post">
            <?php $this->load->view('expenses_form'); ?>

		</div>

		<div class="box-footer">
			<center>
				<button class="btn btn-primary hidden-print" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
			</center>
			<input type="submit" id="save" class="btn btn-success pull-right" value="Save"/>
			<a class="btn btn-danger " href="<?php echo base_url();?>expenses-all">Cancel</a>

		</div>
		</form>
	</div>
</div>

<script>
	function myFunction() {
		window.print();
	}
	$(function () {

		$(document).on("input", ".numbers", function() {

			var sum = 0;
			$(".numbers").each(function(){
				sum += +$(this).val();
			});
			$(".total").val(sum);
		});


	});

	$(document).mousemove(function(){
		$.ajax({
			type: "POST",
			url: '<?php echo base_url();?>Management/ExpenseController/expenseSelectionData',
			success: function (results) {
				$("#invoiceId").text(results);
			}
		});
	});


	$("#save").click(function (e) {
		e.preventDefault();

		var  expense_category_id = new Array();
		$("input[name='expense_category_id']:checked").each(function() {
			expense_category_id.push($(this).val());
		});
		var invoice_amount = new Array();
		$(".numbers").each(function() {
			invoice_amount.push($(this).val());
		});
		var invoice_amount = invoice_amount.filter(Boolean);
		var expense_category_id = expense_category_id.filter(Boolean);

		if(expense_category_id.length==0){
			alert("select expense category");
		} else {

			$.ajax({
				type: "POST",
				data: {expense_category_id: expense_category_id, invoice_amount: invoice_amount},
				url: '<?php echo base_url();?>Management/ExpenseController/store',
				success: function (results) {
					alert(results);

				}
			});
		}
	});
</script>
