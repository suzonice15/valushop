

<table class="table table-bordered">
	<thead>
	<tr  >
		<th>বিবরণ</th>
		<th>টাকা</th>
	</tr>
	</thead>
	<tbody>
	<?php $i=0; if(isset($expenseCategories)): foreach ($expenseCategories as $expenseCategory):?>
		<tr>
			<td><?php  ?><input type="checkbox" name="expense_category_id" value="<?php echo $expenseCategory->expense_category_id;?>">
				<?php echo $expenseCategory->expense_category_name;?></td>
			<td><input type="text" name="invoice_amount" class="form-control numbers"  ></td>
		</tr>
	<?php endforeach; endif;?>
	<tr  >
		<td>মোট</td>
		<td><input id="" class="total form-control" type="text" ></td>
	</tr>

	</tbody>
</table>







