<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box">
		<div class="box-header with-border">
			<div class="row">
				<div class="col-md-offset-3 col-md-4 bg-success">
					<h5>Category :<?php
						if (isset($allCagegory) == 1) {
							echo $allCagegory;
						}  else {
							if (isset($expenses[0])) {
								echo $expenses[0]->expense_category_name;

							}
						}

						?>

					</h5>
					<h5>From :<b><?php echo date('F', strtotime($firstDate)); ?></b></h5>
					<h5>To :<b><?php echo date('F', strtotime($lastDate)); ?></b></h5>
					<h5>Total :<b><?php echo $totalAmount; ?></b></h5>
				</div>
				<div class="col-md-4">
					<a onclick="window.print()" class="btn btn-info btn-lg">
						<span class="glyphicon glyphicon-print"></span> Print
					</a>

				</div>
			</div>
		</div>

		<div  onload="window.print()" class="table-responsive">
			<table class="table table-bordered ">
				<thead>
				<tr>
					<th>Sl</th>
					<th>Category</th>
					<th>Amount</th>
					<th>Note</th>
					<th>Date</th>
				</tr>
				</thead>
				<tbody>


				<?php if (isset($expenses)):
					$i = 1;
					foreach ($expenses as $expense):
						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $expense->expense_category_name; ?></td>
							<td><?php echo $expense->expense_amount; ?></td>
							<td><?php echo $expense->expense_note; ?></td>
							<td><?php echo date('d-m-Y', strtotime($expense->expense_date)); ?></td>
						</tr>
						<?php
						$i++;
					endforeach;
				endif; ?>

				</tbody>
			</table>
		</div>
	</div>
</div>
