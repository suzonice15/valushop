
<?php

$this->load->model('MarkSheet');

?>
<div class="col-md-offset-1 col-md-10">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url() ?>marksheet" class="form-horizontal" method="post">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive hidden-print">
						<thead>
						<tr>
							<th scope="col"  >Class</th>
							<th scope="col"  >Examination</th>
							<th scope="col"  ></th>
							<th scope="col"  ></th>
						</tr>
						</thead>
						<tbody>
						<tr>
							<td>
								<select required name="classreg_section_id" id="classreg_section_id" class="form-control select2 ">
									<option value="">Select Class</option>
									<?php if (isset($classData)):
										foreach ($classData as $class):

											?>
											<option

			<?php  if(isset($classId)){ if($classId==$class->classreg_section_id) { echo 'selected="selected"';} else { echo '';}}  ?>
												value="<?php echo $class->classreg_section_id; ?>"> <?php echo $class->classreg_section_name; ?> </option>
										<?php endforeach; else : ?>
										<option value="">Registration first student name</option>
									<?php endif; ?>

								</select>
							</td>
							<td>
								<select required name="exam_session_id" id="exam_session_id" class="form-control select2 ">
									<option value="">Select Examination</option>
									<?php if (isset($examData)):
										foreach ($examData as $exam):

											?>
											<option

												<?php  if(isset($exam_Id)){ if($exam_Id==$exam->exam_session_id) { echo 'selected="selected"';} else { echo '';}}  ?>
												value="<?php echo $exam->exam_session_id; ?>"> <?php echo $exam->exam_session_name; ?> </option>
										<?php endforeach; else : ?>
										<option value="">Registration first session name</option>
									<?php endif; ?>

								</select>


							</td>
							<td>
								<center>
									<button class="btn btn-primary hidden-print" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
								</center>
							</td>
							<td><input type="submit"  class="btn btn-success pull-right" value="Submit"/></td>

						</tr>

						</tbody>
					</table>

					<div  style="display:one"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
						<h4>Class :<span id="dateShow1"></span></h4>
						<h4>Exam :&nbsp;&nbsp;<span id="dateShow2"></span></h4>
					</div>
				</div>

				<div class="table-responsive">

					<table class="table table-bordered">

						<tr>
							<th>Student Name</th>
							<?php
							if(isset($subjects)) {
							foreach ($subjects as $subject) { ?>
								<th><?php echo $subject->subject_name;?></th>
							<?php
							}
							}
							?>
							<th>Total Marks</th>
						</tr>


						<?php

						if(isset($exam_Id)) {
							$examid = $exam_Id;
						}
						if(isset($students)){
						foreach ($students as $student) {

							$studentName=$student->student_name;
							$student=$student->student_id;


							?>
							<tr>
								<td><?php echo $studentName; ?></td>
								<?php
								$count_marks = 0;
							if(isset($subjects)) {
								foreach ($subjects as $subject) { ?>
									<td>
										<?php
										$subject=$subject->subject_id;

										       $result = $this->MarkSheet->getMark($subject,$examid,$student);
										       if(isset($result)){
										       	  echo  $result->mark_obtained;
												   $count_marks += $result->mark_obtained;

										       }




										?>
									</td>
								<?php }  }?>
								<td><?php echo $count_marks; ?></td>
							</tr>
						<?php }
						}?>
					</table>
				</div>



		</form>
	</div>
</div>
	<script>

		$(function () {
			var classData=$("#classreg_section_id option:selected").text();
			var examData=$("#exam_session_id option:selected").text();
			$("#dateShow1").text(classData);
			$("#dateShow2").text(examData);
		});
		function myFunction() {
			window.print();
		}

</script>
