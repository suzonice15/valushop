<div class="col-md-offset-1 col-md-10">
    <div class="box box-success">
        <div class="box-header with-border">
            <h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


        </div>
        <div class="box-body">

            <form action="<?php echo base_url() ?>mark-save" class="form-horizontal" method="post">
                <?php $this->load->view('marksheet_form'); ?>


        </div>

        <div class="box-footer">
            <input type="submit" onclick=" window.print();
" class="btn btn-success pull-right" value="print"/>
            <a class="btn btn-danger " href="<?php echo base_url();?>mark-list">Cancel</a>

        </div>
        </form>
    </div>
</div>

<script>

	$("#student_id,#session_id").change(function () {

		var session_id = $("#session_id option:selected").text();
		var student_id = $("#student_id option:selected").text();
		$("#resultShow").show();
		$("#dateShow1").text(student_id);
		$("#dateShow2").text(session_id);
	});

	$(function () {
		$("#session_id").change(function () {
			var session_id = $('#session_id').val();
			var student_id = $('#student_id').val();
			$.ajax({
				type: "POST",
				data: {session_id: session_id, student_id: student_id},
				dataType: "json",
				url: '<?php echo base_url();?>student/StudentModuleController/studentMarksheet',
				success: function (results) {
					var str = "";
					var str1 = "";
					$.each(results['marksheet'], function (key, result) {

						str = '<tr>' +
							'<td> ' + result['subject_name'] + '</td>' +
							'<td>' + result['firs'] + '</td>' +
							'<td>' + result['sec'] + '</td>' +
							'<td>' + result['ann'] + '</td>' +
							'</tr>';


						str1=str1+str;

					});
					str1 =str1+'<tr><td>Total Subject='+results['subjectCounter']+'</td><td>'+results['first']+'</td><td>'+results['second']+'</td>' +
						'<td>'+results['final']+'</td></tr>'
					$("#studentList tbody").empty();
					$("#studentList tbody").append(str1);
				}
			});

		});

	});



</script>
