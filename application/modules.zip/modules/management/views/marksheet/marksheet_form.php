

<div class="table-responsive">
<table class="table table-bordered table-responsive">
	<thead>
	<tr>
		<th scope="col"  >Student Name</th>
		<th scope="col"  >Session Name</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td>
			<select required name="student_id" id="student_id" class="form-control select2 ">
				<option value="">Select student name</option>
				<?php if (isset($students)):
					foreach ($students as $student):

						?>
						<option value="<?php echo $student->student_id; ?>"> <?php echo $student->student_name; ?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first student name</option>
				<?php endif; ?>

			</select>
		</td>
		<td>
			<select required name="session" id="session_id" class="form-control select2 ">
				<option value="">Select Session Name</option>
				<?php if (isset($sessions)):
					foreach ($sessions as $session):

						?>
						<option value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first session name</option>
				<?php endif; ?>

			</select>


		</td>

	</tr>

	</tbody>
</table>

	<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
		<h4>Student :<span id="dateShow1"></span></h4>
		<h4>Session :&nbsp;&nbsp;<span id="dateShow2"></span></h4>
	</div>
</div>

<div class="table-responsive">

<table id="studentList" class="table table-bordered table-responsive">
	<thead>
	<tr>
		<th scope="col"> Subject Name</th>
		<th scope="col">First Examination</th>
		<th scope="col">Second Examination</th>
		<th scope="col">Annual examination</th>
	</tr>
	</thead>
	<tbody>

	</tbody>
</table>
</div>

