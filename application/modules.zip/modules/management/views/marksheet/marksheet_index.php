<div class="box  box-success">
	<div class="box-header with-border">

<!--        <h3 class="box-title"><a class="btn btn-success" href="--><?php //echo base_url();?><!--mark-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>-->


	</div>
	<div class="box-body">
		<div class="table-responsive">
			<table id="example1" class="table table-bordered table-striped table-responsive ">
				<thead>
				<tr>
					<th>Id</th>
					<th>StudentName</th>
					<th>ExamSessionName</th>
					<th>ClassName</th>
					<th>SubjectName</th>
					<th>Mark</th>
					<th>GradePoint</th>
					<th>Grade</th>

<!--					<th>Action</th>-->
				</tr>
				</thead>
				<tbody>
				<?php if (isset($marks)):

					$count = 1;
					//var_dump($count);exit();
					foreach ($marks as $mark):

						?>
						<tr>
							<td><?php echo $count; ?></td>

							<td><?php echo $mark->student_name.'-'.$mark->student_roll; ?></td>
							<td><?php echo $mark->exam_session_name; ?></td>
							<td><?php echo $mark->classreg_name; ?></td>
							<td><?php echo $mark->subject_name; ?></td>
							<td><?php echo $mark->mark_obtained; ?></td>
							<td><?php echo $mark->mark_grade_point; ?></td>
							<td><?php echo $mark->mark_gpa; ?></td>

<!--							<td>-->
<!--								<a href="--><?php //echo base_url() ?><!--mark-edit/--><?php //echo $mark->mark_id; ?><!--"-->
<!--								<span class="glyphicon glyphicon-edit btn btn-success"></span>-->
<!--								</a>-->
<!--								<a href="--><?php //echo base_url() ?><!--mark-delete/--><?php //echo $mark->mark_id; ?><!--"-->
<!--								   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">-->
<!--									<span class="glyphicon glyphicon-trash btn btn-danger"></span>-->
<!--								</a>-->
<!--							</td>-->

						</tr>

						<?php
						$count++;
					endforeach;
				endif; ?>

				</tbody>

			</table>


		</div>
	</div>

</div>
