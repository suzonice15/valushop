<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">
<?php if(isset($examSessionRelations[0])):?>
			<form id="add_thana_frm" action="<?php echo base_url() ?>exam-session-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="examName" class="col-sm-3 control-label">Session Name</label>

					<div class="col-sm-8">
						<h4><label id="examName" class="label label-success">
							<?php

							echo $examSessionRelations[0]->session_name;

							?></label></h4>

						<input type="hidden" name="session_id" value="<?php echo $examSessionRelations[0]->session_id; ?>">

					</div>
				</div>

				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Examination Name</th>


					</tr>
					</thead>
					<tbody>
					<?php foreach ($examinations

					as $examination) { ?>
<!--					<div class="checkbox">-->
					<tr>

						<td>
							<input <?php
							foreach ($examSessionRelations as $examSessionRelation) {
								if ($examSessionRelation->examination_id == $examination->examination_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="examination_id<?php echo $examination->examination_id; ?>"
							   name="examination_id[]" value="<?php echo $examination->examination_id; ?>"
							/>
						</td>
						<td>
							<label style="font-weight: normal"
								for="examination_id<?php echo $examination->examination_id; ?>"><?php echo $examination->examination_name; ?></label>

							<input type="text" name="exam_session_name[]" readonly
								   value="<?php
								   foreach ($examSessionRelations as $examSessionRelation) {
									   if ($examSessionRelation->examination_id == $examination->examination_id) {
										   echo $examSessionRelation->exam_session_name;
									   } else {
										   //  echo $examSessionRelation['teacher_shift_name'];
									   }
								   }

								   ?>

"
								   id="exam_session_name<?php echo $examination->examination_id; ?>">
						</td>
					</tr>
						<?php

						} ?>
						<tr>
							<td>
								<a class="btn btn-info pull-left "  href="<?php echo base_url(); ?>session-list ">Back</a>



							</td>

							<td><input type="submit" class="btn btn-success pull-right" value="Save"/ style="margin-right: 27px;"></td>

						</tr>
<!--					</div>-->
					</tbody>
				</table>



			</form>




<!--				<div class="form-group">-->
<!--					<label class="col-sm-3 control-label">Examination Name</label>-->
<!---->
<!--					<div class="col-md-9">-->
<!---->
<!--						--><?php //foreach ($examinations
//
//						as $examination) { ?>
<!--						<div class="checkbox">-->
<!--							<input --><?php
//							foreach ($examSessionRelations as $examSessionRelation) {
//								if ($examSessionRelation->examination_id == $examination->examination_id) {
//									echo 'checked';
//								} else {
//									echo '';
//								}
//							}
//
//							?><!-- type="checkbox" class="check"-->
<!--							   id="examination_id--><?php //echo $examination->examination_id; ?><!--"-->
<!--							   name="examination_id[]" value="--><?php //echo $examination->examination_id; ?><!--"-->
<!--							/>-->
<!--							<label-->
<!--								for="examination_id--><?php //echo $examination->examination_id; ?><!--">--><?php //echo $examination->examination_name; ?><!--</label>-->
<!--							<input type="hidden" name="exam_session_name[]" readonly-->
<!--								   value="--><?php
//								   foreach ($examSessionRelations as $examSessionRelation) {
//									   if ($examSessionRelation->examination_id == $examination->examination_id) {
//										   echo $examSessionRelation->exam_session_name;
//									   } else {
//										   //  echo $examSessionRelation['teacher_shift_name'];
//									   }
//								   }
//
//								   ?>
<!---->
<!--"-->
<!--								   id="exam_session_name--><?php //echo $examination->examination_id; ?><!--">-->
<!---->
<!---->
<!--							<br>-->
<!---->
<!--							--><?php
//
//							} ?>
<!--						</div>-->
<!--					</div>-->
<!--					</div>-->

<!--<div class="form-group">-->
<!--	<a class="btn btn-info pull-left " style="margin-left: -122px;" href="--><?php //echo base_url(); ?><!--session-list ">Back</a>-->
<!--						<input type="submit" class="btn btn-success pull-right" value="Save"/ style="margin-right: 27px;">-->
<!---->
<!---->
<!---->
<!--</div>-->

<?php endif;?>
		</div>


	<script>

		$(".check").click(function () {
			if (this.checked) {
				var label = $("#" + this.id).prop("labels");
				checkBoxText = $(label).text();
				examName = $("#examName").text();
				$("#exam_session_name" + this.value).val(examName.trim() + "-" + checkBoxText.trim());

			} else {
				$("#exam_session_name" + this.value).val("");


			}

		});

	</script>
