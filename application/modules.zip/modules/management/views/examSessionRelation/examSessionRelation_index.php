<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
<!--		<h3 class="box-title"><a class="btn btn-success" href="--><?php //echo base_url();?><!--exam-session-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>-->


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
<!--				<th>ExaminationSessionName </th>-->
				<th>Session</th>

				<th>Examination </th>
<!--				<th>Action</th>-->
			</tr>
			</thead>
			<tbody>
			<?php if (isset($examRelations)):

				$count = 0;
				//var_dump($count);exit();
				foreach ($examRelations as $exam):

					?>
					<tr>
						<td><?php echo $count; ?></td>
<!--						<td>--><?php //echo $exam->exam_session_name; ?><!--</td>-->
						<td><?php echo $exam->session_name; ?></td>

						<td><?php echo $exam->examination_name; ?></td>
<!--						<td>-->
<!--							<a href="--><?php //echo base_url() ?><!--exam-session-edit/--><?php //echo $exam->exam_session_id; ?><!--"-->
<!--							<span class="glyphicon glyphicon-edit btn btn-success"></span>-->
<!--							</a>-->
<!--							<a href="--><?php //echo base_url() ?><!--exam-session-delete/--><?php //echo $exam->exam_session_id; ?><!--"-->
<!--							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">-->
<!--							<span class="glyphicon glyphicon-trash btn btn-danger"></span>-->
<!--							</a>-->
<!---->
<!---->
<!---->
<!--						</td>-->

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
