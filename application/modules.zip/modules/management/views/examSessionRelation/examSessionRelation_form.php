<div class="form-group">
    <label for="shiftName" class="col-md-4 control-label">Examination and Session Name</label>

    <div class="col-md-6">

        <input required type="text" name="exam_session_name" id="exam_session_name" placeholder=" enter exam name" value="<?php if (isset($examRelations)) echo $examRelations->exam_session_name; ?>" class="form-control "/>
    </div>
</div>

<div class="form-group">
    <label for="shiftName" class="col-md-4 control-label">Examination Name</label>

    <div class="col-md-6">

        <select required name="examination_id" id="exam_id" class="form-control select2">
            <option value="">Select exam name</option>
            <?php if (isset($exams)):
                foreach ($exams as $exam):


                    ?>
                    <option <?php if (isset($examRelations->exam_id)): if ($examRelations->exam_id == $exam->examination_id)  : echo 'selected'; else : endif; endif; ?>
                            value="<?php echo $exam->examination_id; ?>"><?php echo $exam->examination_name; ?> </option>
                <?php endforeach; else : ?>
                <option value="">Registration first examination name</option>
            <?php endif; ?>
        </select>
        <input type="hidden" name="exam_session_id"
               value="<?php if (isset($examRelations)) echo $examRelations->exam_session_id; ?>">

    </div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-md-4 control-label">Session Name</label>

	<div class="col-md-6">
		<select required name="session_id" id="session_id"  class="form-control select2 ">
			<option value="">Select session name</option>
			<?php if (isset($sessions)):
				foreach ($sessions as $session):

					?>
					<option <?php if (isset($examRelations->session_id)) : if ($examRelations->session_id == $session->session_id): echo 'selected'; else : echo '';endif;endif; ?>
						value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first session name</option>
			<?php endif; ?>
		</select>
	</div>
</div>


<script>


	$("#exam_id , #session_id").change(function () {
		var session_id = $("#session_id option:selected ").text();
		var exam_id = $("#exam_id option:selected ").text();
		var comExamSession= exam_id + '-' + session_id;
		$("#exam_session_name").val(comExamSession);
	});


</script>



