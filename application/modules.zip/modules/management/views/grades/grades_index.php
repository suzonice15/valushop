<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-success" href="<?php echo base_url();?>grade-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
				<th>GradeName</th>
				<th>GradePoint</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($grades)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($grades as $grade):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $grade->grade_name; ?></td>
						<td><?php echo $grade->grade_point; ?></td>
						<td>
							<a href="<?php echo base_url() ?>grade-edit/<?php echo $grade->grade_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>grade-delete/<?php echo $grade->grade_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>



						</td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>
			<tfoot>
			<tr>
				<th>Serial</th>
				<th>GradeName</th>
				<th>GradePoint</th>
				<th>Action</th>
			</tr>
			</tfoot>
		</table>


	</div>

</div>
