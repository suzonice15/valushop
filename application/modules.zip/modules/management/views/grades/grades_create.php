<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url()?>grade-save" class="form-horizontal"  method="post" >
				<?php $this->load->view('grades_form');?>

		</div>

		<div class="box-footer">
			<input type="submit" class="btn btn-success" value="submit"/>
			<a class="btn btn-default pull-right" href="<?php echo base_url();?>grade-list">Cancel</a>

		</div>
		</form>
	</div>
