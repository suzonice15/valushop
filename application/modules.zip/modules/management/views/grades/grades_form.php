
<div class="form-group">
	<label for="grade_name" class="col-sm-3 control-label">Grade Name</label>

	<div class="col-sm-8">
		<input  required type="text" id="grade_name"  class="form-control" name="grade_name"
				value="<?php   if(isset($gradeData) ) echo $gradeData->grade_name;?>" placeholder="Enter Grade Name : A+">
		<input  type="hidden"  name="grade_id" 	value="<?php   if(isset($gradeData) ) echo $gradeData->grade_id;?>" >
	</div>
</div>

<div class="form-group">
	<label for="grade_point" class="col-sm-3 control-label">Grade Point</label>

	<div class="col-sm-8">
		<input  required type="text" id="grade_point"  class="form-control" name="grade_point"
				value="<?php   if(isset($gradeData) ) echo $gradeData->grade_point;?>" placeholder="Enter Grade Point : 5.00 ">
	</div>
</div>

