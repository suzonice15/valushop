<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<?php $userRole=$this->session->userdata('user_role');
		if($userRole==1):
		?>

		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>holiday-create"><i class="fa fa-plus-circle"></i>Add new</a></h3>

<?php endif; ?>
	</div>
	<div class="box-body">
	<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>SL</th>
				<th>Holiday</th>
				<th>Starting day</th>
				<th>Ending day</th>
				<?php $userRole=$this->session->userdata('user_role');
				if($userRole==1):
				?>
				<th>Action</th>
				<?php endif;?>
			</tr>
			</thead>
			<tbody>
			<?php if(isset($holidays)):

				$count=1;
				foreach($holidays as $holiday):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $holiday->event_title;?></td>
						<td><?php  echo date('d-M-Y',strtotime($holiday->event_start_date));?></td>
						<td><?php echo date('d-M-Y',strtotime($holiday->event_end_date));?></td>
						<?php $userRole=$this->session->userdata('user_role');
						if($userRole==1):
						?>
						<td>

							<a href="<?php echo base_url() ?>holiday-edit/<?php echo $holiday->event_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>holiday-delete/<?php echo $holiday->event_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>
						</td>
						<?php endif;?>

					</tr>

					<?php
					$count++;
				endforeach;
			endif;?>
			</tbody>
		</table>


	</div>
	</div>
	</div>

</div>
