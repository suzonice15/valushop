			<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Holiday name</label>
                        
						<div class="col-sm-6">
							<input required type="text" id="field-1"  class="form-control" name="event_title"   
							value="<?php   if(isset($event) ) echo $event->event_title;?>" placeholder="enter holiday name ">
				<input  type="hidden"  name="event_id" 	value="<?php   if(isset($event) ) echo $event->event_id;?>" >
						</div>
					</div>
					
					<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Holiday start date</label>
                        
						<div class="col-sm-6">
							<div class="input-group date" >
							<input  required type="text" name="event_start_date"  class="form-control withoutFixedDate"
							value="<?php   if(isset($event) ) echo date('d-m-Y',strtotime($event->event_start_date));?>" placeholder=" holiday start : 1-1-2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Holiday end date</label>

						<div class="col-sm-6">
							<div class="input-group date" >
								<input  required type="text" id="holiday_end_date_datepicker"  class="form-control withoutFixedDate" name="event_end_date"
										value="<?php   if(isset($event) )echo date('d-m-Y',strtotime($event->event_end_date));?>" placeholder="holiday end : 1/1/2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>

