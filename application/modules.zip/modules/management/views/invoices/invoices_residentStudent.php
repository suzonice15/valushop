
<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>
			<table class="table table-bordered  hidden-print">
				<thead>
				<tr>
					<th scope="col">Class</th>
					<th scope="col">Student</th>
					<th scope="col">From</th>
					<th scope="col">To</th>
				</tr>
				</thead>
				<tbody>
				<form action="<?php echo base_url()?>studentWiseFeePrint" method="post">
					<td>
						<select   required  id="classSectionId" name="classreg_section_id" class="form-control select2">
							<option value="" >Select Class </option>
							<?php if(isset($classsections)):
								foreach ($classsections as $class):
									?>
									<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class </option>
							<?php endif;?>
						</select>
					</td>

					<td>
						<select  required  id="studentId" name="student_id" class="form-control select2">
							<option value="" >Select class first </option>

						</select>
					</td>

					<td>
						<div class="input-group date" >
							<input id="dateId1" required type="text" class="form-control withoutFixedDate" name="attendance_date1"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td>
						<div class="input-group date" >
							<input id="dateId2" required type="text" class="form-control withoutFixedDate" name="attendance_date2"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td>
						<button class="btn btn-primary hidden-print" onclick="myprint()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
					</td>
				</form>
				</tr>
				</tbody>
			</table>


			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">

				<h4>class &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="ClaaShowId"></span></h4>
				<h4>Student :<span id="StudentShowId"></span></h4>
				<h4>From &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow1"></span></h4>
				<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow2"></span></h4>
			</div>



		</div>
		<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>
						<th>Sl</th>
						<th>Class</th>
						<th>Date</th>
						<th>Category</th>
						<th>Amount</th>
					</tr>
					</thead>
					<tbody>
					<!--					--><?php //if (isset($invoices)):
					//
					//						$count =1;
					//						foreach ($invoices as $invoice):
					//
					//							?>
					<!--							<tr>-->
					<!--								<td>--><?php //echo $count; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->student_name.'-'.$invoice->student_father_name; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->classreg_section_name; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->expense_category_name; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->invoice_amount; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->invoice_amount_paid; ?><!--</td>-->
					<!--								<td>--><?php //echo $invoice->invoice_due; ?><!--</td>-->
					<!--								--><?php //if($invoice->invoice_status==1):?>
					<!--									<td>-->
					<!--										<span class="btn-xs btn-success">Paid</span>-->
					<!--									</td>-->
					<!--								--><?php //elseif($invoice->invoice_status==2): ?>
					<!--									<td>-->
					<!--										<span class="btn-xs btn-info">Partial paid</span>-->
					<!--									</td>-->
					<!--								--><?php //else : ?>
					<!--									<td>-->
					<!--										<span class="btn-xs btn-danger">unpaid</span>-->
					<!--									</td>-->
					<!--								--><?php //endif; ?>
					<!--								<td>--><?php //echo date('d-m-Y',strtotime($invoice->invoice_creation_time)); ?><!--</td>-->
					<!---->
					<!--								<td>-->
					<!--									--><?php //if($invoice->invoice_status==1): ?>
					<!--										<a class="btn btn-success" href="--><?php //echo base_url() ?><!--invoice-make/--><?php //echo $invoice->invoice_id; ?><!--" >  Invoice</a>-->
					<!--									--><?php //elseif($invoice->invoice_status==2):?>
					<!--										<a class="btn btn-info" href="--><?php //echo base_url() ?><!--invoice-take/--><?php //echo $invoice->invoice_id; ?><!--" >  Take fee </a>-->
					<!--									--><?php //else :?>
					<!--										<a class="btn btn-danger" href="--><?php //echo base_url() ?><!--invoice-create" >  Add new </a>-->
					<!--									--><?php //endif;?>
					<!--								</td>-->
					<!---->
					<!---->
					<!--							</tr>-->
					<!---->
					<!--							--><?php
					//							$count++;
					//						endforeach;
					//					endif; ?>

					</tbody>

				</table>


			</div>
		</div>

	</div>
</div>


<script>


	$(".withoutFixedDate").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var classSectionData = $("#classSectionId option:selected").text();
		var studentData = $("#studentId option:selected").text();
		$("#resultShow").show();
		$("#ClaaShowId").text(classSectionData);
		$("#StudentShowId").text(studentData);
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});

	$("#dateId2").change(function () {
		var dateId1=$("#dateId1").val();
		var dateId2=$("#dateId2").val();
		var classreg_section_id=$("#classSectionId").val();
		var student_id=$("#studentId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,dateId1:dateId1,dateId2:dateId2,student_id:student_id},
			dataType: "json",
			url: '<?php echo base_url();?>management/InvoicesController/singleStudentWiseResidentData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results['students'], function (key, result) {
					var key=key+1;

					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>' + result['classreg_section_name'] + '</td>' +
						'<td>' + result['resident_creation_time'] + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['resident_fee_amount'] + '</td>' +
						// '<td><a class="btn btn-success" href="invoice-make/' + result['invoice_id'] + '" >  Invoice</a></td>' +
						'</tr>';

					str1=str1+str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});
	$("#classSectionId").change(function () {
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id},
			url: '<?php echo base_url();?>management/InvoicesController/studentSelectionData',
			success: function (results) {
				$("#studentId").html(results);
			}
		});
	});
	function myprint() {
		window.print();
	}
</script>



