

<table class="table table-bordered">
	<thead>
	<tr  >
		<th> ক্লাস</th>
		<th> ছাত্র
		</th>
		<th>মাস</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td>
			<select required name="classreg_section_id" id="classSectionId" class="form-control select2 ">
				<option value="">Select class  name</option>
				<?php if (isset($classSectionRelations)):
					foreach ($classSectionRelations as $classSectionRelation):

						?>
						<option <?php if (isset($Invoices)) : if ($Invoices->classreg_section_id == $classSectionRelation->classreg_section_id): echo 'selected'; else : echo '';endif;endif; ?>
							value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first class and section name</option>
				<?php endif; ?>
			</select>

		</td>
		<td>
			<select required name="student_id" id="studentId" class="form-control select2 ">
				<option> select first class</option>
			</select>


		</td>
		<td>
			<div class="input-group date">
				<input id="dateId" required type="text" class="form-control datepicker" name="invoice_creation_time"  value="<?php if(isset($Invoices)){ echo   date('d-m-Y',strtotime($Invoices->invoice_creation_time));} ?>" placeholder="Enter date:12/12/2019">
				<div class="input-group-addon">
					<span class="glyphicon glyphicon-th" id="datepicker" ></span>
				</div>

			</div>

		</td>

	</tr>
	</tbody>
</table>

        <table class="table table-bordered">
            <thead>
            <tr  >
                <th>বিবরণ</th>
                <th>টাকা</th>
            </tr>
            </thead>
            <tbody>
            <?php $i=0; if(isset($expenseCategories)): foreach ($expenseCategories as $expenseCategory):?>
            <tr>
                <td><?php  ?><input type="checkbox" name="expense_category_id" value="<?php echo $expenseCategory->expense_category_id;?>">
                    <?php echo $expenseCategory->expense_category_name;?></td>
                <td><input type="text" name="invoice_amount" class="form-control numbers"  ></td>
            </tr>
            <?php endforeach; endif;?>
            <tr  >
                <td>মোট</td>
                <td><input id="" class="total form-control" type="text" ></td>
            </tr>
            <tr  >
                <td>টাকা ছাড় </td>
                <td><input id="lessMoney" class="form-control" type="text" ></td>
            </tr>
            <tr  >
                <td>মোট প্রদান</td>
                <td><input  id="tatalPaid"  class=" form-control" type="text" ></td>
            </tr>
            </tbody>
        </table>






					
