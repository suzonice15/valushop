
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box  ">
		<div class="box-header with-border">
			<div class="row">
			<div    class="col-md-offset-3 col-md-4 bg-success">
				<h3>Class :<b><?php if(isset($students[0])) echo $students[0]->classreg_section_name; ?></b> </h3>
				<h4>Month :<b><?php if(isset($students[0])) echo date('F',strtotime($students[0]->invoice_creation_time)); ?></b> </h4>
			</div>
			<div class="col-md-4">
				<a  onclick="window.print()" class="btn btn-info btn-lg">
					<span  class="glyphicon glyphicon-print"></span> Print
				</a>

			</div>
			</div>
		</div>

<div class="table-responsive">
<table  class="table table-bordered ">
	<thead>
	<tr>
		<th>Sl</th>
		<th>Student</th>
		<th>Class</th>
		<th>Category</th>
		<th>Amount</th>
		<th>Month</th>
		<th>Issue date</th>
	</tr>
	</thead>
	<tbody>

	<?php  if(isset($students)):
		$i=1;
		foreach ($students as $student):

		?>
	<tr>
		<td><?php echo $i;?></td>
		<td><?php echo $student->student_name.'-'.$student->student_father_name; ?></td>
		<td><?php echo $student->classreg_section_name; ?></td>
		<td><?php echo $student->expense_category_name; ?></td>
		<td><?php echo $student->invoice_amount; ?></td>

		<td><?php echo date('d-m-Y',strtotime($student->invoice_creation_time)); ?></td>
		<td><?php echo date('d-m-Y',strtotime($student->invoice_issue_date)); ?></td>

	</tr>
	<?php
			$i++;
	endforeach;
	endif;?>

	</tbody>
</table>
</div>
</div>
</div>
