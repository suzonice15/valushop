
<div class="col-md-offset-0 col-md-12">
    <div class="box  box-success">
        <div class="box-header with-border">
            <h3 class="box-title">
                <a class="btn btn-info" href="<?php echo base_url();?>invoice-create"><i class="fa fa-plus-circle"></i>Add new</span></a>


            </h3>




        </div>
        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped ">
                    <thead>
                    <tr>
                        <th>Sl</th>
                        <th>Rosid</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Category</th>
                        <th>Amount</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php if (isset($invoices)):

                        $count =0;
                        foreach ($invoices as $invoice):

                            ?>
                            <tr>
                                <td><?php echo ++$count; ?></td>
                                <td>#<?php echo $invoice->invoice_id; ?></td>
                                <td><?php echo $invoice->student_name.'-'.$invoice->student_father_name; ?></td>
                                <td><?php echo $invoice->classreg_section_name; ?></td>
                                <td><?php echo $invoice->expense_category_name; ?></td>
                                <td><?php echo $invoice->invoice_amount; ?></td>


                            </tr>

                            <?php

                        endforeach;
                    endif; ?>

                    </tbody>

                </table>


            </div>
        </div>

    </div>
</div>

