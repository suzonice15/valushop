<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url() ?>invoice-update" class="form-horizontal" method="post">
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Class and Section Name</label>
<input name="invoice_id" type="hidden" value="<?php echo $Invoices->invoice_id;?>"/>
					<div class="col-md-6">
						<select required name="classreg_section_id" id="classSectionId" class="form-control select2 ">
							<option value="">Select class and section name</option>
							<?php if (isset($classSectionRelations)):
								foreach ($classSectionRelations as $classSectionRelation):

									?>
									<option <?php if (isset($Invoices)) : if ($Invoices->classreg_section_id == $classSectionRelation->classreg_section_id): echo 'selected'; else : echo '';endif;endif; ?>
										value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class and section name</option>
							<?php endif; ?>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Student Name</label>

					<div class="col-md-6">
						<select required name="student_id" id="studentId" class="form-control select2 ">
							<option value="">Select class and section name</option>
							<?php if (isset($students)):
								foreach ($students as $student):

									?>
									<option <?php if (isset($Invoices)) : if ($Invoices->student_id == $student->student_id): echo 'selected'; else : echo '';endif;endif; ?>
										value="<?php echo $student->student_id; ?>"> <?php echo $student->student_name.'-'.$student->student_father_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first student</option>
							<?php endif; ?>

						</select>
					</div>
				</div>


				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Income Category</label>

					<div class="col-md-6">
						<select required name="expense_category_id" id="expense_category_id" class="form-control select2 ">
							<option value="">Select class and section name</option>
							<?php if (isset($expenseCategories)):
								foreach ($expenseCategories as $expenseCategorie):

									?>
									<option <?php if (isset($Invoices)) : if ($Invoices->expense_category_id == $expenseCategorie->expense_category_id): echo 'selected'; else : echo '';endif;endif; ?>
										value="<?php echo $expenseCategorie->expense_category_id; ?>"> <?php echo $expenseCategorie->expense_category_name; ?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first expense category name</option>
							<?php endif; ?>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Amount </label>

					<div class="col-sm-6">
						<input  required type="text" id="invoice_amount" class="form-control" name="invoice_amount"
								value="<?php if (isset($Invoices)) echo $Invoices->invoice_amount; ?>" placeholder="Enter Amount">
					</div>
				</div>


				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Paid amount </label>

					<div class="col-sm-6">
						<input  required type="text" id="invoice_amount_paid" class="form-control" name="invoice_amount_paid"
								value="<?php if (isset($Invoices)) echo $Invoices->invoice_amount_paid; ?>" placeholder="Enter Paid Amount">
					</div>
				</div>

				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Due Amount </label>

					<div class="col-sm-6">
						<input  readonly type="text" id="invoice_due" class="form-control" name="invoice_due"
								value="<?php if (isset($Invoices)) echo $Invoices->invoice_due; ?>" placeholder="">
					</div>
				</div>







		</div>

		<div class="box-footer">
			<input type="submit" class="btn btn-success pull-right" value="Update"/>
			<a class="btn btn-danger " href="<?php echo base_url();?>invoice-list">Cancel</a>

		</div>
		</form>
	</div>

	<script>

		$(function () {
			$("#invoice_amount_paid").on('input',function () {
				var amount=$("#invoice_amount").val();
				var paidAmount=$(this).val();
				var due=amount-paidAmount;
				$("#invoice_due").val(due);


			})	});


		$("#classSectionId").change(function () {
			var classreg_section_id=$("#classSectionId").val();
			$.ajax({
				type: "POST",
				data: {classreg_section_id: classreg_section_id},
				url: '<?php echo base_url();?>Management/InvoicesController/studentSelectionData',
				success: function (results) {
					$("#studentId").html(results);
				}
			});
		});
	</script>

