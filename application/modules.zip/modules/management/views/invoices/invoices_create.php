<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">
            <h5 class="text-center"> ভান্ডারিয়া    সিদ্দিকিয়া  কামিল মাদ্রাসা </h5>
            <h6 class="text-center">পোস্ট মুকুন্দিয়া , রাজবাড়ী সদর ,রাজবাড়ী  </h6>
            <h6 class="text-center">ছাত্রদের  বেতন আদায়ের রশিদ </h6>
			<p ><b> রশিদ  নংঃ#<span id="invoiceId"></span></b></p>
            <p class="pull-right" ><b> তারিখ :<?php echo date('d-m-Y');?></b></p>
            <h1 class="text-center text-success"id="studentFeeResult" ></h1>


		</div>
		<div class="box-body">

			<form action="" class="form-inline" method="post">
				<?php $this->load->view('invoices_form'); ?>


		</div>

		<div class="box-footer">
			<center>
				<button class="btn btn-primary hidden-print" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
			</center>
			<input type="submit" id="save" class="btn btn-success pull-right" value="Save"/>
			<a class="btn btn-danger " href="<?php echo base_url();?>invoice-all">Cancel</a>

		</div>
		</form>
	</div>
</div>

<script>
	function myFunction() {
		window.print();
	}
	$(function () {

        $(document).on("input", ".numbers", function() {

            var sum = 0;
            $(".numbers").each(function(){
                sum += +$(this).val();
            });
            $(".total").val(sum);
        });
 $("#lessMoney").on('input',function () {
	 var amount=$(".total").val();
	 var paidAmount=$("#lessMoney").val();
	 paidAmount=parseInt(paidAmount);
     amount=parseInt(amount);
	 if(paidAmount> amount){

    alert("Paid amount must be less then from total amount");
     }
	 var due=amount-paidAmount;
	 $("#tatalPaid").val(due);


 })

	});


	$("#classSectionId").change(function () {
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id},
			url: '<?php echo base_url();?>Management/InvoicesController/studentSelectionData',
			success: function (results) {
				$("#studentId").html(results);
			}
		});
	});

	$(document).mousemove(function(){
		$.ajax({
			type: "POST",
			url: '<?php echo base_url();?>Management/InvoicesController/invoiceSelectionData',
			success: function (results) {
				$("#invoiceId").text(results);
			}
		});
		});


    $("#save").click(function (e) {
        e.preventDefault();
        var classreg_section_id=$('#classSectionId').val();
        var invoice_creation_time=$('#dateId').val();
        var student_id=$('#studentId').val();
        if(classSectionId.length ==0){
            alert("Select  Class");
        }
        if(studentId.length ==0){
            alert("Select  Student");
        }
       var  expense_category_id = new Array();
        $("input[name='expense_category_id']:checked").each(function() {

			expense_category_id.push($(this).val());



		});
		var invoice_amount = new Array();
        $("input[name='invoice_amount']").each(function() {

			//invoice_amount = invoice_amount  + $(this).val()+ ',';
			invoice_amount.push($(this).val());


        });
		var invoice_amount = invoice_amount.filter(Boolean);
		var expense_category_id = expense_category_id.filter(Boolean);
        $.ajax({
            type: "POST",
            data: {classreg_section_id:classreg_section_id,student_id:student_id,expense_category_id:expense_category_id,invoice_amount:invoice_amount,invoice_creation_time:invoice_creation_time},
            url: '<?php echo base_url();?>invoice-save',
            success: function (results) {
            	alert(results);

			}
        });
    });
	</script>
