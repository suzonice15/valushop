
<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>
			<table class="table table-bordered col-md-offset-3 col-md-6 hidden-print">
				<thead>
				<tr>
					<!--					<th scope="col"> </th>-->
					<th scope="col" width="250">Class</th>
					<th scope="col" width="250">Month</th>
					<th scope="col" ></th>
				</tr>
				</thead>
				<form action="<?php echo base_url()?>classWiseFeeList" method="post">
					<tbody>
					<!--				<td><a class="btn btn-info" href="--><?php //echo base_url();?><!--invoice-create"><i class="fa fa-plus-circle"></i>Add new</span></a></td>-->
					<td>
						<select  required 	 id="classSectionId" name="classreg_section_id" class="form-control select2">
							<option value="" >Select Class </option>
							<?php if(isset($classsections)):
								foreach ($classsections as $class):
									?>
									<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class </option>
							<?php endif;?>
						</select>
					</td>

					<td>
						<div class="form-group">
							<select  required name="invoice_creation_time"  class="form-control select2" id="invoice_creation_time" >

								<option value="">Select Month </option>
								<option value="01">January </option>
								<option value="02">February </option>
								<option value="03">March </option>
								<option value="04">April </option>
								<option value="05">May </option>
								<option value="06">June </option>
								<option value="07">July </option>
								<option value="08">August </option>
								<option value="09">September </option>
								<option value="10">October </option>
								<option value="11">November </option>
								<option value="12">December </option>

							</select>
						</div>

					</td>
					<td>

						<a onclick="window.print()" class="btn btn-info btn-lg">
							<span class="glyphicon glyphicon-print"></span> Print
						</a>
					</td>
				</form>
				</tr>
				</tbody>
			</table>



			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
				<h3>Result for:<b id="catId"></b> </h3>
				<h4>Month :<span id="dateShow1"></span></h4>
			</div>


		</div>
		<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped ">
					<thead>
					<tr>
						<th>Sl</th>
						<th>Student</th>
						<th>Class</th>
						<th>Category</th>
						<th>Amount</th>
						<th>Month</th>
						<th>Issue date</th>

					</tr>
					</thead>
					<tbody>


					</tbody>

				</table>


			</div>
		</div>

	</div>
</div>


<script>

	$("#invoice_creation_time").change(function () {
		var expense_category = $("#classSectionId option:selected").text();
		var invoice_creation_time = $("#invoice_creation_time option:selected").text();
		$("#resultShow").show();
		$("#catId").text(expense_category);
		$("#dateShow1").text(invoice_creation_time);
	});
	$("#invoice_creation_time").change(function () {
		var invoice_creation_time=$("#invoice_creation_time").val();
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,invoice_creation_time:invoice_creation_time},
			dataType: "json",
			url: '<?php echo base_url();?>management/InvoicesController/residentClassData',
			success: function (results) {
				var str = "";
				var str1 = "";
				debugger;
				$.each(results['students'], function (key, result) {
					var key=key+1;

					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>' + result['student_name'] + '-' + result['student_father_name'] + '</td>' +
						'<td>' + result['classreg_section_name'] + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['resident_fee_amount'] + '</td>' +

						'<td>' + result['resident_creation_time'] + '</td>' +
						'<td>' + result['resident_issue_date'] + '</td>' +
						//	'<td><a class="btn-xs btn-success " href="invoice-make/' + result['invoice_id'] + '" >  Invoice</a></td>' +
						'</tr>';

					str1=str1+str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});



</script>



