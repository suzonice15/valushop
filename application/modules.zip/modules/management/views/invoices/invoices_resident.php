<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">
			<h5 class="text-center"> ভান্ডারিয়া    সিদ্দিকিয়া  কামিল মাদ্রাসা </h5>
			<h6 class="text-center">পোস্ট মুকুন্দিয়া , রাজবাড়ী সদর ,রাজবাড়ী  </h6>
			<h6 class="text-center">আবাসিক  ছাত্রদের বেতন   আদায়ের   রশিদ   </h6>
			<p ><b>Invoice id#<span id="invoiceId"></span></b></p>
			<p class="pull-right" ><b>Date :<?php echo date('d-m-Y');?></b></p>
			<h1 class="text-center text-success"id="studentFeeResult" ></h1>


		</div>
		<div class="box-body">

			<form action="" class="form-horizontal" method="post">


				<table class="table table-bordered">
					<thead>
					<tr>
						<th width="50%">Class</th>
						<th  width="50%">Student</th>

					</tr>
					</thead>
					<tbody>
					<tr>
						<td>
							<select required name="classreg_section_id" id="classSectionId" class="form-control select2 ">
								<option value="">Select class  name</option>
								<?php if (isset($classSectionRelations)):
									foreach ($classSectionRelations as $classSectionRelation):

										?>
										<option <?php if (isset($Invoices)) : if ($Invoices->classreg_section_id == $classSectionRelation->classreg_section_id): echo 'selected'; else : echo '';endif;endif; ?>
											value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
									<?php endforeach; else : ?>
									<option value="">Registration first class and section name</option>
								<?php endif; ?>
							</select>

						</td>
						<td>
							<select required name="student_id" id="studentId" class="form-control select2 ">
								<option> select first class</option>
							</select>


						</td>


					</tr>
					</tbody>
				</table>

				<table class="table table-bordered">
					<thead>
					<tr  >
						<th>বিবরণ</th>
						<th>মাস</th>
						<th>টাকা</th>
					</tr>
					</thead>
					<tbody>
					<?php $i=0; if(isset($expenseCategories)): foreach ($expenseCategories as $expenseCategory):?>
						<tr>
							<td><?php  ?><input type="checkbox" name="expense_category_id" value="<?php echo $expenseCategory->expense_category_id;?>">
								<?php echo $expenseCategory->expense_category_name;?></td>
							<td>
								<div class="input-group date">
									<input id="dateId" required type="text" class="form-control datepicker" name="resident_creation_time"  value="" placeholder="Enter date:12/12/2019">
									<div class="input-group-addon">
										<span class="glyphicon glyphicon-th" id="datepicker" ></span>
									</div>

							</td>
							<td><input type="text" name="resident_fee_amount" class="form-control numbers"  ></td>
						</tr>
					<?php endforeach; endif;?>
					<tr  >
						<td></td>
						<td>মোট</td>
						<td><input  class="total form-control" type="text" ></td>
					</tr>
					<tr  >
						<td></td>
						<td>টাকা ছাড়</td>
						<td><input id="lessMoney" class="form-control" type="text" ></td>
					</tr>
					<tr  >
						<td></td>
						<td>মোট   প্রদান </td>
						<td><input  id="tatalPaid"  class=" form-control" type="text" ></td>
					</tr>
					</tbody>
				</table>



				<div class="box-footer">
					<center>
						<button class="btn btn-primary hidden-print" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
					</center>
					<input type="submit" id="resident_save" class="btn btn-success pull-right hidden-print" value="resident save"/>
					<a class="btn btn-danger " href="<?php echo base_url();?>invoice-resident-all">Cancel</a>

				</div>




			</form>
	</div>
</div>

<script>
	function myFunction() {
		window.print();
	}
	$(function () {

		$(document).on("input", ".numbers", function() {

			var sum = 0;
			$(".numbers").each(function(){
				sum += +$(this).val();
			});
			$(".total").val(sum);
		});
		$("#lessMoney").on('input',function () {
			var amount=$(".total").val();
			var paidAmount=$("#lessMoney").val();
			paidAmount=parseInt(paidAmount);
			amount=parseInt(amount);
			if(paidAmount> amount){

				alert("Paid amount must be less then from total amount");
			}
			var due=amount-paidAmount;
			$("#tatalPaid").val(due);


		});

	});


	$("#classSectionId").change(function () {
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id},
			url: '<?php echo base_url();?>Management/InvoicesController/studentSelectionData',
			success: function (results) {
				$("#studentId").html(results);
			}
		});
	});

	$(document).mousemove(function(){
		$.ajax({
			type: "POST",
			url: '<?php echo base_url();?>Management/InvoicesController/residentSelectionData',
			success: function (results) {
				$("#invoiceId").text(results);
			}
		});
	});


		$(document).on('click','#resident_save',function (e) {

			e.preventDefault();
		var classreg_section_id=$('#classSectionId').val();
		var student_id=$('#studentId').val();
		if(classSectionId.length ==""){
			alert("Select  Class");
		}
		if(studentId.length ==0){
			alert("Select  Student");
		}
		var  expense_category_id = new Array();
		$("input[name='expense_category_id']:checked").each(function() {

			expense_category_id.push($(this).val());
		});
		var  resident_creation_time = new Array();
		$("input[name='resident_creation_time']").each(function() {

			resident_creation_time.push($(this).val());
		});
		var resident_fee_amount = new Array();
		$("input[name='resident_fee_amount']").each(function() {
			resident_fee_amount.push($(this).val());
		});
		var expense_category_id = expense_category_id.filter(Boolean);
		var resident_fee_amount = resident_fee_amount.filter(Boolean);
		var resident_creation_time = resident_creation_time.filter(Boolean);
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,student_id:student_id,expense_category_id:expense_category_id,resident_fee_amount:resident_fee_amount,resident_creation_time:resident_creation_time},
			url: '<?php echo base_url();?>Management/InvoicesController/residentSave',
			success: function (results) {
				alert(results);

			},
			error:function (results) {
				alert(results);
			}
		});
	});
</script>
