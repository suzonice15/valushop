<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<section class="invoice">
				<!-- title row -->
				<div class="row">
					<div class="col-xs-12">
						<h2 class="page-header">
							<i class="fa fa-globe"></i> <?php echo $schools->satinge_name; ?>
							<small class="pull-right">Date: <?php echo date('d/m/Y');?></small>
						</h2>
					</div>
					<!-- /.col -->
				</div>
				<!-- info row -->
				<div class="row invoice-info">
					<div class="col-sm-4 invoice-col">
						From
						<address>schools
							<strong><?php echo $schools->satinge_name; ?></strong><br>
							<?php echo $schools->satinge_address; ?><br>
							Phone: <?php echo $schools->satinge_mobile; ?><br>
							Email: <?php echo $schools->satinge_email; ?>
						</address>
					</div>
					<!-- /.col -->
					<div class="col-sm-4 invoice-col">
						To
						<address>
							<strong><?php echo $Invoices->student_name; ?></strong><br>
							<?php echo $Invoices->student_address; ?><br>
							Phone: <?php echo $Invoices->student_phone; ?><br>
							Email: <?php echo $Invoices->student_email; ?>
						</address>
					</div>
					<!-- /.col -->
					<div class="col-sm-4 invoice-col">
						<br>
						<b>Invoice ID  : <?php echo $Invoices->invoice_id; ?></b><br>

						<b>Reggistration ID:</b> <?php echo $Invoices->student_id; ?><br>
						<b>Payment Due:</b><?php echo date('d-m-Y',strtotime($Invoices->invoice_creation_time)); ?><br>

					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->

				<!-- Table row -->
				<div class="row">
					<div class="col-xs-12 table-responsive">
						<table class="table table-striped">
							<thead>
							<tr>
								<th>Sl</th>
								<th>Name</th>
								<th>Class</th>
								<th>Subtotal</th>
							</tr>
							</thead>
							<tbody>
<?php // $i=1;foreach ($Invoices as $invoice):?>
							<tr>
								<td><?php echo '1';?></td>
								<td><?php echo $Invoices->student_name;?></td>
								<td><?php echo $Invoices->classreg_section_name;?></td>
								<td><?php echo $Invoices->invoice_amount;?></td>
							</tr>
<!--							--><?php //$i++;endforeach;?>
							</tbody>
						</table>
					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->

				<div class="row">
					<!-- accepted payments column -->
					<div class="col-xs-5">

					</div>
					<!-- /.col -->
					<div class="col-xs-7">
						<p class="lead">Amount Due: <?php echo date('d-m-Y',strtotime($Invoices->invoice_creation_time));?></p>

						<div class="table-responsive">
							<table class="table">
								<tbody><tr>
									<th style="width:50%">Payment </th>
									<td>Money</td>
								</tr>

								<?php  $i=1;foreach ($payments as $payment):?>

								<tr>

									<td><?php echo date('l jS \of F Y ',strtotime($payment->payment_date));?></td>
									<td><?php echo $payment->payment_amount;?></td>
								</tr>
								<?php endforeach;?>

								<tr>

									<th>Total</th>
									<td><?php echo $Invoices->invoice_amount;?></td>
								</tr>
								<tr>

									<th>Paid amount</th>
									<td><?php echo $Invoices->invoice_amount_paid;?></td>
								</tr>
								<tr>

									<th>Due</th>
									<td><?php echo $Invoices->invoice_due;?></td>
								</tr>
								<tr>
								<?php
								//$due=0;//$Invoices[0]->invoice_due;
								if($Invoices->invoice_due==0){?>
									<th>Status</th>
									<td><span class="btn-xs btn-success">paid</span></td>

								<?php } else { ?>
									<th>Status</th>
									<td><span class="btn-xs btn-danger">Unpaid</span></td>
									<?php }  ?>
								</tr>
								</tbody></table>
						</div>
					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->

				<!-- this row will not appear when printing -->
				<div class="row no-print">
					<div class="col-md-12">
						<a class="btn btn-danger pull-left " href="<?php echo base_url();?>invoice-list">Cancel</a>

						<a onclick="printDocument()" id="print" target="_blank" class="btn btn-info pull-right"><i class="fa fa-print"></i> Print</a>
<!--						<button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment-->
<!--						</button>-->
<!--						<button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">-->
<!--							<i class="fa fa-download"></i> Generate PDF-->
<!--						</button>-->
					</div>
				</div>
			</section>
<!--		<div class="box-footer">-->
<!--			<input type="submit" class="btn btn-success pull-right" value="Update"/>-->
<!--			<a class="btn btn-danger " href="--><?php //echo base_url();?><!--invoice-list">Cancel</a>-->
<!---->
<!--		</div>-->
		</form>
	</div>

	<script>

		$(function () {
			$("#invoice_amount_paid").on('input',function () {
				var amount=$("#invoice_amount").val();
				var paidAmount=$(this).val();
				var due=amount-paidAmount;
				$("#invoice_due").val(due);


			})	});


		$("#classSectionId").change(function () {
			var classreg_section_id=$("#classSectionId").val();
			$.ajax({
				type: "POST",
				data: {classreg_section_id: classreg_section_id},
				url: '<?php echo base_url();?>Management/InvoicesController/studentSelectionData',
				success: function (results) {
					$("#studentId").html(results);
				}
			});
		});
		function printDocument() {
			window.print();
		}
	</script>

