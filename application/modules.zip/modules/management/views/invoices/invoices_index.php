
<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>
			<table class="table table-bordered col-md-offset-3 col-md-6">
				<thead>
				<tr>
<!--					<th scope="col"> </th>-->
					<th scope="col" width="250">Class</th>
					<th scope="col" width="250">Month</th>
					<th scope="col" ></th>
				</tr>
				</thead>
				<form action="<?php echo base_url()?>classWiseFeeList" method="post">
				<tbody>
<!--				<td><a class="btn btn-info" href="--><?php //echo base_url();?><!--invoice-create"><i class="fa fa-plus-circle"></i>Add new</span></a></td>-->
					<td>
						<select  required 	 id="classSectionId" name="classreg_section_id" class="form-control select2">
							<option value="" >Select Class </option>
							<?php if(isset($classsections)):
								foreach ($classsections as $class):
									?>
									<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class </option>
							<?php endif;?>
						</select>
					</td>

				<td>
                    <div class="form-group">
					<select  required name="invoice_creation_time"  class="form-control select2" id="invoice_creation_time" >

                        <option value="">Select Month </option>
                        <option value="01">January </option>
                        <option value="02">February </option>
                        <option value="03">March </option>
                        <option value="04">April </option>
                        <option value="05">May </option>
                        <option value="06">June </option>
                        <option value="07">July </option>
                        <option value="08">August </option>
                        <option value="09">September </option>
                        <option value="10">October </option>
                        <option value="11">November </option>
                        <option value="12">December </option>

                    </select>
					</div>

				</td>
<td>
 <input type="submit"  href="<?php echo base_url()?>/classWiseFeeList"  target="_blank"  value="Print" class="btn btn-success"/></a>
</td>
				</form>
				</tr>
				</tbody>
			</table>



			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
				<h3>Result for:<b id="catId"></b> </h3>
				<h4>Month :<span id="dateShow1"></span></h4>
			</div>


		</div>
		<div class="box-body">
			<div class="table-responsive">
			<table id="example1" class="table table-bordered table-striped ">
				<thead>
				<tr>
					<th>Sl</th>
					<th>Student</th>
					<th>Class</th>
					<th>Category</th>
					<th>Amount</th>
					<th>Month</th>
                    <th>Issue date</th>

				</tr>
				</thead>
				<tbody>
<!--				--><?php //if (isset($invoices)):
//
//					$count =1;
//					foreach ($invoices as $invoice):
//
//						?>
<!--						<tr>-->
<!--							<td>--><?php //echo $count; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->student_name.'-'.$invoice->student_father_name; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->classreg_section_name; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->expense_category_name; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->invoice_amount; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->invoice_amount_paid; ?><!--</td>-->
<!--							<td>--><?php //echo $invoice->invoice_due; ?><!--</td>-->
<!--							--><?php //if($invoice->invoice_amount==$invoice->invoice_amount_paid):?>
<!--							<td>-->
<!--								<span class="btn-xs btn-success">Paid</span>-->
<!--							</td>-->
<!--							--><?php //elseif($invoice->invoice_amount > $invoice->invoice_amount_paid): ?>
<!--							<td>-->
<!--								<span class="btn-xs btn-info">Partial paid</span>-->
<!--							</td>-->
<!--							--><?php //else : ?>
<!--							<td>-->
<!--								<span class="btn-xs btn-danger">unpaid</span>-->
<!--							</td>-->
<!--							--><?php //endif; ?>
<!--                            <td>--><?php //echo date('d-m-Y',strtotime($invoice->invoice_creation_time)); ?><!--</td>-->
<!--                            <td>--><?php //echo date('d-m-Y',strtotime($invoice->invoice_issue_date)); ?><!--</td>-->
<!---->
<!--							<td>-->
<!--								--><?php //if($invoice->invoice_amount==$invoice->invoice_amount_paid): ?>
<!--									<a class="btn btn-success" href="--><?php //echo base_url() ?><!--invoice-make/--><?php //echo $invoice->invoice_id; ?><!--" >  Invoice</a>-->
<!--								--><?php //elseif($invoice->invoice_amount > $invoice->invoice_amount_paid):?>
<!--									<a class="btn btn-info" href="--><?php //echo base_url() ?><!--invoice-take/--><?php //echo $invoice->invoice_id; ?><!--" >  Take fee </a>-->
<!--								--><?php //else :?>
<!--		<a class="btn btn-danger"  href="--><?php //echo base_url() ?><!--invoice-create" >  Add new </a>-->
<!--								--><?php //endif;?>
<!--							</td>-->
<!---->
<!---->
<!--						</tr>-->
<!---->
<!--						--><?php
//						$count++;
//					endforeach;
//				endif; ?>

				</tbody>

			</table>


		</div>
		</div>

	</div>
</div>


<script>

	$("#invoice_creation_time").change(function () {
		var expense_category = $("#classSectionId option:selected").text();
		var invoice_creation_time = $("#invoice_creation_time option:selected").text();
		$("#resultShow").show();
		$("#catId").text(expense_category);
		$("#dateShow1").text(invoice_creation_time);
	});
	$("#invoice_creation_time").change(function () {
		var invoice_creation_time=$("#invoice_creation_time").val();
		var classreg_section_id=$("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,invoice_creation_time:invoice_creation_time},
			dataType: "json",
			url: '<?php echo base_url();?>management/InvoicesController/studentData',
			success: function (results) {
				var str = "";
				var str1 = "";
				debugger;
				$.each(results['students'], function (key, result) {
					var key=key+1;

						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['student_name'] + '-' + result['student_father_name'] + '</td>' +
							'<td>' + result['classreg_section_name'] + '</td>' +
							'<td>' + result['expense_category_name'] + '</td>' +
							'<td>' + result['invoice_amount'] + '</td>' +

							'<td>' + result['invoice_creation_time'] + '</td>' +
							'<td>' + result['invoice_issue_date'] + '</td>' +
						//	'<td><a class="btn-xs btn-success " href="invoice-make/' + result['invoice_id'] + '" >  Invoice</a></td>' +
							'</tr>';

					str1=str1+str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#printId").click(function () {

		printDiv();
	});

	function printDiv()
	{

		var divToPrint=$("#example1").html();
		var resultShow=$("#resultShow").html();
		var html =resultShow+divToPrint;

		var newWin=window.open('','Print-Window');

		newWin.document.open();

		newWin.document.write('<html><body onload="window.print()">'+html+'</body></html>');

		newWin.document.close();

		setTimeout(function(){newWin.close();},10);

	}
</script>



