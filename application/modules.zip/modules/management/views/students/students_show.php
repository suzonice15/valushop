
<div class="col-md-offset-1 col-md-8">

<div class="box box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><?php echo $title; ?></h3>


	</div>
	<div class="box-body">
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-7">
				<table class="table ">
					<tbody>
					<tr>
						<td style="padding: 33px 15px;">Student picture</td>
						<td > <?php
							if (!empty($student->student_picture_path)) {
								?>
								<img width="80" height="80"  src="<?php echo base_url(); ?><?php echo $student->student_picture_path; ?>"/>
								<?php
							} else {
								?>
								<img width="80" height="80" src="<?php echo base_url(); ?>/uploads/teachers/teacher.png"/>
							<?php } ?>

						</td>
					</tr>

					<tr>
						<td>Student Name</td>
						<td> <?php echo $student->student_name; ?></td>
					</tr>
					<tr>
						<td>Student Father Name</td>
						<td> <?php echo $student->student_father_name; ?></td>
					</tr>
					<tr>
						<td>Student Mother Name</td>
						<td> <?php echo $student->student_mother_name; ?></td>
					</tr>
					<tr>
						<td>Student Roll </td>
						<td> <?php echo $student->student_roll; ?></td>
					</tr>
					<tr>
						<td>Student's Address</td>
						<td> <?php echo $student->student_address; ?></td>
					</tr>
					<tr>
						<td>
							Student Bairthday
						</td>
						<td> <?php echo $student->student_birthday; ?></td>
					</tr>
					<tr>
						<td>Student's Mobile </td>
						<td> <?php echo $student->student_phone; ?></td>
					</tr>
					<tr>
						<td>Student's Email </td>
						<td> <?php echo $student->student_email; ?></td>
					</tr>
					<tr>
						<td>Class </td>
						<td> <?php echo $student->classreg_section_name; ?></td>
					</tr>
					<tr>
						<td>Session </td>
						<td> <?php echo $student->session_name; ?></td>
					</tr>

					<tr>
						<td>Gender</td>
						<td> <?php echo $student->student_sex; ?></td>
					</tr><tr>
						<td>Religion</td>
						<td> <?php echo $student->student_religion; ?></td>
					</tr><tr>
						<td>Blood Group </td>
						<td> <?php echo $student->student_blood_group; ?></td>
					</tr>

					</tr><tr>
						<td> </td>
						<td><a class="btn btn-info pull-right" href="<?php echo base_url(); ?>student-list">Back</a> </td>

					</tr>

					</tbody>

				</table>
			</div>

		</div>
	</div>


</div>
</div>
