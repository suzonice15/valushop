
<div class="col-md-offset-0 col-md-12">
<div class="box  box-success ">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>student-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">
		<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped table-responsive ">
			<thead>
			<tr>
				<th>Id</th>
				<th>Picture</th>
				<th>StudentName</th>
				<th>FatherName</th>
				<th>MotherName</th>
				<th>Mobile</th>
				<th>Religion</th>
				<th>BloodGroup</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($students)):

				$count = sizeof($students);
				//var_dump($count);exit();
				foreach ($students as $student):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php
							if(!empty($student->student_picture_path)):
								?>
				<img width="70" height="50" src="<?php echo base_url(); echo $student->student_picture_path; ?>"/>
							<?php
							else:
								?>
								<img width="70" height="50"  src="<?php echo base_url() ?>uploads/teacher/teacher.png"/>
							<?php endif;
							?></td>
						<td><?php echo $student->student_name; ?></td>
						<td><?php echo $student->student_father_name; ?></td>
						<td><?php echo $student->student_mother_name; ?></td>
						<td><?php echo $student->student_phone; ?></td>
						<td><?php echo $student->student_religion; ?></td>
						<td><?php echo $student->student_blood_group; ?></td>
						<td>
							<a title="profile" href="<?php echo base_url() ?>student-view/<?php echo $student->student_id;  ?>"
							<span class=" glyphicon glyphicon-user btn btn-primary"></span>
							</a>
							<a title="edit" href="<?php echo base_url() ?>student-edit/<?php echo $student->student_id;  ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a title="delete" href="<?php echo base_url() ?>student-delete/<?php echo $student->student_id;  ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>
						</td>

					</tr>

					<?php
					$count--;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>
	</div>

</div>
