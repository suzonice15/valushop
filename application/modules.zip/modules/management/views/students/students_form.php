<!--<div class="form-group">-->
<!--	<label  class="col-sm-3 control-label">Student Name<span style="color:red"> *</span></label>-->
<!---->
<!--	<div class="col-md-7">-->
		<input  type="hidden"  class="form-control" name="student_classreg_section_name" id="student_classreg_section_name"
			   value="<?php if (isset($student)) echo $student->student_classreg_section_name; ?>">
<!---->
<!--	</div>-->
<!--</div>-->

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student Name<span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text"  class="form-control" name="student_name" id="studentName"
			   value="<?php if (isset($student)) echo $student->student_name; ?>"
			   placeholder="Enter Studnet name :shahinul islam">
		<input type="hidden" name="student_id" value="<?php if (isset($student)) echo $student->student_id; ?>">
	</div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student Father Name <span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control" name="student_father_name"
			   value="<?php if (isset($student)) echo $student->student_father_name; ?>"
			   placeholder="Enter Student Father Name :abdul Hamid">
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student Mother Name <span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control" name="student_mother_name"
			   value="<?php if (isset($student)) echo $student->student_mother_name; ?>"
			   placeholder="Enter Student Mother Name :Sunur Jan ">
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student Roll <span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control" name="student_roll"
			   value="<?php if (isset($student)) echo $student->student_roll; ?>"
			   placeholder="Enter Student Roll:10">
	</div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student's Address<span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control " name="student_address"
			   value="<?php if (isset($student)) echo $student->student_address; ?>"
			   placeholder="Enter Student address: Mirpur 2,Dahaka">
	</div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student Bairthday </label>

	<div class="col-md-7">
		<div class="input-group date" >
			<input type="text" id="field-1" class="form-control withoutFixedDate" name="student_birthday"
				   value="<?php if (isset($student)) echo $student->student_birthday; ?>"
				   placeholder="enter session name : 2010">
			<div class="input-group-addon">
				<span class="glyphicon glyphicon-th"></span>
			</div>
		</div>
	</div>
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">Class  Name</label>
	<div class="col-md-7">
		<select required name="classreg_section_id" id="classreg_section_id" class="form-control select2 ">
			<option value="">Select class and section name</option>
			<?php if (isset($classSectionRelations)):
				foreach ($classSectionRelations as $classSectionRelation):

					?>
					<option <?php if (isset($student)) : if ($student->classreg_section_id == $classSectionRelation->classreg_section_id): echo 'selected'; else : echo '';endif;endif; ?>
						value="<?php echo $classSectionRelation->classreg_section_id; ?>"> <?php echo $classSectionRelation->classreg_section_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class and section name</option>
			<?php endif; ?>
		</select>
	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">Session  Name</label>
	<div class="col-md-7">
		<select required name="session_id" id="classSectionId" class="form-control select2 ">
			<option value="">Select class and section name</option>
			<?php if (isset($sessions)):
				foreach ($sessions as $session):

					?>
					<option <?php if (isset($student)) : if ($student->session_id == $session->session_id): echo 'selected'; else : echo '';endif;endif; ?>
						value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class and section name</option>
			<?php endif; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student's Mobile <span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="studentMobile" class="form-control" name="student_phone"
			   value="<?php if (isset($student)) echo $student->student_phone; ?>"
			   placeholder="Enter Student Mobile:01815330597">
        <span style="color:red" id="mobileEerror"></span>
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student's Email</label>

	<div class="col-md-7">
		<input type="email" id="student_email" class="form-control" name="student_email"
			   value="<?php if (isset($student)) echo $student->student_email; ?>"
			   placeholder="Enter Student Email :shahinul@gmail.com">
		<span id="emailError" style="color:red"></span>
	</div>
</div>


<div class="form-group">
	<label for="field-2" class="col-sm-3 control-label">Gender<span style="color:red"> *</span></label>
	<div class="col-md-7">
		<select required name="student_sex" id="gender_id" class="form-control select2 ">
			<option value="">Select Gender</option>
			<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Female" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="Female">Female
			</option>
			<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Male" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Male">Male</option>
			<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Other" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Other">Other
			</option>

		</select>
	</div>

</div>


<div class="form-group">
	<label for="field-2" class="col-sm-3 control-label">Religion <span style="color:red"> *</span></label>
	<div class="col-md-7">
		<select required name="student_religion" id="religion_id" class="form-control select2">

			<option value="">Select Religion</option>
			<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Muslim" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="Muslim">
				Muslim
			</option>
			<option  <?php $selected=isset($student->student_religion)? $student->student_religion == "Buddist" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Buddist">
				Buddist
			</option>
			<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Christian" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Christian">
				Christian
			</option>
			<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Hindu" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Hindu">Hindu
			</option>
		</select>
	</div>
</div>



<div class="form-group">
	<label for="student_blood_group" class="col-sm-3 control-label">Blood Group<span style="color:red"> *</span> </label>
	<div class="col-md-7">
		<select name="student_blood_group" id="student_blood_group" class="form-control select2 ">
			<option value="">Select blood group</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "AB-" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="AB-">AB-</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "AB+" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="AB+">AB+</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "B-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="B-">B-</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "B+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="B+">B+</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "A-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="A-">A-</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "A+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="A+">A+</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "O-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="O-">O-</option>
			<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "O+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="O+">O+</option>
		</select>
	</div>
</div>
<?php if(!empty($student->student_picture_path)):?>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student picture</label>
	<div class="col-md-7">
		<img width="70" height="50" src="<?php echo base_url(); if(isset($student)){ echo $student->student_picture_path;} ?>"/>

		<input type="hidden"  class="form-control" name="old_student_picture_path" value="<?php  if(isset($student)){ echo $student->student_picture_path;} ?>">
	</div>
</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Student picture</label>
	<div class="col-md-7">
		<input type="file"  class="form-control" name="student_picture_path">
	</div>
</div>

<script>

	$(function () {
		// $("#classreg_section_id").change(function () {
			$(document).on('change , blur , click','#classreg_section_id, #studentName ',function () {
				var classreg_section_id=$("#classreg_section_id option:selected").text();
				var studentName=$("#studentName").val();
				var combination =studentName.trim()+'-'+classreg_section_id.trim();
				$("#student_classreg_section_name").val(combination);

			});

		});


</script>

