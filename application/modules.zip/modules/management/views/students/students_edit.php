<div class="col-md-offset-1 col-md-8">

<div class="box box-success ">
	<div class="box-header with-border">
		<h3 class="box-title"><?php echo $title; ?></h3>


	</div>
	<div class="box-body">

		<form action="<?php echo base_url() ?>student-update" class="form-horizontal" method="post" enctype="multipart/form-data">
			<?php $this->load->view('students_form'); ?>

	</div>

	<div class="box-footer">
		<input type="submit" class="btn btn-success pull-right" value="Update"/>
		<a class="btn btn-danger " href="<?php echo base_url();?>student-list">Cancel</a>

	</div>
	</form>
</div>
</div>
<script>

	$(document).ready(function () {
		$(document).on('blur','#studentMobile',function () {
			checkMobile();
		});
	});

	function checkMobile() {
		var student_phone = $('#studentMobile').val();
		if(student_phone.length<11){
			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;

		}
		else if(student_phone.length>11){

			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;
		}
		//$.ajax({
		//	type: 'POST',
		//	url: '<?php //echo base_url()?>//Management/StudentsController/studentMobile/' + student_phone,
		//	success: function (result) {
		//		if (result) {
		//			$('#mobileEerror').html(result);
		//			return false;
		//		} else {
		//			$('#mobileEerror').html('');
		//			$('input[type="submit"]').removeAttr('disabled');
		//			return false;
		//		}
		//	}
		//});
		//return false;
	}

</script>

