<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class section</label>
	<div class="col-sm-6">
		<select required name="classreg_section_id" id="classreg_section_id" class="form-control select2">
			<option value="" >Select class section name</option>
			<?php if(isset($classSections)):
				foreach ($classSections as $classSection):
					?>
					<option <?php if(isset($classRoutineData->classreg_section_id )): if($classRoutineData->classreg_section_id == $classSection->classreg_section_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $classSection->classreg_section_id; ?>" ><?php echo $classSection->classreg_section_name;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class seciton</option>
			<?php endif;?>
		</select>
		<input type="hidden"  name="class_routine_id" value="<?php if (isset($classRoutineData)) echo $classRoutineData->class_routine_id; ?>">

	</div>
</div>



<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Subject </label>
	<div class="col-sm-6">
		<select required name="subject_id" id="subject_id" class="form-control select2">
			<option value="" >Select subject</option>
			<?php if(isset($subjects)):
				foreach ($subjects as $subject):
					?>
					<option <?php if(isset($classRoutineData->subject_id )): if($classRoutineData->subject_id == $subject->subject_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $subject->subject_id; ?>" ><?php echo $subject->subject_name.'-'.$subject->subject_code;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first subject name</option>
			<?php endif;?>
		</select>
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Teacher Name</label>
	<div class="col-sm-6">
		<select required name="teacher_id" id="teacher_id" class="form-control select2">
			<option value="" >Select teacher name</option>
			<?php if(isset($teachers)):
				foreach ($teachers as $teacher_row):
					?>
					<option <?php if(isset($classRoutineData->teacher_id )): if($classRoutineData->teacher_id == $teacher_row->teacher_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $teacher_row->teacher_id; ?>" ><?php echo $teacher_row->teacher_full_name;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first teacher name</option>
			<?php endif;?>
		</select>
	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class Room</label>
	<div class="col-sm-6">
		<select required name="class_room_id" id="class_room_id" class="form-control select2">
			<option value="" >Select teacher name</option>
			<?php if(isset($classRooms)):
				foreach ($classRooms as $classRoom):
					?>
					<option <?php if(isset($classRoutineData->class_room_id )): if($classRoutineData->class_room_id == $classRoom->class_room_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $classRoom->class_room_id; ?>" ><?php echo $classRoom->class_room_name;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first class name</option>
			<?php endif;?>
		</select>
	</div>
</div>
<div class="form-group ">
	<label for="day" class="col-sm-4 control-label">Day</label>
	<div class="col-sm-6">
		<select name="class_routine_day" id="day" class="form-control select2" required="">
			<option value="">Select a day</option>
			<option <?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='saturday' ?  'selected="selected"': "":""; echo $selected; ?> value="saturday">Saturday</option>
			<option
				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='sunday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="sunday">Sunday</option>
			<option

				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='monday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="monday">Monday</option>
			<option
				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='tuesday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="tuesday">Tuesday</option>
			<option
				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='wednesday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="wednesday">Wednesday</option>
			<option
				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='thursday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="thursday">Thursday</option>
			<option
				<?php $selected=isset($classRoutineData->class_routine_day) ? $classRoutineData->class_routine_day=='friday' ?  'selected="selected"': "":""; echo $selected; ?>
				value="friday">Friday</option>
		</select>
	</div>
</div>
	<div class="form-group">
		<label for="day" class="col-sm-4 control-label">Staring Time</label>
		<div class="col-sm-6">
		<div class="input-group">
			<input type="text" name="class_routine_starting" value="<?php if(isset($classRoutineData->class_routine_starting)) { echo $classRoutineData->class_routine_starting; }?>" class="form-control timepicker">
			<div class="input-group-addon">
				<i class="fa fa-clock-o"></i>
			</div>
		</div>
		</div>
	</div>

<div class="form-group">
	<label for="day" class="col-sm-4 control-label">Ending Time</label>
	<div class="col-sm-6">
		<div class="input-group">
			<input type="text" name="class_routine_ending" value="<?php if(isset($classRoutineData->class_routine_ending)) { echo $classRoutineData->class_routine_ending; }?>"class="form-control timepicker">
			<div class="input-group-addon">
				<i class="fa fa-clock-o"></i>
			</div>
		</div>
	</div>
</div>
<script>
	$(function () {
		$("#classreg_section_id").change(function () {
			var classreg_section_id=$(this).val();
			$.ajax({
				type:'post',
				data:{classreg_section_id:classreg_section_id},
				url:'<?php echo base_url()?>management/ClassRoutineController/subjectSelection',
				success:function (results) {
					$("#subject_id").html(results);
				}

			});



		});

	});


	</script>
