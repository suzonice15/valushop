<div class="col-md-offset-0 col-md-12">

	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title">
<!--				-->
<!--				<a class="btn btn-info" href="--><?php //echo base_url();?><!--class-routine-create"><i class="fa fa-plus-circle"></i>Add new</span></a>-->

			</h3>
			<br/>
			<br/>
			<br/>
			<?php
							 if(isset($classreg_section_id)) echo $classreg_section_id;?>
	<form action="<?php echo base_url();?>class-routine-view" method="post">
			<div class="row justify-content-md-center" style="margin-bottom: 10px;">
				<div class="col-md-offset-2 col-md-4 ">
					<select class="form-control select2" name="classreg_section_id" id="classreg_section_id" >

						<option value="all">Select class</option>
						<?php foreach ($classSections as $classSection) :?>

						<option
							<?php
							if(isset($classreg_section_id)){
								if($classreg_section_id==$classSection->classreg_section_id){
									echo 'selected';
								}
							}

							?>
							value="<?php echo $classSection->classreg_section_id?> "><?php echo $classSection->classreg_section_name?> </option>

						<?php endforeach;?>
					</select>
				</div>


				<div class="col-md-4 ">
					<button type="submit" id="filter" name="filter" value="filter" class="btn btn-success" style="width:150px" text="center" >Filter</button>
				</div>
			</div>
		</form>

		</div>

	</div>
</div>

<script>

	$(function () {
		$("#filter").submit(function () {
			$("#filterTable").show();
			return false;

		});
		// $("#classreg_section_id").change(function () {
		// 	$("#filterTable").show();
		// })
	});

	</script>
