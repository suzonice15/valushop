<div class="col-md-offset-0 col-md-12">

	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title">
				<!--				-->
				<!--				<a class="btn btn-info" href="--><?php //echo base_url();?><!--class-routine-create"><i class="fa fa-plus-circle"></i>Add new</span></a>-->

			</h3>
			<br/>
			<br/>
			<br/>
			
			<form action="<?php echo base_url();?>class-routine-view" method="post">
				<div class="row justify-content-md-center" style="margin-bottom: 10px;">
					<div class="col-md-offset-2 col-md-4 ">
						<select class="form-control select2" name="classreg_section_id" id="classreg_section_id" >

							<option value="">Select class</option>
							<?php foreach ($classSections as $classSection) :?>

								<option
									<?php
									if(isset($classreg_section)){
										if($classreg_section ==$classSection->classreg_section_id){
											echo 'selected="selected"';
										}
										else{
											echo '';
										}
									}

									?>
									value="<?php echo $classSection->classreg_section_id?>"><?php echo $classSection->classreg_section_name?> </option>

							<?php endforeach;?>
						</select>
					</div>


					<div class="col-md-4 ">
						<button type="submit" id="filter" name="filter" value="filter" class="btn btn-success" style="width:150px" text="center" >Filter</button>
					</div>
				</div>
			</form>

		</div>
		<div class="box-body">

			<table  id="filterTable"  class="table table-bordered table-striped">

				<tr>
				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">Saturday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='saturday'):?>

								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
					<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>
				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">Sunday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='sunday'):?>

								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>


				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">Monday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='monday'):?>

								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>

				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">Tuesday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='tuesday'):?>

								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>

				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">Wednesday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='wednesday'):?>


								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>

				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">thursday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='thursday'):?>


								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>
				<tr>
					<td style="font-weight: bold;
width: 100px;
padding: 43px 13px;">friday</td>
					<td>

						<?php if(isset($classRoutinelists)):
							foreach($classRoutinelists as $classRoom):
								?>
								<?php if($classRoom->class_routine_day=='friday'):?>


								<div class="btn-group text-left">
									<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-folder-open-o"></i> <?php echo $classRoom->subject_name.'  '.$classRoom->subject_code;?> </p>
										<p style="margin-bottom: 0px;"><i class=" fa fa-fw fa-clock-o"></i> <?php echo date('H:nn',strtotime($classRoom->class_routine_starting));?>  -  <?php echo date('H:nn',strtotime($classRoom->class_routine_ending));?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw fa-user"></i> <?php echo $classRoom->teacher_full_name;?> </p>
										<p style="margin-bottom: 0px;"><i class="fa fa-fw  fa-home"></i> <?php echo $classRoom->class_room_name;?></p>
										<span class="caret"></span>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="<?php echo base_url()?>class-routine-edit/<?php echo $classRoom->class_routine_id;?>">Edit</a>
										<a class="dropdown-item" href="<?php echo base_url() ?>class-routine-delete/<?php echo $classRoom->class_routine_id; ?>"   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">Delete</a>
									</div>
								</div>
							<?php endif;?>
							<?php

							endforeach;
						endif;?>


					</td>
				</tr>

				</tbody>

			</table>


		</div>

	</div>
</div>

<script>

	$(function () {
			$("#filterTable").hide();
		var classIdText=$("#classreg_section_id option:selected").text();
		alert(classIdText);
		if(classIdText.length>0)
		{
			$("#filterTable").show();
		}

			// $("#classreg_section_id").change(function () {
			// $("#filterTable").show();
			// return false;
		})
	});
	$(document).on('load','#filterTable',function(){
		$("#filterTable").hide();

	});
</script>
