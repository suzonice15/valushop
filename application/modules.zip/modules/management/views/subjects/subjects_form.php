
<div class="form-group">
	<label for ="field-3" class="col-md-3 control-label">Class name</label>
	<div class="col-md-8">

		<select required name="classreg_id" id="classreg_id" class="form-control select2">
			<?php
			if($class):
				?>
				<option value="">Select class name</option>
				<?php
				foreach($class as $class_data):?>
					<option
						<?php
						$selected=isset($subject->classreg_id) ? $subject->classreg_id == $class_data->classreg_id ? 'selected="selected"':"" :"";
						echo $selected;
						?>

						value="<?php echo $class_data->classreg_id;?>">


						<?php echo $class_data->classreg_name;?></option>

				<?php endforeach;

			else : ?>
				<option value="">There are no class data registration please</option>
			<?php endif; ?>
		</select>
	</div>
</div>


					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Subject name</label>
                        
						<div class="col-sm-8">
							<input required type="text" id="field-1"  value="<?php if (isset($subject)) echo $subject->subject_name; ?>" class="form-control" name="subject_name"  id="subject_name"   placeholder="enter subject name such as: Math">
							<input  type="hidden" id="field-1"  name="subject_id" value="<?php if (isset($subject)) echo $subject->subject_id; ?>" class="form-control" name="subject_name"  id="subject_name"   placeholder="enter subject name such as: Math">
						</div>
					</div>
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label">Subject code</label>
                        
						<div class="col-sm-8">
							<input required type="text" id="field-2"  value="<?php if (isset($subject)) echo $subject->subject_code; ?>" class="form-control" name="subject_code"  id="subject_code"   placeholder="enter subject code such as: 102">
						</div>
					</div>


<div class="form-group">
	<label for ="field-3" class="col-md-3 control-label">Subject Status</label>
	<div class="col-md-8">

		<select required name="subject_status" id="subject_status" class="form-control select2">

			<option value="">Select subject status </option>

			<option value="1"> Full mark	</option>
			<option value="2"> Written and MCQ	</option>
			<option value="3"> Practical	</option>


		</select>
	</div>
</div>
