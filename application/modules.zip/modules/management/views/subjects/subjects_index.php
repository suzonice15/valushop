<div class="col-md-offset-0 col-md-12">

<div class="box box-success ">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>subject-create"><i class="fa fa-plus-circle"></i>Add new</span></a>

			<select required name="shift_id" id="classId" class="form-control select2">
				<option value="" >Select Class </option>
				<?php if(isset($classes)):
					foreach ($classes as $class):
						?>
						<option value="<?php echo $class->classreg_id;?>"><?php echo $class->classreg_name;?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first class </option>
				<?php endif;?>
			</select>
			<select required name="shift_id" id="subjectId" class="form-control select2">
				<option value="" >Select Subject </option>
				<?php if(isset($subjects)):
					foreach ($subjects as $subject):
						?>
						<option value="<?php echo $subject->subject_id;?>"><?php echo $subject->subject_name.'-'.$subject->subject_code;?> </option>
					<?php endforeach; else : ?>
					<option value="">Registration first subject </option>
				<?php endif;?>
			</select>

		</h3>



	</div>
	<div class="box-body">
<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped table">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Class</th>
				<th>Subject</th>
				<th>SubjectCode</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($subjects)):

				$count = sizeof($subjects);
				//var_dump($count);exit();
				foreach ($subjects as $subject):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php
							if($classes):
								foreach ($classes as $row):
									if($subject->classreg_id == $row->classreg_id) :
										echo $row->classreg_name;
									endif;
								endforeach;
							endif;
							?>
						</td>
						<td><?php echo $subject->subject_name; ?></td>
						<td><?php echo $subject->subject_code; ?></td>
						<td>

							<?php if($subject->subject_status ==1): ?>
							<span class="btn btn-block btn-success btn-xs">Full Mark Subject</span>
							<?php elseif($subject->subject_status ==2):?>
							<span class="btn btn-block btn-info btn-xs">Written and MCQ   Subject</span>
							<?php else :?>
							<span class="btn btn-block btn-danger btn-xs">Practical  Subject</span>
							<?php endif;?>




						</td>


						<td>



							<a href="<?php echo base_url() ?>subject-edit/<?php echo $subject->subject_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>subject-delete/<?php echo $subject->subject_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>
<!--						<a href="--><?php //echo base_url() ?><!--mark-multiple/--><?php //echo $subject->subject_id;?><!--">							<span class="glyphicon glyphicon-plus btn btn-info"></span>Marks</a>-->


						</td>

					</tr>

					<?php
					$count--;
				endforeach;
			endif; ?>

			</tbody>
			<tfoot>
			<tr>
				<th>Sl</th>
				<th>Class</th>
				<th>Subject</th>
				<th>SubjectCode</th>
				<th>Action</th>
			</tr>
			</tfoot>
		</table>

</div>

	</div>

</div>
</div>


<script>

	$("#classId").change(function () {
		var classId=$("#classId").val();
		$.ajax({
			type: "POST",
			data: {classreg_id: classId},
			dataType: "json",
			url: '<?php echo base_url();?>Management/SubjectsController/classData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['subject_code']+'</td>'+
'<td><a href="<?php echo base_url() ?>subject-edit/'+result['subject_id']+'" <span class="glyphicon glyphicon-edit btn  btn-success"></span></a><a href="<?php echo base_url() ?>subject-delete/'+result['subject_id']+'" onclick="return confirm("Are you want to delete this information :press Ok for delete otherwise Cancel")"><span class="glyphicon glyphicon-trash btn btn-danger"></span></a></td>' +
					'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#subjectId").change(function () {
		var subjectId=$("#subjectId").val();
		$.ajax({
			type: "POST",
			data: {subject_id: subjectId},
			dataType: "json",
			url: '<?php echo base_url();?>Management/SubjectsController/subjectData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['subject_code']+'</td>'+
						'<td><a href="<?php echo base_url() ?>subject-edit/'+result['subject_id']+'" <span class="glyphicon glyphicon-edit btn  btn-success"></span></a><a href="<?php echo base_url() ?>subject-delete/'+result['subject_id']+'" onclick="return confirm("Are you want to delete this information :press Ok for delete otherwise Cancel")"><span class="glyphicon glyphicon-trash btn btn-danger"></span></a></td>' +
						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#teacherId").change(function () {
		var teacher_id=$("#teacherId").val();
		$.ajax({
			type: "POST",
			data: {teacher_id: teacher_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/SubjectsController/teacherData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['classreg_name']+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>


