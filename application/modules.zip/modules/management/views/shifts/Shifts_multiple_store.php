<div class="col-md-offset-2 col-md-6">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>shift-class-section-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Shift Name</label>

					<div class="col-sm-8">
						<label id="shiftName" class="label label-success">
							<?php

							echo $shiftData->shift_name;

							?></label>

						<input type="hidden" name="shift_id" value="<?php echo $shiftData->shift_id; ?>">

					</div>
				</div>



				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Class Section Name</th>

					</tr>
					</thead>
					<tbody>

					<?php foreach ($classSectionRelations

					as $classSectionRelation) { ?>

					<tr>
						<td>

							<input <?php
							foreach ($shiftClassSectionRelations as $shiftClassSectionRelation) {
								if ($classSectionRelation->classreg_section_id == $shiftClassSectionRelation->classreg_section_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="classreg_section_id_<?php echo $classSectionRelation->classreg_section_id; ?>"
							   name="classreg_section_id[]" value="<?php echo $classSectionRelation->classreg_section_id; ?>"
							/>

						</td>
						<td>

							<label style="font-weight: normal"
								for="classreg_section_id_<?php echo $classSectionRelation->classreg_section_id; ?>"><?php echo $classSectionRelation->classreg_section_name; ?></label>


							<input type="text" name="shift_classreg_section_name[]" readonly
								   value="<?php
								   foreach ($shiftClassSectionRelations as $shiftClassSectionRelation) {
									   if ($classSectionRelation->classreg_section_id == $shiftClassSectionRelation->classreg_section_id) {
										   echo $shiftClassSectionRelation->shift_classreg_section_name;
									   } else {
										   //  echo $shift['teacher_shift_name'];
									   }
								   }

								   ?>

"
								   id="shift_classreg_section_name_<?php echo $classSectionRelation->classreg_section_id; ?>">



						</td>
					</tr>
						<?php

					} ?>
					<tr>
						<td>
							<a  class="btn btn-info " href="<?php echo base_url(); ?>shift-list">Back</a>


						</td>

						<td>
							<input type="submit" class="btn btn-success pull-right" value="Save"/>


						</td>

					</tr>
					</tbody>
				</table>
			</form>
<!--				<div class="form-group">-->
<!--					<label class="col-sm-3 control-label">Class Section Name</label>-->
<!---->
<!--					<div class="col-md-9">-->
<!---->
<!--						--><?php //foreach ($classSectionRelations
//
//						as $classSectionRelation) { ?>
<!--						<div class="checkbox">-->
<!--							<input --><?php
//							foreach ($shiftClassSectionRelations as $shiftClassSectionRelation) {
//								if ($classSectionRelation->classreg_section_id == $shiftClassSectionRelation->classreg_section_id) {
//									echo 'checked';
//								} else {
//									echo '';
//								}
//							}
//
//							?><!-- type="checkbox" class="check"-->
<!--							   id="classreg_section_id_--><?php //echo $classSectionRelation->classreg_section_id; ?><!--"-->
<!--							   name="classreg_section_id[]" value="--><?php //echo $classSectionRelation->classreg_section_id; ?><!--"-->
<!--							/>-->
<!--							<label-->
<!--								for="classreg_section_id_--><?php //echo $classSectionRelation->classreg_section_id; ?><!--">--><?php //echo $classSectionRelation->classreg_section_name; ?><!--</label>-->
<!--							<input type="hidden" name="shift_classreg_section_name[]" readonly-->
<!--								   value="--><?php
//								   foreach ($shiftClassSectionRelations as $shiftClassSectionRelation) {
//									   if ($classSectionRelation->classreg_section_id == $shiftClassSectionRelation->classreg_section_id) {
//										   echo $shiftClassSectionRelation->shift_classreg_section_name;
//									   } else {
//										   //  echo $shift['teacher_shift_name'];
//									   }
//								   }
//
//								   ?>
<!---->
<!--"-->
<!--								   id="shift_classreg_section_name_--><?php //echo $classSectionRelation->classreg_section_id; ?><!--">-->
<!---->
<!---->
<!--							<br>-->
<!---->
<!--							--><?php
//
//							} ?>
<!--						</div>-->
<!--					</div>-->
<!---->
<!--					<div class="box-footer">-->
<!--						<input type="submit" class="btn btn-success pull-right" value="Save"/>-->
<!--						<a style="margin-left: -138px;" class="btn btn-info " href="--><?php //echo base_url(); ?><!--shift-list">Back</a>-->
<!---->
<!--					</div>-->
<!--			</form>-->
		</div>
	</div>





	<script>

		$(".check").click(function () {
			if (this.checked) {
				var label = $("#" + this.id).prop("labels");
				checkBoxText = $(label).text();
				shiftName = $("#shiftName").text();
				$("#shift_classreg_section_name_" + this.value).val(checkBoxText.trim() + "-" + shiftName.trim());

			} else {
				$("#shift_classreg_section_name_" + this.value).val("");


			}

		});

	</script>
