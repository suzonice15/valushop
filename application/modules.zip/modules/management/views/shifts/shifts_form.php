<div class="form-group">
    <label for="shiftName" class="col-sm-3 control-label">Shift Name</label>

    <div class="col-sm-8">
        <input  required type="text" id="shiftName" class="form-control" name="shift_name"
               value="<?php if (isset($shift)) echo $shift->shift_name; ?>" placeholder="Enter Shift Name : Text">
        <input type="hidden" id="shiftId" name="shift_id" value="<?php if (isset($shift)) echo $shift->shift_id; ?>">
    </div>
</div>
					
