
<?php




?>
<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url() ?>attendence-monthly" class="form-horizontal" name="attendaceForm" method="post">
				<div class="table-responsive">
					<table class="table table-bordered table-responsive ">
						<thead>
						<tr>
							<th scope="col"  >Class</th>
							<th scope="col"  >Examination</th>
							<th scope="col"  ></th>
							<th scope="col"  ></th>
						</tr>
						</thead>
						<tbody>
						<tr>
							<td>
								<select required name="classreg_section_id" id="classreg_section_id" class="form-control select2 ">
									<option value="">Select Class</option>
									<?php if (isset($classData)):
										foreach ($classData as $class):

											?>
											<option


												value="<?php echo $class->classreg_section_id; ?>"> <?php echo $class->classreg_section_name; ?> </option>
										<?php endforeach; else : ?>
										<option value="">Registration first student name</option>
									<?php endif; ?>

								</select>
							</td>
							<td>
								<select required name="session_id" id="session_id" class="form-control select2 ">
									<option value="">Select Year</option>
									<?php if (isset($sessions)):
										foreach ($sessions as $session):

											?>
			<option		value="<?php echo $session->session_name; ?>"> <?php echo $session->session_name; ?> </option>
										<?php endforeach; else : ?>
										<option value="">Registration first session name</option>
									<?php endif; ?>

								</select>


							</td>
							<td>
							<td>
								<select name="month" id="month" class="form-control select2">
									<option value="">Select month</option>
									<option value="1">January</option>
									<option value="2">February</option>
									<option value="3">March</option>
									<option value="4" >April</option>
									<option value="5">May</option>
									<option value="6">June</option>
									<option value="7">July</option>
									<option value="8">August</option>
									<option value="9">September</option>
									<option value="10">October</option>
									<option value="11">November</option>
									<option value="12">December</option>
								</select>
							</td>


							<td><input type="submit"  class="btn btn-success pull-right" value="Submit"/></td>
							<td>	<center>
									<button class="btn btn-primary " onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
								</center></td>

						</tr>

						</tbody>
					</table>

					<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
						<h4>Class :<span id="dateShow1"></span></h4>
						<h4>Exam :&nbsp;&nbsp;<span id="dateShow2"></span></h4>
					</div>
				</div>

				<div class="table-responsive">
					<?php
					if(isset($session_Id) && isset($monthId)) {
					$year = $session_Id;
					$ClassId = $ClassId;
					$month = $monthId;
					$number = cal_days_in_month(CAL_GREGORIAN, $month, $year);


					?>
					<table class="table table-bordered">
						<tr style="font-size: 14px;">
							<th width="150px">Student <i class="fa fa-arrow-down"></i> Date <i
									class="fa fa-arrow-right"></i></th>
							<?php for ($k = 1; $k <= $number; $k++) { ?>
								<th><?php echo $k; ?></th>
							<?php } ?>
						</tr>

						<?php foreach ($students as $student) { ?>
							<tr>
								<td><?php echo $student->student_name.'- '.$student->student_roll;

									$student = $student->student_id
									?></td>
								<?php for ($k = 1; $k <= $number; $k++) { ?>
									<td style="">
										<?php
										if ($k < 10) {
											$set_k = "0" . $k;
										} else {
											$set_k = $k;
										}
										if ($month < 10) {
											$set_month = "0" . $month;
										} else {
											$set_month = $month;
										}

										$date = $year . '-' . $set_month . '-' . $set_k;

										$query = "select * from attendances where classreg_section_id=$ClassId and student_id=$student and attendance_date='$date'";
										$attendace = $this->MainModel->SingleQueryData($query);

										$presentCount = 0;
										$leaveCount = 0;
										$absentCount = 0;
										if (isset($attendace)) {
											if ($attendace->attendance_type == 1) {
												echo 'P';
												++$presentCount;
											} elseif ($attendace->attendance_type == 0) {

												echo 'A';
												++$absentCount;

											} else {
												echo 'L';
												++$leaveCount;

											}

										}

										?>

									</td>

								<?php } ?>


							</tr>
							<!--								<td>--><?php //echo $presentCount ?><!--</td>-->
							<!--								<td>--><?php //echo $absentCount ?><!--</td>-->
							<!--								<td>--><?php //echo $leaveCount ?><!--</td>-->
						<?php }
						}
					?>

					</table>
					<?php ?>
				</div></form>
		</div>
</div>
	<script type="text/javascript">

		document.forms['attendaceForm'].elements['classreg_section_id'].value='<?php if(isset($ClassId) ){ echo $ClassId;} ?>'
		document.forms['attendaceForm'].elements['session_id'].value='<?php if(isset($session_Id) ){ echo $session_Id;} ?>'
		document.forms['attendaceForm'].elements['month'].value='<?php if(isset($monthId) ){ echo $monthId;} ?>'
		function  myFunction() {
			window.print()

		}

	</script>
