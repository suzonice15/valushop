<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box">
		<div class="box-header with-border">
			<div class="row">
				<div class="col-md-offset-4 col-md-4 bg-success">
					<h5>Name : <?php  if(isset($attendaces[0])){ echo $attendaces[0]->student_name;}?></h5>
					<h5>Class : <?php  if(isset($attendaces[0])){ echo $attendaces[0]->classreg_name;}?></h5>
					<h5>Section : <?php  if(isset($attendaces[0])){ echo $attendaces[0]->section_name;}?></h5>
					<h5>From : <?php  if(isset($date1)){ echo date('d-m-Y',strtotime($date1));}?></h5>
					<h5>To : <?php  if(isset($date2)){ echo date('d-m-Y',strtotime($date2));}?></h5>
					<h5>Total : <?php  if(isset($total)){ echo $total;}?></h5>
					<h5>Present : <?php  if(isset($present)){ echo $present;}?></h5>
					<h5>Absent : <?php  if(isset($absent)){ echo $absent;}?></h5>
					<h5>Leave : <?php  if(isset($leave)){ echo $leave;}?></h5>
				</div>
				<div class="col-md-4">
					<a onclick="window.print()" class="btn btn-info btn-lg">
						<span class="glyphicon glyphicon-print"></span> Print
					</a>

				</div>
			</div>
		</div>

		<div   class="table-responsive">
			<table class="table table-bordered ">
				<thead>
				<tr>
					<th>Serial</th>
					<th>Date</th>
					<th>Type</th>

					<!--					<th>Action</th>-->
				</tr>
				</thead>
				<tbody>
				<?php if (isset($attendaces)):

					$count = 1;
					//var_dump($count);exit();
					foreach ($attendaces as $attendance):

						?>
						<tr>
							<td><?php echo $count; ?></td>

							<td><?php echo date('d-M-Y', strtotime($attendance->attendance_date)); ?></td>

							<?php
							if ($attendance->attendance_type == 1):
								?>
								<td><p class="btn btn-success ">present</p></td>
							<?php elseif ($attendance->attendance_type == 2): ?>
								<td><p class="btn btn-info ">Leave</p></td>
							<?php else: ?>
								<td><p class="btn btn-danger ">Absent</p></td>
							<?php endif; ?>
						</tr>
						<?php
						$count++;
					endforeach;
				endif; ?>

				</tbody>
			</table>
		</div>
	</div>
</div>
