<div class="col-md-offset-1 col-md-10" >
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body " style="height:auto">

			<form action="<?php echo base_url()?>attendance-multiple-save" class="form-horizontal"  method="post" >

				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col">Attendance Date</th>
						<th scope="col">Class and section same</th>
						<th scope="col"></th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td>

									<div class="input-group date" >
										<input id="attendance_date"  type="text" class="form-control withoutFixedDate" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-th" id="datepicker" ></span>
										</div>
									</div>
						</td>
						<td>
							<select  name="classreg_section_id" id="classregsection_id" class="form-control select2">
								<option value="" >Select class and section name</option>
								<?php
								foreach ($classSectionRelations as $classSectionRelation):
									?>

									<option
										<?php $selectedData= isset($classreg_section_id) ? ($classreg_section_id == $classSectionRelation->classreg_section_id ) ? 'selected="selected"' :"":"" ; echo $selectedData ;?>


										value="<?php echo $classSectionRelation->classreg_section_id; ?>" > <?php echo $classSectionRelation->classreg_section_name;?> </option>
								<?php endforeach; ?>
							</select>

						</td>
						<td>		<input type="submit" value="Show Student" name="attendance" class="btn btn-success pull-right">
						</td>
					</tr>

					</tbody>
				</table>


<?php

if(isset($attendanceData)):
	?>
	<p id="checkId" class="btn btn-success col-md-offset-1" >Mark as present</p>
	<p type="button" id="uncheckId" class="btn btn-danger col-md-offset-2">Mark as absent</p>
	<p type="button" id="leaveId" class="btn btn-info col-md-offset-3">Mark as leave</p>
<table id="tableId" class="table table-bordered table-centered ">
		<thead>
<th>Student Name</th>
<th>Status</th>
</thead>
<tbody>
</tbody>

<?php

	foreach ($attendanceData as $attendance) :

//foreach ($attendanceStudentResults as $attendanceStudentResult):endforeach;

        ?>
<tr>
    <td><?php echo $attendance->student_name;?></td>
    <td>
		<div class="custom-control custom-radio">
        <input
			<?php foreach ($attendanceStudentResults as $attendanceStudentResult) :

			if($attendanceStudentResult->student_id==$attendance->student_id) {
			if($attendanceStudentResult->attendance_type==1){
				echo 'checked';
			}
			}
			endforeach;
			?>

			type="radio" id="" class="checkItem" name="status_<?php echo $attendance->student_id;?>"  value="1" class=""> Present &nbsp;<input

				<?php foreach ($attendanceStudentResults as $attendanceStudentResult) :

					if($attendanceStudentResult->student_id==$attendance->student_id) {
						if($attendanceStudentResult->attendance_type==0){
							echo 'checked';
						}
					}
				endforeach;
				?>
				id="select" class="uncheackItem" type="radio"  name="status_<?php echo $attendance->student_id;?>" value="0" class="" > Absent &nbsp;
	</td>
</tr>
<?php endforeach;
	?>


	</tbody>
</table>

		</div>

		<div class="box-footer">
			<input type="submit" value="Save Attendance" name="saveAttendance" class="btn btn-success pull-right">
			<a class="btn btn-danger " href="<?php echo base_url();?>attendance-list">Cancel</a>

		</div>
		</form>
	</div>

<?php
endif;
?>

<script>
	$(document).ready(function(){

		$("#checkId").click(function () {
			$(".checkItem").prop('checked',true)
		});
		$("#uncheckId").click(function () {
			$(".uncheackItem").prop('checked',true)
		});
		$("#leaveId").click(function () {
			$(".leaveItem").prop('checked',true)
		});
		var class_id= $("#class_id").val();
		if(class_id>0) {
			$("#studentList").hide("fast");
		}


//
//	$("#classregsection_id").change(function () {
//		var classreg_section_id=$("#classregsection_id").val();
//		var attendance_date=$("#attendance_date").val();
//		alert(attendance_date)
//		$.ajax({
//			type: "POST",
//			data: {classreg_section_id: classreg_section_id,attendance_date:attendance_date},
//			url: '<?php //echo base_url();?>//management/AttendancesController/studentSelectionlist',
//			success: function (results) {
//
//	var str ="";
//	var str1 ="";
//				$.each(results['students'], function (key, result) {
//					var key=key+1;
//					debugger;
//alert(result)
//					str ='<tr>'+
//						'<td>'+key+'</td>'+
//						'<td>'+result['student_name']+'</td>'+
//						'<td><div class="custom-control custom-radio">' +
//	'<input    type="radio" id="" class="checkItem" name="status_'+result['student_id']+'"  value="1" >  Present &nbsp;' +
//	'<input   id="select" class="uncheackItem" type="radio"  name="status_'+result['student_id']+'" value="0" > Absent &nbsp;'+
//	' <input	id="select" class="leaveItem" type="radio" name="status_'+result['student_id']+'" value="2" class="" > leave &nbsp;'+
//				'</div></td>'+
//						'</tr>';
//					str1=str1+str;
//				});
//				$("#tableId tbody").empty();
//				$("#tableId tbody").append(str1);
//			}
//		});
//	});
	});
</script>

