



<div class="form-group " >
	<label for="date" class="col-sm-4 control-label">Date:</label>

	<div class="col-sm-7">
	<div class="input-group date" >
		<input id="datepicker" required type="text" class="form-control datepicker" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
		<div class="input-group-addon">
			<span class="glyphicon glyphicon-th"></span>
		</div>
	</div>
	</div>
	<!-- /.input group -->
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Class & Section Name:</label>

	<div class="col-sm-7">

		<select required name="classreg_section_id" id="classregsection_id" onchange="return selectStudent()" class="form-control">
			<option value="" >Select class & section name</option>
			<?php
				foreach ($classSectionRelations as $classSectionRelation):
					?>
<!--<?php $classData= isset($class_id) ? ($class_id == $classSectionRelation->classreg_id ) ? 'selected="selected"' :"":"" ; echo $classData ;?>-->

				<option  value="<?php echo $classSectionRelation->classreg_section_id; ?>" > <?php echo $classSectionRelation->classreg_section_name;?> </option>
				<?php endforeach; ?>
		</select>


	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Student Name:</label>

	<div class="col-sm-7">

		<select  hidden class="form-control" name="student_id" id="student_id">
			<option value="">Select class and section first</option>
		</select>


	</div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Attendance type:</label>

	<div class="col-sm-7">

		<select   class="form-control" name="attendance_type" id="attendance_type">
			<option value="1">present</option>
			<option value="0">Absent</option>
		</select>


	</div>
</div>


<!--
<?php

if(isset($attendanceData)):
?>
	<p id="checkId" class="btn btn-success col-md-offset-1" >Mark as present</p>
	<p type="button" id="uncheckId" class="btn btn-danger col-md-offset-4">Mark as absent</p>
<table id="tableId" class="table table-bordered table-centered ">
		<thead>
<th>Student Name</th>
<th>Status</th>
</thead>
<tbody>

<?php

foreach ($attendanceData as $attendance) :?>
<tr>
    <td><?php echo $attendance->student_name;?></td>
    <td>   <div class="custom-control custom-radio">
			<input name="student_id[]" type="hidden" value="<?php echo $attendance->student_id;?>"/>
			<input name="class_id" type="hidden" value="<?php if(isset($class_id)){ echo $class_id; }?>"/>
			<input name="section_id" type="hidden" value="<?php if(isset($section_id)){ echo $section_id; }?>"/>
			<input name="attendance_date" type="hidden" value="<?php if(isset($attendance_date)){ echo $attendance_date; }?>"/>

            <input type="radio" id="" class="checkItem" name="status_<?php echo $attendance->student_id;?>"  value="1" class=""> Present &nbsp;
            <input id="select" class="uncheackItem" type="radio" id="" name="status_<?php echo $attendance->student_id;?>" value="0" class="" > Absent &nbsp;
        </div></td>
</tr>
<?php endforeach;
	?>
	<tr><td></td><td>
		<input type="submit" value="Update Attendance"" name="attendance" class="btn btn-success">
		</td>
	</tr>

	</tbody>
</table>


<?php
endif;
?>
-->
<script>
	$(document).ready(function(){

		$("#checkId").click(function () {
			$(".checkItem").prop('checked',true)
		});
		$("#uncheckId").click(function () {
			$(".uncheackItem").prop('checked',true)
		});
 var class_id= $("#class_id").val();
 if(class_id>0) {
	 $("#studentList").hide("fast");
 }

	});

	function selectStudent() {
		var classreg_section_id = $('#classregsection_id').val();
		//alert(classregsection_id);
		$.ajax({
			type: "POST",
			data: {classreg_section_id : classreg_section_id},
			url: '<?php echo base_url() ;?>Management/AttendancesController/selectStudent',
			success: function (result) {
				if (result) {
					$('#student_id').html(result);
					return false;
				} else {
					return false;
				}
			}
		});
		return false;
	}

</script>


<script>
	$(document).ready(function () {
		$('#add_attendance').submit(function () {
				var class_id = $('#class_id').val();
				$.ajax({
					type: "POST",
					url: '<?php echo base_url() ?>Management/AttendancesController/Attendance',
					data: {class_id : class_id },
					success: function (result) {
						if (result) {
							$('#add_msg').html(result);
							$('#fadeout').show(5000));

					}
				});
				return false ;

			}
		});
		});

</script>

