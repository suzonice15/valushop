<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<div class="row">
				<div class="col-md-9">

					<div class="nav-tabs-custom">
						<ul class="nav nav-tabs">
							<li class=""><a href="#tab_1" data-toggle="tab" aria-expanded="false">Take attendance</a></li>
							<li class="active"><a href="#tab_2" data-toggle="tab" aria-expanded="true">
									Student tracking</a></li>
							<li class=""><a href="#tab_3" data-toggle="tab" aria-expanded="false">Class traking</a></li>
						</ul>
						<div class="tab-content">
													<div class="tab-pane" id="tab_1">
														<div class="table-responsive">
															<table class="table table-bordered">
																<thead>
																<tr>
																	<th scope="col"></th>

																</tr>
																</thead>
																<tbody>
																<tr>

																	<td>
																		<a class="btn btn-info" href="
							<?php echo base_url();?>attendance-multiple"><i class="fa fa-plus-circle"></i> Attendance</span></a>
																	</td>

																	</td>



																</tr>

																</tbody>
															</table>
														</div>

													</div>

							<div class="tab-pane active" id="tab_2">
								<div class="table-responsive">
									<table class="table table-bordered">
										<thead>
										<tr>
											<th scope="col">From</th>
											<th scope="col">To</th>
											<th scope="col">Class </th>
											<th scope="col">Student</th>
										</tr>
										</thead>
										<tbody>
										<tr>

											<form action="<?php echo base_url()?>single-student-attendace-report" method="post">

											<td>
												<div class="input-group date">
													<input id="date1" type="text" name="date1" class="datepicker"
														    value="">
													<div class="input-group-addon">
														<span class="glyphicon glyphicon-th" id="datepicker"></span>
													</div>
												</div>
											</td>
											<td>
												<div class="input-group date">
													<input id="date2" type="text" name="date2" class="form-control datepicker"
														   value="">
													<div class="input-group-addon">
														<span class="glyphicon glyphicon-th" id="datepicker"></span>
													</div>
												</div>
											</td>
											<td>
												<select id="classSectionId" name="classreg_section_id" class="form-control select2">
													<option value="">Select Class and Session</option>
													<?php if (isset($classsections)):
														foreach ($classsections as $classsection):
															?>
															<option
																value="<?php echo $classsection->classreg_section_id; ?>"><?php echo $classsection->classreg_section_name; ?> </option>
														<?php endforeach; else : ?>
														<option value="">Registration first examsession</option>
													<?php endif; ?>
												</select>

											</td>
											<td>
												<select id="studentId" name="student_id" class="form-control select2">

													<option value="">Select class section</option>

												</select>

											</td>
												<td><input type="submit" class="btn btn-success" value="Print"></td>
											</form>

										</tr>

										</tbody>
									</table>
									<div class="col-md-offset-4 col-md-4 bg-success">
										<h4>Class : <span id="studentClassResultId"></span></h4>
										<h4>Student : <span id="studentNameResultId"></span></h4>
										<h4>From : <span id="studentFromDateId"></span></h4>
										<h4>To : <span id="studentToDateId"></span></h4>
										<h4>Total : <span id="studenttotalId"></span></h4>
										<h4>Present : <span id="studentpresentResultId"></span></h4>
										<h4>Absent : <span id="studentAbsentResultId"></span></h4>
										<h4>Leave : <span id="studentleaveResultId"></span></h4>
									</div>
								</div>


							</div>
							<!-- /.tab-pane -->
							<div class="tab-pane" id="tab_3">
								<div class="table-responsive">
									<table class="table table-bordered">
										<thead>
										<tr>
											<th scope="col">Date</th>
											<th scope="col">Class and Section</th>
										</tr>
										</thead>
										<tbody>
										<form action="<?php echo base_url()?>class-wise-student-report-print" method="post">
										<tr>

											<td>
												<div class="input-group date">
													<input  type="text"  name="date_id" class="form-control datepicker"
														   id="ClasswiseAttendaceDateID" value="">
													<div class="input-group-addon">
														<span class="glyphicon glyphicon-th" ></span>
													</div>
												</div>
											</td>

											</td>
											<td>
												<select id="classSectionIdByclass" name="classreg_section_id" class="form-control select2">
													<option value="">Select Class and Session</option>
													<?php if (isset($classsections)):
														foreach ($classsections as $classsection):
															?>
															<option
																value="<?php echo $classsection->classreg_section_id; ?>"><?php echo $classsection->classreg_section_name; ?> </option>
														<?php endforeach; else : ?>
														<option value="">Registration first examsession</option>
													<?php endif; ?>
												</select>

											</td>
											<td><input type="submit" class="btn btn-success" value="Print"></td>


										</tr>
										</form>

										</tbody>
									</table>

								<div class="col-md-offset-4 col-md-4 bg-success">
									<h4>Class : <span id="classResultId"></span></h4>
									<h4>Month : <span id="monthResultId"></span></h4>
									<h4>Total : <span id="totalId"></span></h4>
									<h4>Present : <span id="presentResultId"></span></h4>
									<h4>Absent : <span id="AbsentResultId"></span></h4>
									<h4>Leave : <span id="leaveResultId"></span></h4>
								</div>
								</div>

							</div>
							<!-- /.tab-pane -->
						</div>
						<!-- /.tab-content -->
					</div>
					<!-- nav-tabs-custom -->
				</div>
				<!-- /.col -->


			</div>


		</div>
		<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped table-responsive ">
					<thead>
					<tr>
						<th>Serial</th>
						<th>Date</th>
						<th>ClassName</th>
						<th>SectionName</th>
						<th>StudentName</th>
						<th>Type</th>

						<!--					<th>Action</th>-->
					</tr>
					</thead>
					<tbody>
					<?php if (isset($attendances)):

						$count = 1;
						//var_dump($count);exit();
						foreach ($attendances as $attendance):

							?>
							<tr>
								<td><?php echo $count; ?></td>

								<td><?php echo date('d-M-Y', strtotime($attendance->attendance_date)); ?></td>
								<td><?php echo $attendance->class_name; ?></td>
								<td><?php echo $attendance->section_name; ?></td>
								<td><?php echo $attendance->student_name; ?></td>
								<?php
								if ($attendance->attendance_type == 1):

									?>
									<td><p class="btn btn-success ">present</p></td>
								<?php elseif ($attendance->attendance_type == 2): ?>
									<td><p class="btn btn-info ">Leave</p></td>
								<?php else: ?>
									<td><p class="btn btn-danger ">Absent</p></td>
								<?php endif; ?>

							</tr>

							<?php
							$count++;
						endforeach;
					endif; ?>

					</tbody>

				</table>


			</div>
		</div>

	</div>
</div>

<script>

	$("#classSectionId").change(function () {
		var classreg_section_id = $("#classSectionId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id},
			url: '<?php echo base_url();?>Management/AttendancesController/studentSelectionData',
			success: function (results) {
				$("#studentId").html(results);
			}
		});
	});
	$("#classSectionIdByclass").change(function () {
		var classreg_section_id = $("#classSectionIdByclass").val();
		var date_id = $("#ClasswiseAttendaceDateID").val();
		var classTextData = $("#classSectionIdByclass option:selected").text();
		var date_id = $("#ClasswiseAttendaceDateID").val();
		$("#classResultId").text(classTextData);
		$("#monthResultId").text(date_id);


		$.ajax({
			type: "POST",
			data: {classreg_section_id: classreg_section_id, date_id: date_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/AttendancesController/classSectionAttendance',
			success: function (results) {
				debugger
				var str = "";
				var str1 = "";
				$("#presentResultId").text(results['present']);
				$("#AbsentResultId").text(results['absent']);
				$("#leaveResultId").text(results['leave']);
				$("#totalId").text(results['total']);
				$.each(results['examSesseionData'], function (key, result) {
					var key = key + 1;

					if (result['attendance_type'] == 1) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-success">Present</p></td>' +
							'</tr>';
					}

					if (result['attendance_type'] == 2) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-info">Leave</p></td>' +
							'</tr>';
					}
					else {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-danger">Absent</p></td>' +
							'</tr>';
					}

					str1 = str1 + str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});


	$("#studentId").change(function () {
		var classreg_section_id = $("#classSectionId").val();
		var date1 = $("#date1").val();
		var date2 = $("#date2").val();
		var student_id = $("#studentId").val();
		var classTextData = $("#classSectionId option:selected").text();
		var studentText = $("#studentId option:selected").text();
		var date_id = $("#ClasswiseAttendaceDateID").val();
		$("#studentClassResultId").text(classTextData);
		$("#studentNameResultId").text(studentText);
		$("#studentFromDateId").text(date1);
		$("#studentToDateId").text(date2);

		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id, date1: date1,date2: date2, student_id: student_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/AttendancesController/studentWiseAttendace',
			success: function (results) {
				$("#studentpresentResultId").text(results['present']);
				$("#studentAbsentResultId").text(results['absent']);
				$("#studentleaveResultId").text(results['leave']);
				$("#studenttotalId").text(results['total']);
				var str = "";
				var str1 = "";
				$.each(results['attendaces'], function (key, result) {
					var key = key + 1;
					if (result['attendance_type'] == 1) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-success">present</p></td>' +
							'</tr>';
					}
					if (result['attendance_type'] == 2) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-info">Leave</p></td>' +
							'</tr>';
					}
					else {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['attendance_date'] + '</td>' +
							'<td>' + result['classreg_name'] + '</td>' +
							'<td>' + result['section_name'] + '</td>' +
							'<td>' + result['student_name'] + '</td>' +
							'<td><p class="btn btn-danger">absent</p></td>' +
							'</tr>';
					}

					str1 = str1 + str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});


</script>
