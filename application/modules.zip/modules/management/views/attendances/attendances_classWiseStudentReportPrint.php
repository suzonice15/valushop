<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box">
		<div class="box-header with-border">
			<div class="row">
				<div class="col-md-offset-4 col-md-4 bg-success">
					<h4>Class : <?php  if(isset($attendances)){ echo $attendances[0]->classreg_name;}?></h4>
					<h4>Section : <?php  if(isset($attendances)){ echo $attendances[0]->section_name;}?></h4>
					<h4>Month : <?php  if(isset($attendances)){ echo date('F',strtotime($attendances[0]->attendance_date));}?></h4>
					<h4>Total : <?php  if(isset($total)){ echo $total;}?></h4>
					<h4>Present : <?php  if(isset($present)){ echo $present;}?></h4>
					<h4>Absent : <?php  if(isset($absent)){ echo $absent;}?></h4>
					<h4>Leave : <?php  if(isset($leave)){ echo $leave;}?></h4>
				</div>
				<div class="col-md-4">
					<a onclick="window.print()" class="btn btn-info btn-lg">
						<span class="glyphicon glyphicon-print"></span> Print
					</a>

				</div>
			</div>
		</div>

		<div   class="table-responsive">
			<table class="table table-bordered ">
				<thead>
				<tr>
					<th>Serial</th>
					<th>Date</th>

					<th>StudentName</th>
					<th>Type</th>

					<!--					<th>Action</th>-->
				</tr>
				</thead>
				<tbody>
				<?php if (isset($attendances)):

					$count = 1;
					//var_dump($count);exit();
					foreach ($attendances as $attendance):

						?>
						<tr>
							<td><?php echo $count; ?></td>

							<td><?php echo date('d-M-Y', strtotime($attendance->attendance_date)); ?></td>

							<td><?php echo $attendance->student_name; ?></td>
							<?php
							if ($attendance->attendance_type == 1):

								?>
								<td><p class="btn btn-success ">present</p></td>
							<?php elseif ($attendance->attendance_type == 2): ?>
								<td><p class="btn btn-info ">Leave</p></td>
							<?php else: ?>
								<td><p class="btn btn-danger ">Absent</p></td>
							<?php endif; ?>

						</tr>

						<?php
						$count++;
					endforeach;
				endif; ?>

				</tbody>
			</table>
		</div>
	</div>
</div>
