			<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Session name</label>
                        
						<div class="col-sm-6">
							<input required type="text" id="field-1"  class="form-control" name="session_name"   
							value="<?php   if(isset($session) ) echo $session->session_name;?>" placeholder="enter session name : 2010">
							<input  type="hidden"  name="session_id" 	value="<?php   if(isset($session) ) echo $session->session_id;?>" >
						</div>
					</div>
					
					<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Session start date</label>
                        
						<div class="col-sm-6">
							<div class="input-group date" >
							<input  required type="text" id="field-1"  class="form-control datepicker" name="session_start_date"
							value="<?php   if(isset($session) ) echo date('d-m-Y',strtotime($session->session_start_date));?>" placeholder=" session start : 1-1-2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="field-1" class="col-sm-4 control-label">Session end date</label>

						<div class="col-sm-6">
							<div class="input-group date" >
								<input  required type="text" id="session_end_date_datepicker"  class="form-control datepicker" name="session_end_date"
										value="<?php   if(isset($session) )echo date('d-m-Y',strtotime($session->session_end_date));?>" placeholder="session end : 1/1/2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th"></span>
								</div>
							</div>
						</div>
					</div>

