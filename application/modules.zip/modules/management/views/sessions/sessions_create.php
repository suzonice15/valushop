<div class="col-md-offset-2 col-md-7" style="margin-top: 100px;">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">
         
		<form action="<?php echo base_url()?>session-save" class="form-horizontal"  method="post" >
		<span style="text-align:center;color:red"><?php echo validation_errors(); ?></span>
		<?php $this->load->view('sessions_form');?>
		
		</div>

			<div class="box-footer">
				<input type="submit" class="btn btn-success pull-right" value="Save"/>
				<a class="btn btn-danger " href="<?php echo base_url();?>session-list">Cancel</a>

			</div>
		</form>
        </div>
