<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>session-create"><i class="fa fa-plus-circle"></i>Add new</a></h3>


	</div>
	<div class="box-body">
	<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
				<th>SessionName</th>
				<th>SessionStart</th>
				<th>SessionEnd</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if(isset($sessions)):

				$count=1;
				foreach($sessions as $result):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $result->session_name;?></td>
						<td><?php  echo date('d-M-Y',strtotime($result->session_start_date));?></td>
						<td><?php echo date('d-M-Y',strtotime($result->session_end_date));?></td>
						<td>

							<a href="<?php echo base_url() ?>session-edit/<?php echo $result->session_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>session-delete/<?php echo $result->session_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>
							<a href="<?php echo base_url() ?>exam-session-multiple/<?php echo $result->session_id; ?>"
							<span class="glyphicon glyphicon-plus-sign btn btn-primary"></span>Examinations
							</a>




						</td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif;?>

			</tbody>
<!--			<tfoot>-->
<!--			<tr>-->
<!--				<th>serial</th>-->
<!--				<th>sessionName</th>-->
<!--				<th>sessionStart</th>-->
<!--				<th>sessionEnd</th>-->
<!--				<th>Action</th>-->
<!--			</tr>-->
<!--			</tfoot>-->
		</table>


	</div>
	</div>
	</div>

</div>
