<div class="col-md-offset-0 col-md-12">

<div class="box  box-success ">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-info" href="<?php echo base_url();?>expense-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Category Name  </th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($expenses)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($expenses as $expense):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $expense->expense_category_name; ?></td>
						<td>
							<a href="<?php echo base_url() ?>expense-edit/<?php echo $expense->expense_category_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>expense-delete/<?php echo $expense->expense_category_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
							<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>



						</td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
</div>

