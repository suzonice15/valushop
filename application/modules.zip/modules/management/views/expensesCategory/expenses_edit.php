<div class="col-md-offset-2 col-md-8">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

        <form action="<?php echo base_url() ?>expense-update" name="category" class="form-horizontal" method="post">
            <?php $this->load->view('expenses_form'); ?>

    </div>

	<div class="box-footer">
		<input type="submit" class="btn btn-success pull-right" value="Update"/>
		<a class="btn btn-danger " href="<?php echo base_url();?>expense-list">Cancel</a>

	</div>
    </form>
</div>

    <script type="text/javascript">

        document.forms['category'].elements['expense_category_status'].value=<?php echo $expense->expense_category_status; ?>;

    </script>
