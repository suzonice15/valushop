<div class="form-group">
    <label for="shiftName" class="col-md-2 control-label">Category Name</label>

    <div class="col-md-8">
        <input  required type="text" id="shiftName" class="form-control" name="expense_category_name"
               value="<?php if (isset($expense)) echo $expense->expense_category_name; ?>" placeholder="
Expense / Expense Category Name
">
        <input type="hidden" id="shiftId" name="expense_category_id" value="<?php if (isset($expense)) echo $expense->expense_category_id; ?>">
    </div>
</div>

<div class="form-group">
    <label for="shiftName" class="col-md-2 control-label">Category Type</label>

    <div class="col-md-8">
        <select name="expense_category_status" class="form-control select2" required >
            <option value="">Select Category</option>
            <option value="1">Student Fee Category </option>
            <option value="2">Student Abasic Fee Category </option>
            <option value="3">Expense Category </option>
            <option value="4">Madrasah Dan Income Category</option>
            <option value="5">Madrasah   Income Category</option>
        </select>

    </div>
</div>

