
<div class="col-md-offset-2 col-md-6">
<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<form id="add_thana_frm" action="<?php echo base_url() ?>teacher-shift-multiple-save"
				  class="form-horizontal" method="post">
				<div class="form-group">
					<label for="shiftName" class="col-sm-3 control-label">Shift Name</label>

					<div class="col-sm-4">
						<h4><label id="shiftName" class="label label-success">
							<?php

							echo $shiftRelation[0]['shift_name'];

							?></label></h4>

						<input type="hidden" name="shift_id" value="<?php echo $shiftRelation[0]['shift_id'];; ?>">

					</div>
				</div>


				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Teacher Name
						</th>

					</tr>
					</thead>
					<tbody>
					<?php foreach ($teachers

					as $teacher) { ?>

					<tr>

						<td>

							<input <?php
							foreach ($shiftRelation as $shift) {
								if ($shift['teacher_id'] == $teacher->teacher_id) {
									echo 'checked';
								} else {
									echo '';
								}
							}

							?> type="checkbox" class="check"
							   id="teacher_id_<?php echo $teacher->teacher_id; ?>"
							   name="teacher_id[]" value="<?php echo $teacher->teacher_id; ?>"
							/>

						</td>
						<td>
							<label style="font-weight: normal"
								for="teacher_id_<?php echo $teacher->teacher_id; ?>"><?php echo $teacher->teacher_full_name; ?></label>



							<input type="text" name="teacher_shift_name[]" readonly
								   value="<?php
								   foreach ($shiftRelation as $shift) {
									   if ($shift['teacher_id'] == $teacher->teacher_id) {
										   echo $shift['teacher_shift_name'];
									   } else {
										   //  echo $shift['teacher_shift_name'];
									   }
								   }

								   ?>

"
								   id="teacher_shift_name_<?php echo $teacher->teacher_id; ?>">



						</td>
					</tr>

						<?php

						} ?>
						<tr>
							<td>
								<a  class="btn btn-info " href="<?php echo base_url(); ?>shift-list">Back</a>
							</td>

							<td>
								<input type="submit" class="btn btn-success pull-right" value="Save"/>

							</td>
						</tr>

					</tbody>
				</table>
			</form>
</div>
</div>
</div>

<script>

	$(".check").click(function () {
		if (this.checked) {
			var label = $("#" + this.id).prop("labels");
			checkBoxText = $(label).text();
			shiftName = $("#shiftName").text();
			$("#teacher_shift_name_" + this.value).val(checkBoxText.trim() + "-" + shiftName.trim());

		} else {
			$("#teacher_shift_name_" + this.value).val("");


		}

	});

</script>


