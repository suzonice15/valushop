<h1>Monipur school </h1>
<p>Report for</p>
<h3>shift:<?php echo $teacherRelation[0]->shift_name; ?> </h3>
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

		<div class="box-body">

			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped">
					<thead>

					<tr>
						<th>Serial</th>
						<!--				<th>teacherShiftName </th>-->
						<th>Shift</th>
						<th>Teacher </th>
						<th>Contact number </th>

						<!--				<th>Action</th>-->
					</tr>
					</thead>
					<tbody>
					<?php if (isset($teacherRelation)):

						$count = sizeof($teacherRelation);
						//var_dump($count);exit();
						foreach ($teacherRelation as $teacher_data):

							?>
							<tr>
								<td><?php echo $count; ?></td>
								<td><?php echo $teacher_data->shift_name; ?></td>
								<td><?php echo $teacher_data->teacher_full_name; ?></td>
								<td><?php echo $teacher_data->teacher_contact_no; ?></td>

							</tr>

							<?php
							$count--;
						endforeach;
					endif; ?>

					</tbody>

				</table>
			</div>


		</div>


	</div>
</div>
