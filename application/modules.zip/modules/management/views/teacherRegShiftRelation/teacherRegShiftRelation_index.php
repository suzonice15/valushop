<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border ">


		<table class="table table-bordered col-md-offset-4 col-md-4">
			<thead>
			<tr>
				<th scope="col" width="200">shift </th>
<!--				<th scope="col">Teacher</th>-->
				<th scope="col"></th>

			</tr>
			</thead>
			<tbody>
			<form action="<?php echo base_url();?>shift-report" method="post">
			<tr>

				<td>
					<select required name="shift_id" id="shiftId" class="form-control select2">
						<option value="" >Select Shift </option>
						<?php if(isset($shifts)):
							foreach ($shifts as $shift):
								?>
								<option value="<?php echo $shift->shift_id;?>"><?php echo $shift->shift_name;?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first shift name</option>
						<?php endif;?>
					</select>
				</td>
<!--				<td>-->
<!--					<select required name="teacher_id" id="teacherId" class="form-control select2">-->
<!--						<option value="" >Select teacher</option>-->
<!--						--><?php //if(isset($teachers)):
//							foreach ($teachers as $teacher):
//
//
//								?>
<!--								<option value="--><?php //echo $teacher->teacher_id; ?><!--"> --><?php //echo $teacher->teacher_full_name;?><!-- </option>-->
<!--							--><?php //endforeach; else : ?>
<!--							<option value="">Registration first teacher name</option>-->
<!--						--><?php //endif;?>
<!--					</select>-->
<!---->
<!--				</td>-->


				<td> <input type="submit" value="Print" /></td>


			</tr>

			</tbody>
		</table>
	</form>

		<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-4 bg-success">
			<h4>Shift :<span id="dateShow1"></span></h4>
		</div>

	</div>


	<div class="box-body">

		<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped">
			<thead>

			<tr>
				<th>Serial</th>
<!--				<th>teacherShiftName </th>-->
				<th>Shift</th>
				<th>Teacher </th>
				<th>Contact number </th>

<!--				<th>Action</th>-->
			</tr>
			</thead>
			<tbody>
			<?php if (isset($teacherRelation)):

				$count = sizeof($teacherRelation);
				//var_dump($count);exit();
				foreach ($teacherRelation as $teacher_data):

					?>
					<tr>
						<td><?php echo $count; ?></td>
<!--						<td>--><?php //echo $teacher_data->teacher_shift_name; ?><!--</td>-->
						<td><?php echo $teacher_data->shift_name; ?></td>
						<td><?php echo $teacher_data->teacher_name; ?></td>
						<td><?php echo $teacher_data->teacher_contact_no; ?></td>

					</tr>

					<?php
					$count--;
				endforeach;
			endif; ?>

			</tbody>

		</table>
		</div>


	</div>



</div>
</div>
   <script>

	   $("#shiftId").change(function () {
		   var expense_category = $("#shiftId option:selected").text();
		   $("#resultShow").show();
		   $("#dateShow1").text(expense_category);
	   });

	$("#shiftId").change(function () {
		var shift_id=$("#shiftId").val();
		$.ajax({
			type: "POST",
			data: {shift_id: shift_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/TeacherRegShiftRelationController/shiftSelection',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['shift_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	$("#teacherId").change(function () {
		var teacher_id=$("#teacherId").val();
		$.ajax({
			type: "POST",
			data: {teacher_id: teacher_id},
			dataType: "json",
			url: '<?php echo base_url();?>Management/TeacherRegShiftRelationController/teacherSelection',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results, function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['shift_name']+'</td>'+
						'<td>'+result['teacher_full_name']+'</td>'+
						'<td>'+result['teacher_contact_no']+'</td>'+

						'</tr>';

					str1=str1+str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

	</script>
