


<div class="form-group">
<!--	<label for="shiftName" class="col-md-4 control-label">Teacher and Shift Name</label>-->

	<div class="col-md-6">

		<input  type="hidden" name="teacher_shift_name" id="teacher_shift_name" placeholder=" enter exam name" value="<?php if (isset($teacherRelation)) echo $teacherRelation->teacher_shift_name; ?>" class="form-control "/>
	</div>
</div>
<div class="form-group">
    <label for="shiftName" class="col-sm-4 control-label">Teacher Name</label>

    <div class="col-sm-6">

		<select required name="teacher_id" id="teacher_id" class="form-control select2">
			<option value="" >Select teacher name</option>
			<?php if(isset($teacher)):
				foreach ($teacher as $teacher_row):


				?>
			<option <?php if(isset($teacherRelation->teacher_id )): if($teacherRelation->teacher_id == $teacher_row->teacher_id)  : echo 'selected'; else : endif; endif; ?> value="<?php echo $teacher_row->teacher_id; ?>" ><?php echo $teacher_row->teacher_full_name;?> </option>
			<?php endforeach; else : ?>
			<option value="">Registration first teacher name</option>
			<?php endif;?>
		</select>
		<input type="hidden"  name="teacher_shift_id" value="<?php if (isset($teacherRelation)) echo $teacherRelation->teacher_shift_id; ?>">

          </div>
</div>

<div class="form-group">
	<label for="shiftName" class="col-sm-4 control-label">Shift Name</label>

	<div class="col-sm-6">
		<select required name="shift_id"    id="shift_id" class="form-control select2 ">
			<option value="" >Select shift name</option>
			<?php if(isset($shift)):
				foreach ($shift as $shift_row):

					?>
					<option <?php if(isset($teacherRelation->shift_id )) : if($teacherRelation->shift_id == $shift_row->shift_id ):  echo 'selected'; else : echo '';endif;endif; ?> value="<?php echo $shift_row->shift_id; ?>" > <?php echo $shift_row->shift_name;?> </option>
				<?php endforeach; else : ?>
				<option value="">Registration first section name</option>
			<?php endif;?>
		</select>
	</div>
</div>

<script>


	$("#shift_id ,#teacher_id").change(function () {
		var teacher_id = $("#teacher_id option:selected ").text();
		var shift_id = $("#shift_id option:selected ").text();
		var teacherShiftRelation= teacher_id + '-' + shift_id;
		$("#teacher_shift_name").val(teacherShiftRelation);
	});


</script>





