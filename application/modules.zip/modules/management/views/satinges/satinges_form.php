<div class="form-group">
    <label for="shiftName" class="col-sm-3 control-label">School Name</label>

    <div class="col-sm-8">
        <input  required type="text" id="shiftName" class="form-control" name="satinge_name"
               value="<?php if (isset($sating)) echo $sating->satinge_name; ?>" >
        <input type="hidden" id="shiftId" name="satinge_id" value="<?php if (isset($sating)) echo $sating->satinge_id; ?>">
    </div>
</div>
<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">School slug </label>

	<div class="col-sm-8">
		<input  required type="text" id="shiftName" class="form-control" name="satinge_slug"
				value="<?php if (isset($sating)) echo $sating->satinge_slug; ?>" placeholder="Enter Shift Name : Text">
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">School contacr number </label>

	<div class="col-sm-8">
		<input  required type="text" id="shiftName" class="form-control" name="satinge_mobile"
				value="<?php if (isset($sating)) echo $sating->satinge_mobile; ?>" placeholder="Enter Shift Name : Text">
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">School contact email </label>

	<div class="col-sm-8">
		<input  required type="email" id="shiftName" class="form-control" name="satinge_email"
				value="<?php if (isset($sating)) echo $sating->satinge_email; ?>" placeholder="Enter Shift Name : Text">
	</div>
</div>


<div class="form-group">
	<label for="shiftName" class="col-sm-3 control-label">School address </label>

	<div class="col-sm-8">
		<input  required type="text" id="shiftName" class="form-control" name="satinge_address"
				value="<?php if (isset($sating)) echo $sating->satinge_address; ?>" placeholder="Enter Shift Name : Text">
	</div>
</div>

<?php if(!empty($sating->satinge_logo)):?>

	<div class="form-group">
		<label for="field-1" class="col-sm-3 control-label">School logo</label>
		<div class="col-md-7">
			<img width="70" height="60" src="<?php echo base_url(); if(isset($sating)){ echo $sating->satinge_logo;} ?>"/>
			<input type="hidden"  class="form-control" name="old_satinge_logo" value="<?php  if(isset($sating)){ echo $sating->satinge_logo;} ?>">
		</div>
	</div>
<?php else :?>

<?php endif;?>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">School logo</label>

	<div class="col-md-7">
		<input type="file" id="field-1" class="form-control" name="satinge_logo">
	</div>
</div>







					
