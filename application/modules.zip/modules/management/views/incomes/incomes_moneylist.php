<div class="col-md-offset-0 col-md-12">

	<div   id="printable"  class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>

							<td><a class="btn btn-info" href="<?php echo base_url();?>income-money-create"><i class="fa fa-plus-circle"></i>Add new</span></a></td>



		</div>
		<div class="box-body">
			<table id="example1" class="table table-bordered table-striped">
				<thead>
				<tr>
					<th>Sl</th>
					<th>রশিদ নং</th>
					<th>দাতার নাম</th>
					<th>দাতার  ঠিকানা</th>
					<th>টাকা</th>
					<th>দানের নাম</th>
					<th>আদায়কারির  নাম</th>
					<th> তারিখ</th>
				</tr>
				</thead>
				<tbody>
				<?php if(isset($receives )): $i=0;foreach ($receives as $receive):?>
				<tr>
					<td><?php echo ++$i;?></td>
					<td>#<?php echo $receive->receive_id;?></td>
					<td><?php echo $receive->receive_data_name;?></td>
					<td><?php echo $receive->receive_address;?></td>
					<td><?php echo $receive->receive_amount;?></td>
					<td><?php echo $receive->expense_category_name;?></td>
					<td><?php echo $receive->receive_adaikari;?></td>
					<td><?php echo date('d-m-Y',strtotime($receive->receive_date));?></td>

				</tr>
				<?php endforeach;endif;?>
				</tbody>

			</table>
		</div>

	</div>
</div>

