<div class="col-md-offset-0 col-md-12">

    <div   id="printable"  class="box  box-success">
        <div class="box-header with-border">
            <h3 class="box-title">
                <a class="btn btn-info" href="<?php echo base_url();?>income-create"><i class="fa fa-plus-circle"></i>Add new</span></a>


            </h3>

            <div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
                <h3>Result for:<b id="catId"></b> category</h3>
                <h4>From :<span id="dateShow1"></span></h4>
                <h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="dateShow2"></span></h4>
            </div>



        </div>
        <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>Sl</th>
                    <th>Rosid</th>
                    <th>Category</th>
                    <th>Amount</th>

                    <th>Date</th>

<!--                    <th>Action</th>-->
                </tr>
                </thead>
                <tbody>
                <?php if (isset($incomes)):

                    $count = 1;
                    //var_dump($count);exit();
                    foreach ($incomes as $income):

                        ?>
                        <tr>
                            <td><?php echo $count; ?></td>
                            <td>#<?php echo $income->income_id; ?></td>
                            <td><?php echo $income->expense_category_name; ?></td>
                            <td><?php echo $income->income_amount; ?></td>

                            <td><?php echo $income->income_date; ?></td>




<!--                            <td>-->
<!--                                <a href="--><?php //echo base_url() ?><!--income-edit/--><?php //echo $income->income_id; ?><!--"-->
<!--                                <span class="glyphicon glyphicon-edit btn btn-success"></span>-->
<!--                                </a>-->
<!--                                <a href="--><?php //echo base_url() ?><!--income-delete/--><?php //echo $income->income_id; ?><!--"-->
<!--                                   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">-->
<!--                                    <span class="glyphicon glyphicon-trash btn btn-danger"></span>-->
<!--                                </a>-->
<!---->
<!---->
<!---->
<!--                            </td>-->

                        </tr>

                        <?php
                        $count++;
                    endforeach;
                endif; ?>

                </tbody>

            </table>


        </div>

    </div>
</div>


<script>


    function printDiv()
    {

        var divToPrint=document.getElementById('printable');

        var htmlToPrint = '' +
            '<style type="text/css">' +
            'table th, table td {' +
            'border:1px solid #000;' +
            'padding;0.5em;' +
            '}' +
            '</style>';
        htmlToPrint += divToPrint.outerHTML;
        newWin = window.open("");
        newWin.document.write("<h3 align='center'>Print Page</h3>");
        newWin.document.write(htmlToPrint);
        newWin.print();
        newWin.close();

    }

    $(".withoutFixedDate").change(function () {
        var dateId1 = $("#dateId1").val();
        var dateId2 = $("#dateId2").val();
        var expense_category_id = $("#expenseId").val();
        var expense_category = $("#expenseId option:selected").text();
        $("#resultShow").show();
        $("#catId").text(expense_category);
        $("#dateShow1").text(dateId1);
        $("#dateShow2").text(dateId2);
    });


    $("#dateId2").change(function () {
        var dateId1 = $("#dateId1").val();
        var dateId2 = $("#dateId2").val();
        var expense_category_id = $("#expenseId").val();

        $.ajax({
            type: "POST",
            data: {expense_category_id: expense_category_id, dateId1: dateId1, dateId2: dateId2},
            dataType: "json",
            url: '<?php echo base_url();?>management/IncomesController/incomeReport',
            success: function (results) {
                var str = "";
                var str1 = "";
                $.each(results['incomes'], function (key, result) {
                    var key = key + 1;
                    if (result['income_status'] == 1) {
                        str = '<tr>' +
                            '<td>' + key + '</td>' +
                            '<td>' + result['expense_category_name'] + '</td>' +
                            '<td>' + result['income_amount'] + '</td>' +
                            '<td>' + result['income_note'] + '</td>' +
                            '<td>' + result['income_date'] + '</td>' +
                            '<td><span class="btn-xs btn-success">Paid</span></td>' +
                            '<td><a href="income-edit/' + result['income_id'] + '"' +
                            '<span class="glyphicon glyphicon-edit btn btn-success"></span>	</a>' +
                            '</tr>';
                    } else {
                        str = '<tr>' +
                            '<td>' + key + '</td>' +
                            '<td>' + result['income_category_name'] + '</td>' +
                            '<td>' + result['income_amount'] + '</td>' +
                            '<td>' + result['income_note'] + '</td>' +
                            '<td>' + result['income_date'] + '</td>' +
                            '<td><span class="btn-xs btn-success">Paid</span></td>' +
                            '</tr>';

                    }
                    str1 = str1 + str;

                });

                $("#example1 tbody").empty();
                $("#example1 tbody").append(str1);
            }
        });
    });

</script>

