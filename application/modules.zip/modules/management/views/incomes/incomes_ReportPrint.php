
<link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

<div class="col-md-offset-0 col-md-12">
	<div class="box  ">
		<div class="box-header with-border">
			<div class="row">
				<div    class="col-md-offset-3 col-md-4 bg-success">
					<h4>Category :<?php
						 if(isset($allCagegory)==1){
									 echo $allCagegory;
						}

							else if(isset($fees[0]->expense_category_name)){
									 echo $fees[0]->expense_category_name;
						}
						else {
						echo $incomes[0]->expense_category_name;
						}

						?>

					</h4>
					<h4>From :<b><?php echo date('F',strtotime($firstDate)); ?></b> </h4>
					<h4>To :<b><?php echo date('F',strtotime($lastDate)); ?></b> </h4>
					<h4>Total :<b><?php echo $totalIncome; ?></b> </h4>
				</div>
				<div class="col-md-4">
					<a  onclick="window.print()" class="btn btn-info btn-lg">
						<span  class="glyphicon glyphicon-print"></span> Print
					</a>

				</div>
			</div>
		</div>

		<div class="table-responsive">
			<table  class="table table-bordered ">
				<thead>
				<tr>
					<th>Sl</th>
					<th>Category</th>
					<th>Amount</th>

					<th>Date</th>
				</tr>
				</thead>
				<tbody>

				<?php  if(isset($fees)):
					$i=1;
					foreach ($fees as $fee):
						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $fee->expense_category_name; ?></td>
							<td><?php echo $fee->invoice_amount; ?></td>
							<td><?php echo date('d-m-Y',strtotime($fee->invoice_creation_time)); ?></td>
						</tr>
						<?php
						$i++;
					endforeach;
				endif;?>

				<?php  if(isset($incomes)):

					foreach ($incomes as $income):
						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $income->expense_category_name; ?></td>
							<td><?php echo $income->income_amount; ?></td>
							<td><?php echo date('d-m-Y',strtotime($income->income_date)); ?></td>
						</tr>
						<?php
						$i++;
					endforeach;
				endif;?>

				</tbody>
			</table>
		</div>
	</div>
</div>
