
<div class="col-md-offset-0 col-md-12">

	<div   id="printable"  class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>

			<table class="table table-bordered table-responsive hidden-print">
				<thead>
				<tr>
					<th scope="col">Category</th>
					<th scope="col">From</th>
					<th scope="col">To</th>
					<th scope="col"></th>
				</tr>
				</thead>
				<form action="<?php echo base_url()?>incomeReportPrint" method="post">
					<td>
						<select   id="expenseId" name="expense_category_id" class="form-control select2">
							<option value="1" >All category</option>
							<?php if(isset($expenscat)):
								foreach ($expenscat as $expense):
									?>
									<option value="<?php echo $expense->expense_category_id;?>"><?php echo $expense->expense_category_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first expense </option>
							<?php endif;?>
						</select>
					</td>
					<td>
						<div class="input-group date" >
							<input id="dateId1" required type="text" class="form-control withoutFixedDate" name="dateId1"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td>
						<div class="input-group date" >
							<input id="dateId2" required type="text" class="form-control withoutFixedDate" name="dateId2"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td>
						<a onclick="window.print()" class="btn btn-info btn-lg">
							<span class="glyphicon glyphicon-print"></span> Print
						</a>
					</td>

					</tr>
				</form>
				</tbody>
			</table>

			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
				<h3>Income for:<b id="catId"></b> category</h3>
				<h4>From :<span id="dateShow1"></span></h4>
				<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow2"></span></h4>
				<h4>Total &nbsp;&nbsp; :৳<span id="totalAmount"></span></h4>
			</div>





		</div>
		<div class="box-body table-responsive">
			<table id="example1" class="table table-bordered table-striped">
				<thead>
				<tr>
					<th>Sl</th>
					<th>রশিদ নং</th>
					<th>দাতার নাম</th>
					<th>দাতার  ঠিকানা</th>
					<th>টাকা</th>
					<th>দানের নাম</th>
					<th>আদায়কারির  নাম</th>
					<th> তারিখ</th>
				</tr>
				</thead>
				<tbody>
<!--				--><?php //if(isset($receives )): $i=0;foreach ($receives as $receive):?>
<!--					<tr>-->
<!--						<td>--><?php //echo ++$i;?><!--</td>-->
<!--						<td>#--><?php //echo $receive->receive_id;?><!--</td>-->
<!--						<td>--><?php //echo $receive->receive_data_name;?><!--</td>-->
<!--						<td>--><?php //echo $receive->receive_address;?><!--</td>-->
<!--						<td>--><?php //echo $receive->receive_amount;?><!--</td>-->
<!--						<td>--><?php //echo $receive->expense_category_name;?><!--</td>-->
<!--						<td>--><?php //echo $receive->receive_adaikari;?><!--</td>-->
<!--						<td>--><?php //echo date('d-m-Y',strtotime($receive->receive_date));?><!--</td>-->
<!---->
<!--					</tr>-->
<!--				--><?php //endforeach;endif;?>
				</tbody>

			</table>
		</div>

	</div>
</div>



<script>

	$("#dateId2").change(function () {
		var expense_category = $("#expenseId option:selected").text();
		var dateId2 = $("#dateId2").val();
		var dateId1 = $("#dateId1").val();
		$("#resultShow").show();
		$("#catId").text(expense_category);
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});
	$("#dateId2, #dateId1").change(function () {
		var dateId2 = $("#dateId2").val();
		var dateId1 = $("#dateId1").val();
		var classreg_section_id=$("#expenseId").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,dateId1:dateId1,dateId2:dateId2},
			dataType: "json",
			url: '<?php echo base_url();?>management/IncomesController/moneyRecievedReport',
			success: function (results) {

				$("#totalAmount").text(results.total);

				var str = "";
				var str1 = "";
				debugger;
				$.each(results['receive'], function (key, result) {
					var key=key+1;

					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>#' + result['receive_id'] + '</td>' +
						'<td>' + result['receive_data_name'] + '</td>' +
						'<td>' + result['receive_address'] + '</td>' +
						'<td>' + result['receive_amount'] + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['receive_adaikari'] + '</td>' +
						'<td>' + result['receive_date'] + '</td>' +
						'</tr>';

					str1=str1+str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});



</script>





