<div class="col-md-offset-1 col-md-8">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="text-center">Bandaria Siddikia Kamil Madrasah</h3>
			<h4 class="text-center">post Mokundia ,Rajbari sodor, Rajbari.</h4>
			<h4 class="text-center">Resident Student fee collection roshid</h4>
			<p ><b>Invoice id#<span id="invoiceId"></span></b></p>
			<p class="pull-right" ><b>Date :<?php echo date('d-m-Y');?></b></p>
			<h1 class="text-center text-success"id="studentFeeResult" ></h1>


		</div>
		<div class="box-body">

			<form action="<?php echo base_url() ?>income-save" class="form-horizontal" method="post">

				<div class="form-group">
					<label for="amount" class="col-md-4 control-label">দাতার নাম /Doner</label>

					<div class="col-md-6">
						<input required type="text" id="receive_data_name" class="form-control" name="receive_data_name"
							   value="" placeholder="দাতার নাম /Doner">
					</div>
				</div>
				<div class="form-group">
					<label for="amount" class="col-md-4 control-label">ঠিকানা / Adress</label>

					<div class="col-md-6">
						<input required type="text" id="receive_address" class="form-control" name="receive_address"
							   value="" placeholder="দাতার ঠিকানা">
					</div>
				</div>
				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label">বাবদ /A.C </label>

					<div class="col-md-6">
						<select required name="expense_category_id" id="expense_category_id" class="form-control select2">
							<option value="">select income category</option>
							<?php
							foreach ($expensesCatogry as $incomesCatogoy):
								?>
								<option


									value="<?php echo $incomesCatogoy->expense_category_id; ?>"> <?php echo $incomesCatogoy->expense_category_name; ?> </option>
							<?php endforeach; ?>
						</select>

					</div>
				</div>

				<div class="form-group">
					<label for="amount" class="col-md-4 control-label">পরিমাণ /Amount</label>

					<div class="col-md-6">
						<input required type="text" id="receive_amount" class="form-control" name="receive_amount"
							   value="" placeholder="পরিমাণ /Amount ">
					</div>
				</div>
				<div class="form-group">
					<label for="shiftName" class="col-md-4 control-label"> আদায়কারি /Collector</label>

					<div class="col-md-6">
						<input  type="text" class="form-control" id="receive_adaikari" name="receive_adaikari"
								value="" placeholder="আদায়কারি /Collector">
					</div>
				</div>





		</div>

		<div class="box-footer">
			<button class="btn btn-primary hidden-print pull-right" onclick="myFunction()"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Print</button>
			<input type="submit"  id="saveReceied"class="btn btn-success pull-right hidden-print" value="Save"/>
			<a class="btn btn-danger hidden-print " href="<?php echo base_url();?>income-money-list">Cancel</a>

		</div>
		</form>
	</div>
</div>

<script>
	function myFunction() {
		window.print();
	}
	$(function () {


	});



	$(document).mousemove(function(){
		$.ajax({
			type: "POST",
			url: '<?php echo base_url();?>Management/IncomesController/receiveSelectionData',
			success: function (results) {
				$("#invoiceId").text(results);
			}
		});
	});


	$(document).on('click','#saveReceied',function (e) {

		e.preventDefault();
		var receive_data_name=$('#receive_data_name').val();
		var receive_address=$('#receive_address').val();
		var expense_category_id=$('#expense_category_id').val();
		var receive_amount=$('#receive_amount').val();
		var receive_adaikari=$('#receive_adaikari').val();
		if(receive_data_name.length ==""){
			alert("Select  Doner Name");
		}
		if(receive_address.length ==0){
			alert("Select  Doner Address");
		}
		if(expense_category_id.length ==0){
			alert("Select  Category ");
		}
		if(receive_amount.length ==0){
			alert("Select  Amount ");
		}

		if(receive_adaikari.length ==0){
			alert("Select  আদায়কারি /Collector ");
		}


		$.ajax({
			type: "POST",
			data: {expense_category_id:expense_category_id,receive_data_name:receive_data_name,receive_address:receive_address,receive_adaikari:receive_adaikari,receive_amount:receive_amount},
			url: '<?php echo base_url();?>Management/IncomesController/receviedSave',
			success: function (results) {
				alert(results);

			},
			error:function (results) {
				alert(results);
			}
		});
	});
</script>

