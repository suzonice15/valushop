<div class="col-md-offset-0 col-md-12">
	<div class="box box-success">
		<div class="box-header with-border">


		</div>
		<div class="box-body">

			<form action="#" class="form-horizontal" method="post">

				<div class="container"><h2><?php if (isset($title)) echo $title ;?> </h2></div>
				<div id="exTab3" class="container">
					<ul  class="nav nav-pills">
						<li class="active">
							<a  href="#1b" data-toggle="tab">Income Report</a>
						</li>
						<li><a href="#2b" data-toggle="tab">Expense Report</a>
						</li>
						<li><a href="#3b" data-toggle="tab">Profit/Loss Report</a>
						</li>
					</ul>

					<div class="tab-content clearfix">
						<div class="tab-pane active" id="1b">

							<div   id="printable"  class="box  box-success">
								<div class="box-header with-border table-responsive ">
									<h3 class="box-title"></h3>
									<table class="table table-bordered hidden-print">
										<thead>
										<tr>
											<th scope="col">Category</th>
											<th scope="col">From</th>
											<th scope="col">To</th>
											<th scope="col"></th>
										</tr>
										</thead>
										<form action="<?php echo base_url()?>incomeReportPrint" method="post">
											<td>
												<select   id="expenseId" name="expense_category_id" class="form-control select2">
													<option value="1" >All category</option>
													<?php if(isset($expenscat)):
														foreach ($expenscat as $expense):
															?>
															<option value="<?php echo $expense->expense_category_id;?>"><?php echo $expense->expense_category_name;?> </option>
														<?php endforeach; else : ?>
														<option value="">Registration first expense </option>
													<?php endif;?>
												</select>
											</td>
											<td>
												<div class="input-group date" >
													<input id="dateId1" required type="text" class="form-control withoutFixedDate" name="dateId1"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
													<div class="input-group-addon">
														<span class="glyphicon glyphicon-th" id="datepicker" ></span>
													</div>
												</div>

											</td>
											<td>
												<div class="input-group date" >
													<input id="dateId2" required type="text" class="form-control withoutFixedDate" name="dateId2"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
													<div class="input-group-addon">
														<span class="glyphicon glyphicon-th" id="datepicker" ></span>
													</div>
												</div>

											</td>
											<td>
												<a onclick="window.print()" class="btn btn-info btn-lg">
													<span class="glyphicon glyphicon-print"></span> Print
												</a>
											</td>

											</tr>
										</form>
										</tbody>
									</table>

									<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
										<h3>Income for:<b id="catId"></b> category</h3>
										<h4>From :<span id="dateShow1"></span></h4>
										<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="dateShow2"></span></h4>
										<h4>Total &nbsp;&nbsp; :৳<span id="totalAmount"></span></h4>
									</div>



								</div>
								<div class="box-body table-responsive ">
									<table id="example1" class="table table-bordered table-striped">
										<thead>
										<tr>
											<th>Sl</th>
											<th>Category</th>
											<th>Amount</th>
											<!--				<th>Note</th>-->
											<th>Date</th>
											<!--				<th>Status</th>-->
											<!--				<th>Action</th>-->
										</tr>
										</thead>
										<tbody>
										</tbody>

									</table>


								</div>

							</div>

						</div>
						<div class="tab-pane" id="2b">
							<div class="table table-responsive">
								<div class="box  box-success ">
									<div class="box-header with-border">
										<table class="table table-bordered hidden-print">
											<thead>
											<tr>
												<th scope="col">Category</th>
												<th scope="col">From</th>
												<th scope="col">To</th>
											</tr>
											</thead>
											<tbody>
											<form action="<?php echo base_url()?>expenses-report-print" method="post">
												<tr>
													<td>
														<select id="expenseId1" name="expense_category_id" class="form-control select2">
															<option value="1">All category</option>
															<?php if (isset($expenseCatt)):
																foreach ($expenseCatt as $expense):
																	?>
																	<option
																		value="<?php echo $expense->expense_category_id; ?>"><?php echo $expense->expense_category_name; ?> </option>
																<?php endforeach; else : ?>
																<option value="">Registration first expense</option>
															<?php endif; ?>
														</select>
													</td>
													<td>
														<div class="input-group date">
															<input id="dateId11" required   name="dateId1" type="text" class="form-control withoutFixedDate"
																   name="attendance_date" value="<?php if (isset($attendance_date)) {
																echo $attendance_date;
															} ?>" placeholder="Enter date:12/12/2019">
															<div class="input-group-addon">
																<span class="glyphicon glyphicon-th" id="datepicker"></span>
															</div>
														</div>
													</td>
													<td>
														<div class="input-group date">
															<input id="dateId22"  name="dateId22" required type="text" class="form-control withoutFixedDate"
																   name="attendance_date" value="<?php if (isset($attendance_date)) {
																echo $attendance_date;
															} ?>" placeholder="Enter date:12/12/2019">
															<div class="input-group-addon">
																<span class="glyphicon glyphicon-th" id="datepicker"></span>
															</div>
														</div>
													</td>
													<td>
														<a onclick="window.print()" class="btn btn-info btn-lg">
															<span class="glyphicon glyphicon-print"></span> Print
														</a>
													</td>
												</tr>
											</form>
											</tbody>
										</table>

										<div style="display:none" id="resultShow1" class="col-md-offset-3 col-md-6 bg-success">
											<h3>Expense category:<b id="catId"></b></h3>
											<h4>From :<span id="dateShow11"></span></h4>
											<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow22"></span></h4>
											<h4>Total &nbsp;&nbsp;&nbsp;:৳<span id="totalAmount1"></span></h4>
										</div>


									</div>
									<div class="box-body">

										<table id="example1" class="table table-bordered table-striped">
											<thead>
											<tr>
												<th>Serial</th>
												<th>Category</th>
												<th>Amount</th>
												<th>Date</th>

											</tr>
											</thead>
											<tbody>

											</tbody>

										</table>


									</div>

								</div>
							</div>

						</div>



						<div class="tab-pane" id="3b">
							<div class="box  box-success ">
								<div class="box-header with-border">
									<table class="table table-bordered hidden-print">
										<thead>
										<tr>
											<th scope="col">From</th>
											<th scope="col">To</th>
										</tr>
										</thead>
										<tbody>


										<form action="" method="post">
											<tr>
												<td>
													<div class="input-group date" >
														<input id="dateId13" name="dateId1" required type="text" class="form-control withoutFixedDate" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
														<div class="input-group-addon">
															<span class="glyphicon glyphicon-th" id="datepicker" ></span>
														</div>
													</div>

												</td>
												<td>
													<div class="input-group date" >
														<input id="dateId23" name="dateId23"  required type="text" class="form-control withoutFixedDate" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
														<div class="input-group-addon">
															<span class="glyphicon glyphicon-th" id="datepicker" ></span>
														</div>
													</div>

												</td>
												<td>

													<a onclick="window.print()" class="btn btn-info btn-lg">
														<span class="glyphicon glyphicon-print"></span> Print
													</a>
												</td>
											</tr>
										</form>
										</tbody>
									</table>

									<div  style="display:none"  id="resultShow3" class="col-md-offset-3 col-md-6 bg-success">
										<h4>From :<span id="dateShow13"></span></h4>
										<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow23"></span></h4>
										<h4>Profit &nbsp;:৳ <span id="profitId"></span></h4>
										<h4>Loss &nbsp;&nbsp;:৳ <span id="lossId"></span></h4>
									</div>



								</div>
								<div class="box-body">

									<table id="example1" class="table table-bordered table-striped">
										<thead>
										<tr>
											<th>Sl</th>
											<th>Income</th>
											<th>Expense</th>
											<th>profit   </th>
											<th>Loss   </th>
										</tr>
										</thead>
										<tbody>
										</tbody>
									</table>
								</div>
							</div>
						</div>

					</div>


				</div>


		</div>
	</div>
	</div>
</div>

<script>


	$(".withoutFixedDate").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var expense_category_id = $("#expenseId").val();
		var expense_category = $("#expenseId option:selected").text();
		$("#resultShow").show();
		$("#catId").text(expense_category);
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});


	$("#dateId2,#dateId1,#expenseId").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var expense_category_id = $("#expenseId").val();

		$.ajax({
			type: "POST",
			data: {expense_category_id: expense_category_id, dateId1: dateId1, dateId2: dateId2},
			dataType: "json",
			url: '<?php echo base_url();?>management/IncomesController/incomeReport',
			success: function (results) {
				var str = "";
				var str1 = "";
				var i=1;
				$("#totalAmount").text(results.totalIncome);
				$.each(results['incomes'], function (key, result) {

					str = '<tr>' +
						'<td>' + i + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['income_amount'] + '</td>' +
						'<td>' + result['income_date'] + '</td>' +

						'</tr>';
					i++;

					str1 = str1 + str;

				});

				$.each(results['studentFee'], function (key, result) {
					i++;
					str = '<tr>' +
						'<td>' + i + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['invoice_amount'] + '</td>' +
						'<td>' + result['invoice_creation_time'] + '</td>' +
						'</tr>';
					str1 = str1 + str;

				});

				$.each(results['studentAbasic'], function (key, result) {
					i++;
					str = '<tr>' +
						'<td>' + i + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['resident_fee_amount'] + '</td>' +
						'<td>' + result['resident_creation_time'] + '</td>' +
						'</tr>';
					str1 = str1 + str;

				});

				$.each(results['dan'], function (key, result) {
					i++;
					str = '<tr>' +
						'<td>' + i + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['receive_amount'] + '</td>' +
						'<td>' + result['receive_date'] + '</td>' +
						'</tr>';
					str1 = str1 + str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>

<script>

	function myprint() {
		window.print();
	}

	$(".withoutFixedDate").change(function () {
		var dateId1 = $("#dateId11").val();
		var dateId2 = $("#dateId22").val();
		var expense_category_id = $("#expenseId1").val();
		var expense_category = $("#expenseId1 option:selected").text();
		$("#resultShow1").show();
		$("#catId1").text(expense_category);
		$("#dateShow11").text(dateId1);
		$("#dateShow22").text(dateId2);
	});

	$("#dateId22,#expenseId1").change(function () {
		var dateId1 = $("#dateId11").val();
		var dateId2 = $("#dateId22").val();
		var expense_category_id = $("#expenseId1").val();
		$.ajax({
			type: "POST",
			data: {expense_category_id: expense_category_id, dateId1: dateId1, dateId2: dateId2},
			dataType: "json",
			url: '<?php echo base_url();?>management/ExpenseController/expenseReport',
			success: function (results) {
				var str = "";
				var str1 = "";
				$("#totalAmount1").text(results.totalAmount);
				$.each(results['expenses'], function (key, result) {
					var key = key + 1;
					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>' + result['expense_category_name'] + '</td>' +
						'<td>' + result['expense_amount'] + '</td>' +
						'<td>' + result['expense_date'] + '</td>' +
						'</tr>';
					str1 = str1 + str;
				});
				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});
</script>

<script>

	function myprint() {
		window.print();
	}
	$("#dateId23").change(function () {
		var dateId1 = $("#dateId13").val();
		var dateId2 = $("#dateId23").val();

		$("#resultShow").show();
		$("#dateShow13").text(dateId1);
		$("#dateShow23").text(dateId2);
	});

	$("#dateId23,#dateId13").change(function () {
		var dateId1=$("#dateId13").val();
		var dateId2=$("#dateId23").val();
		$.ajax({
			type: "POST",
			data: {dateId1:dateId1,dateId2:dateId2},
			dataType: "json",
			url: '<?php echo base_url();?>management/ExpenseController/incomeExpenseReport',
			success: function (results) {
				var str = "";
				var str1 = "";
				var key=1;
				$("#profitId").text(results.gain);
				$("#lossId").text(results.los);

				if(results['totalIncome']>=results['expense']) {
					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>' + results['totalIncome'] + '</td>' +
						'<td>' + results['expense'] + '</td>' +
						'<td>' + results['gain'] + '</td>' +
						'<td></td>' +

						'</tr>';
				}

				else {
					str = '<tr>' +
						'<td>' + key + '</td>' +
						'<td>' + results['totalIncome'] + '</td>' +
						'<td>' + results['expense'] + '</td>' +
						'<td></td>' +
						'<td>' + results['los'] +'</td>' +
						'</tr>';
				}
				str1=str1+str;



				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});
</script>




