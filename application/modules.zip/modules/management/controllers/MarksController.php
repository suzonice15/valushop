<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MarksController extends MX_Controller {

    public function __construct()
    {
        $this->load->model('MainModel');
        $this->load->model('Mark');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//		}
    }

    public function index()
    {
        $data['main'] = "Marks";
        $data['active'] = "Marks view";
        $query="select marks.*,subject_name,classreg_name,student_roll,student_name,exam_session_name from marks  join subjects on subjects.subject_id=marks.subject_id join students on students.student_id=marks.student_id join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id";
		$data['marks'] = $this->MainModel->AllQueryDalta($query);
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
        $data['pageContent'] = $this->load->view('management/marks/marks_index', $data, true);
        $this->load->view('layouts/main', $data);
    }
	public function markstudentwise()
	{
		$data['main'] = "Marks";
		$data['active'] = "Marks view";
		$query="select marks.*,subject_name,classreg_name,student_name,exam_session_name from marks  join subjects on subjects.subject_id=marks.subject_id join students on students.student_id=marks.student_id join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id";
		$data['marks'] = $this->MainModel->AllQueryDalta($query);
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/markstudentwise', $data, true);
		$this->load->view('layouts/main', $data);
	}

    public function create()
    {
        $data['title'] = "Marks registration form ";
        $data['main'] = "Marks";
        $data['active'] = "add Marks";
        $query="select * from student_classreg_section_com   join (select  subjects.* from subjects  join class_registrations on class_registrations.classreg_id=subjects.classreg_id)tablename on student_classreg_section_com.classreg_section_id=tablename.classreg_id";
        $data['marks'] = $this->MainModel->AllQueryDalta($query);
        $data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
        $data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
        $data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
        $data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
        //var_dump($data['students']);exit();
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');

        //  echo '<pre>';
       // print_r($data['marks']);exit();


        $data['pageContent'] = $this->load->view('management/marks/marks_create', $data, true);
        $this->load->view('layouts/main', $data);
    }


    public function store()
    {

        $data['exam_session_id'] = $this->input->post('exam_session_id');
        $data['subject_id'] = $this->input->post('subject_id');
        $data['mark_obtained'] = $this->input->post('mark_obtained');
        $data['mark_grade_point'] = $this->input->post('mark_grade_point');
        $data['student_id'] = $this->input->post('student_id');
        $data['mark_gpa'] = $this->input->post('mark_gpa');
        // var_dump($data);exit();
        $this->form_validation->set_rules('exam_session_id', 'Student name', 'required');
        $this->form_validation->set_rules('subject_id', 'Student name', 'required');
        $this->form_validation->set_rules('mark_obtained', 'Student name', 'required');
        $this->form_validation->set_rules('mark_grade_point', 'Student name', 'required');
        $this->form_validation->set_rules('mark_gpa', 'Student name', 'required');
        $this->form_validation->set_rules('student_id', 'Student name', 'required');
        if ($this->form_validation->run()) {
            $result = $this->MainModel->insertData('marks', $data);
            if ($result) {

                $this->session->set_flashdata('message', "Student mark added successfully !!!!");

                redirect('mark-create');
            }
        } else {

            $this->session->set_flashdata('error', "All field need to fillUp");
            redirect('mark-create');
        }


    }

    public function show($id)
    {

    }
    public function StudentSelection()
    {
		$classregsection_id=$this->input->post('subject_id');
		//$classregsection_id =$this->input->post('classreg_section_id');
		$classSectionData = $this->MainModel->getSingleData('classreg_section_id', $classregsection_id, 'classreg_section_com', '*');
		$class_id=$classSectionData->classreg_section_id;
		$query="select student_classreg_section_com.*,students.student_name,students.student_id from student_classreg_section_com join students on student_classreg_section_com.student_id=students.student_id
where student_classreg_section_com.classreg_section_id=$class_id";
		$students = $this->MainModel->AllQueryDalta($query);
		$str = "";
		$str .= '<select  name="student_id" id="student_id" class="form-control">
				<option value="">--- Select student ---</option>';
		if (!empty($students)) {
			foreach ($students as $student) {
				$str .= '<option value="' . $student->student_id . '">' . $student->student_name . '</option>';
			}
		}
		$str .= '</select>';
		echo $str;
    }
	public function MultipleStudentSelection()
	{
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$query="select A.student_name,A.student_id,B.mark_obtained,B.mark_grade_point, B.mark_gpa,B.student_id as mark_student_id from  (select  students.student_name,students.student_id,subjects.*  from subjects    
		join class_registrations on class_registrations.classreg_id=subjects.classreg_id 
	join classreg_section_com on classreg_section_com.classreg_id=class_registrations.classreg_id 
join student_classreg_section_com on student_classreg_section_com.classreg_section_id=classreg_section_com.classreg_section_id
join students on student_classreg_section_com.student_id=students.student_id 
where subjects.subject_id=$subjectId  and student_classreg_section_com.student_classreg_section_isActive=1  ) A  left join (select marks.*,marks.student_id as student_mark_id from marks  join subjects on subjects.subject_id=marks.subject_id join students on marks.student_id=students.student_id
where  subjects.subject_id=$subjectId and  exam_session_id=$examSessionId) B on A.student_id=B.student_id";
	$data['students']=$this->MainModel->AllQueryDalta($query);
		echo json_encode($data);
	}
	public function WrittenMcqStudentSelection()
	{
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$query="select A.student_name,A.student_id,B.mark_obtained,B.mark_grade_point, B.mark_gpa,B.student_id as mark_student_id,B.mark_mcq,B.mark_practical,B.mark_written  from  (select  students.student_name,students.student_id,subjects.*  from subjects    
		join class_registrations on class_registrations.classreg_id=subjects.classreg_id 
	join classreg_section_com on classreg_section_com.classreg_id=class_registrations.classreg_id 
join student_classreg_section_com on student_classreg_section_com.classreg_section_id=classreg_section_com.classreg_section_id
join students on student_classreg_section_com.student_id=students.student_id 
where subjects.subject_id=$subjectId  and student_classreg_section_com.student_classreg_section_isActive=1  ) A  left join (select marks.*,marks.student_id as student_mark_id from marks  join subjects on subjects.subject_id=marks.subject_id join students on marks.student_id=students.student_id
where  subjects.subject_id=$subjectId and  exam_session_id=$examSessionId) B on A.student_id=B.student_id";
		$data['students']=$this->MainModel->AllQueryDalta($query);
//		echo '<pre>';
//		print_r($data['students']);exit();
		echo json_encode($data);
	}

	public function edit($id)
    {
        $data['markdata']= $this->MainModel->getSingleData('mark_id', $id, 'marks', '*');

        $markId= $data['markdata']->mark_id;
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
        if (isset($markId)) {
            $data['title'] = "Mark update page ";
            $data['main'] = "Mark";
            $data['active'] = "Update mark";
            $data['pageContent'] = $this->load->view('management/marks/marks_edit', $data, true);
            $this->load->view('layouts/main', $data);
        } else {
            $this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
            redirect('student-list');
        }

    }

    public function update()
    {
        $mark_id = $this->input->post('mark_id');
        // check if the element exists before trying to edit it
        $markData= $this->MainModel->getSingleData('mark_id', $mark_id, 'marks', '*');
		$markId = $markData->mark_id;

        if (isset($markId)) {
			$data['exam_session_id'] = $this->input->post('exam_session_id');
			$data['subject_id'] = $this->input->post('subject_id');
			$data['mark_obtained'] = $this->input->post('mark_obtained');
			$data['mark_grade_point'] = $this->input->post('mark_grade_point');
			$data['student_id'] = $this->input->post('student_id');
			$data['mark_gpa'] = $this->input->post('mark_gpa');
			// var_dump($data);exit();
			$this->form_validation->set_rules('exam_session_id', 'Student name', 'required');
			$this->form_validation->set_rules('subject_id', 'Student name', 'required');
			$this->form_validation->set_rules('mark_obtained', 'Student name', 'required');
			$this->form_validation->set_rules('mark_gpa', 'Student name', 'required');
			$this->form_validation->set_rules('student_id', 'Student name', 'required');

			if ($this->form_validation->run()) {
                $result = $this->MainModel->updateData('mark_id', $markId, 'marks', $data);
                if ($result) {
                    $this->session->set_flashdata('message', "Mark updated successfully !!!!");
                    redirect('mark-list');
                }
            } else {

                $this->session->set_flashdata('error', "value reqiured");
                redirect('mark-update');
            }
        } else {
            $this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
            redirect('mark-list');
        }

    }

	public function multipleDataStore($subjectId)
	{
		$query = "select  students.student_name,students.student_id,students.student_roll,subjects.*   from subjects    join class_registrations on class_registrations.classreg_id=subjects.classreg_id join classreg_section_com
on classreg_section_com.classreg_id=class_registrations.classreg_id join student_classreg_section_com on student_classreg_section_com.classreg_section_id=classreg_section_com.classreg_section_id
join students on student_classreg_section_com.student_id=students.student_id where subjects.subject_id
=$subjectId";
		$data['studentSubjectRelations'] = $this->MainModel->AllQueryDalta($query);
		$query="select * from marks  join subjects on subjects.subject_id=marks.subject_id where subjects.subject_id=$subjectId";

        $data['studentMarkRelations'] = $this->MainModel->AllQueryDalta($query);
//echo '<pre>';
//		print_r($data['studentMarkRelations'] );exit();

        $data['title'] = "Mark  registration form ";
		$data['main'] = "Marks relation";
		$data['active'] = "add mark ";
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/marks_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function multipleMarkForm()
	{


		$data['title'] = "Mark  registration form ";
		$data['main'] = "Marks relation";
		$data['active'] = "add mark ";
		$query="select * from subjects join class_registrations on  class_registrations.classreg_id=subjects.classreg_id order by subject_id desc";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/multiple_mark_form', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function writtenMcqMarkForm()
	{


		$data['title'] = "Mark  registration form ";
		$data['main'] = "Marks relation";
		$data['active'] = "add mark ";
		$query="select * from subjects join class_registrations on  class_registrations.classreg_id=subjects.classreg_id
where subjects.subject_status=2
 order by subject_id desc";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/marks_writtenMcqMarkForm', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function practicalMarkForm()
	{


		$data['title'] = "Practical mark  registration form ";
		$data['main'] = " Practical Marks ";
		$data['active'] = "add mark ";
		$query="select * from subjects join class_registrations on  class_registrations.classreg_id=subjects.classreg_id
where subjects.subject_status=3
 order by subject_id desc";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/marks_practicalMarkForm', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function multipleDataInsertInDB()
	{
		$studentDataArray = array();
		$gradePointDataArray = array();
		$gpaDataArray = array();
		$markDataArray = array();
		$data['subject_id'] = $this->input->post('subject_id');
		$data['exam_session_id'] = $this->input->post('exam_session_id');
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$studentId=$this->input->post('student_id');
		if(isset($studentId)) {
			$studentData = implode(',', $this->input->post('student_id'));
		//	print_r($studentData);exit();
			$studentDataArray = explode(',', $studentData);
			$markData = implode(',', $this->input->post('mark_obtained'));
			$markDataArray = explode(',', $markData);
			$gpaData = implode(',', $this->input->post('mark_gpa'));
			$gpaDataArray = explode(',', $gpaData);
			$gradPointeData = implode(',', $this->input->post('mark_grade_point'));
			$gradePointDataArray = explode(',', $gradPointeData);
			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['student_id'] = $studentDataArray[$i];
				$data['mark_grade_point'] = $gradePointDataArray[$i];
				$data['mark_gpa'] = $gpaDataArray[$i];
				$data['mark_obtained'] = $markDataArray[$i];
				$result = $this->MainModel->insertData('marks', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Mark  added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('mark-multiple-form');
			}
		}
		else {

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			$data['relationMessage'] = "You dont add any information in database !!!!!!!!!";
			$this->session->set_userdata($data);
			redirect('mark-multiple-form');
		}


	}



	public function writtenMcqMarkSave()
	{

		$studentDataArray = array();
		$gradePointDataArray = array();
		$gpaDataArray = array();
		$markDataArray = array();
		$data['subject_id'] = $this->input->post('subject_id');
		$data['exam_session_id'] = $this->input->post('exam_session_id');
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$studentId=$this->input->post('student_id');
		if(isset($studentId)) {
			$studentData = implode(',', $this->input->post('student_id'));
			//	print_r($studentData);exit();
			$studentDataArray = explode(',', $studentData);
			$markData = implode(',', $this->input->post('mark_obtained'));
			$markDataArray = explode(',', $markData);
			$gpaData = implode(',', $this->input->post('mark_gpa'));
			$gpaDataArray = explode(',', $gpaData);
			$gradPointeData = implode(',', $this->input->post('mark_grade_point'));
			$gradePointDataArray = explode(',', $gradPointeData);

			$mark_writtenData = implode(',', $this->input->post('mark_written'));
			$mark_writtenArray = explode(',', $mark_writtenData);
			$mark_mcqData = implode(',', $this->input->post('mark_mcq'));
			$mark_mcqDataArray = explode(',', $mark_mcqData);

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['student_id'] = $studentDataArray[$i];
				$data['mark_grade_point'] = $gradePointDataArray[$i];
				$data['mark_mcq'] = $mark_mcqDataArray[$i];
				$data['mark_written'] = $mark_writtenArray[$i];
				$data['mark_gpa'] = $gpaDataArray[$i];
				$data['mark_obtained'] = $markDataArray[$i];
				$result = $this->MainModel->insertData('marks', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Mark  added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('mark-written-mcq-form');
			}
		}
		else {

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			$data['relationMessage'] = "You dont add any information in database !!!!!!!!!";
			$this->session->set_userdata($data);
			redirect('mark-written-mcq-form');
		}


	}


	public function practicalMarkSave()
	{

//		$studentDataArray = array();
//		$gradePointDataArray = array();
//		$gpaDataArray = array();
//		$markDataArray = array();
		$data['subject_id'] = $this->input->post('subject_id');
		$data['exam_session_id'] = $this->input->post('exam_session_id');
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$studentId=$this->input->post('student_id');
		if(isset($studentId)) {
			$studentData = implode(',', $this->input->post('student_id'));
			//	print_r($studentData);exit();
			$studentDataArray = explode(',', $studentData);
			$markData = implode(',', $this->input->post('mark_obtained'));
			$markDataArray = explode(',', $markData);
			$gpaData = implode(',', $this->input->post('mark_gpa'));
			$gpaDataArray = explode(',', $gpaData);
			$gradPointeData = implode(',', $this->input->post('mark_grade_point'));
			$gradePointDataArray = explode(',', $gradPointeData);

			$mark_writtenData = implode(',', $this->input->post('mark_written'));
			$mark_writtenArray = explode(',', $mark_writtenData);
			$mark_mcqData = implode(',', $this->input->post('mark_mcq'));
			$mark_mcqDataArray = explode(',', $mark_mcqData);
			$mark_practicalData = implode(',', $this->input->post('mark_practical'));
			$mark_practicalDataArray = explode(',', $mark_practicalData);

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['student_id'] = $studentDataArray[$i];
				$data['mark_grade_point'] = $gradePointDataArray[$i];
				$data['mark_mcq'] = $mark_mcqDataArray[$i];
				$data['mark_written'] = $mark_writtenArray[$i];
				$data['mark_gpa'] = $gpaDataArray[$i];
				$data['mark_obtained'] = $markDataArray[$i];
				$data['mark_practical'] = $mark_practicalDataArray[$i];
				$result = $this->MainModel->insertData('marks', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Mark  added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('practical-mark-form');
			}
		}
		else {

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			$data['relationMessage'] = "You dont add any information in database !!!!!!!!!";
			$this->session->set_userdata($data);
			redirect('practical-mark-form');
		}


	}


	public function studentData()
	{
		$student_id = $this->input->post('student_id');
		$exam_session_id= $this->input->post('exam_session_id');
		$classreg_section_id= $this->input->post('classreg_section_id');
		$query = "select student_name,subject_name,mark_obtained,mark_grade_point,mark_gpa from marks 
join student_classreg_section_com on student_classreg_section_com.student_id=marks.student_id
join students on students.student_id=student_classreg_section_com.student_id
join subjects on subjects.subject_id=marks.subject_id
where marks.exam_session_id=$exam_session_id and student_classreg_section_com.classreg_section_id=$classreg_section_id  and student_classreg_section_com.student_classreg_section_isActive=1
and students.student_id=$student_id";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		$totalMarks=0;
		$totalGpa=0;
		$subjectCount=0;
		$finalgpa=0;
		foreach($data['students'] as $student){
			$subjectCount++;
			$totalMarks=$totalMarks+$student->mark_obtained;
			$totalGpa=$totalGpa+$student->mark_grade_point;
		}
//		echo $totalMarks;
//		echo $totalGpa;
		$finalgpa=$totalGpa/$subjectCount;
		if($finalgpa==5){
			$data['gradePoint']='A+';

		}
		else if($finalgpa<5 and $finalgpa>=4){
			$data['gradePoint']='A';

		}
	else if($finalgpa<4 and $finalgpa>=3.5){
			$data['gradePoint']='A-';

		}
		else if($finalgpa<3.5 and $finalgpa>=3){
			$data['gradePoint']='B';

		}
		else if($finalgpa<3 and $finalgpa>=2){
			$data['gradePoint']='C';

		}
		else if($finalgpa<2 and $finalgpa>=1){
			$data['gradePoint']='D';

		}
		else {
			$data['gradePoint']='F';
		}
		//echo $finalgpa;
		$data['finalGpa']=sprintf("%.2f", $finalgpa);
		$data['finalmark']=sprintf("%.2f", $totalMarks);
		//echo $data['gradePoint'];



		echo json_encode($data);


	}

	public function classSectionData()
	{
		$classreg_section_id = $this->input->post('classreg_section_id');
		$query = "select subjects.* from subjects join classreg_section_com on classreg_section_com.classreg_id=subjects.classreg_id where classreg_section_com.classreg_section_id=$classreg_section_id";
		$classSection = $this->MainModel->AllQueryDalta($query);
		$str='<select   id="subjectId" class="form-control select2"><option value="">select subject </option>';
		foreach ($classSection as $class):
		$str .='<option value="'.$class->subject_id.'">'.$class->subject_name.'</option>';
		endforeach;
		$str .=	'</select>';
		echo $str;
	}

	public function studentSelectionData()
	{
		$classreg_section_id = $this->input->post('classreg_section_id');
		$query = "select student_classreg_section_com.student_id as studentId,student_name,student_father_name from student_classreg_section_com
join  students on students.student_id=student_classreg_section_com.student_id
 where student_classreg_section_com.classreg_section_id=$classreg_section_id and student_classreg_section_com.student_classreg_section_isActive=1";
		$students = $this->MainModel->AllQueryDalta($query);
		$str='<select   id="studentId" class="form-control select2"><option value="">select student </option>';
		foreach ($students as $student):
			$str .='<option value="'.$student->studentId.'">'.$student->student_name.'</option>';
		endforeach;
		$str .=	'</select>';
		echo $str;
	}



	public function examSessionData()
	{
		$exam_session_id= $this->input->post('exam_session_id');
		$subject_id= $this->input->post('subject_id');
		$classreg_section_id= $this->input->post('classreg_section_id');
		$query = "
select * from classreg_section_com join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join subjects on subjects.classreg_id=class_registrations.classreg_id join marks on marks.subject_id=subjects.subject_id
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id 
join student_classreg_section_com on student_classreg_section_com.student_id=marks.student_id 
join students  on students.student_id=student_classreg_section_com.student_id 
where student_classreg_section_com.student_classreg_section_isActive=1 and classreg_section_com.classreg_section_id=$classreg_section_id
and subjects.subject_id=$subject_id and marks.exam_session_id=$exam_session_id";
		$examSesseionData = $this->MainModel->AllQueryDalta($query);
		echo json_encode($examSesseionData);


	}


	public function classWiseMark()
	{
		$this->load->library('Pdf');

		$exam_session_id= $this->input->post('exam_session_id');
		$subject_id= $this->input->post('subject_id');
		$classreg_section_id= $this->input->post('classreg_section_id');
		$query = "
select * from classreg_section_com join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join subjects on subjects.classreg_id=class_registrations.classreg_id join marks on marks.subject_id=subjects.subject_id
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id 
join student_classreg_section_com on student_classreg_section_com.student_id=marks.student_id 
join students  on students.student_id=student_classreg_section_com.student_id 
where student_classreg_section_com.student_classreg_section_isActive=1 and classreg_section_com.classreg_section_id=$classreg_section_id
and subjects.subject_id=$subject_id and marks.exam_session_id=$exam_session_id";
		$data['marks'] = $this->MainModel->AllQueryDalta($query);
//		$data['pageContent'] = $this->load->view('management/marks/classWiseMark', $data, true);
//		$this->load->view('layouts/main', $data);
		$this->pdf->load_view('management/marks/classWiseMark',$data);
		$this->pdf->render();
		$this->pdf->stream("mark.pdf");




	}


	 public  function  gpaData(){
		 $subject_id= $this->input->post('subject_id');
		 $exam_session_id= $this->input->post('exam_session_id');
		 $gpa= $this->input->post('gpa');
    	$query="select marks.*,subject_name,classreg_name,exam_session_name,student_name,student_father_name from marks join students on students.student_id=marks.student_id 
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id
join subjects on subjects.subject_id=marks.subject_id
join class_registrations on class_registrations.classreg_id=subjects.classreg_id
where  marks.subject_id=$subject_id and marks.exam_session_id=$exam_session_id and marks.mark_gpa='$gpa'";
		 $subjects = $this->MainModel->AllQueryDalta($query);
		 echo json_encode($subjects);

	 }



	public function destroy($id)
    {
        $markData= $this->MainModel->getSingleData('mark_id', $id, 'marks', '*');
		$markId = $markData->mark_id;
        if (isset($markId)) {
            $result = $this->MainModel->deleteData('mark_id', $markId, 'marks');
            if ($result) {
                $this->session->set_flashdata('message', "Mark deleted successfully !!!!");
                redirect('mark-list');
            }
        } else {
            $this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
            redirect('mark-list');
        }
    }

}
