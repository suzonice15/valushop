<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MarkSheetController extends MX_Controller {

    public function __construct()
    {
        $this->load->model('MainModel');
        $this->load->model('MarkSheet');
		$this->load->library('Pdf');

//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
    }

    public function index()
    {

    }

    public function create()
    {
        $data['main'] = "Single student marksheet";
        $data['active'] = "view marksheet";
        $data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
        $data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
        //var_dump($data['students']);exit();
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
        $data['pageContent'] = $this->load->view('management/marksheet/marksheet_create', $data, true);
        $this->load->view('layouts/main', $data);
    }


    public function store()
	{
	}
    public function show($id)
    {

    }
    public function StudentSelection()
    {
    }
	public function studentMarksheet()
	{
		$studentId = $this->input->post('student_id');
		$sessionId= $this->input->post('session_id');
		$examsessionQuery="select * from exam_session_com where exam_session_com.session_id=$sessionId order by exam_session_com.exam_session_id DESC";
		$examSession=$this->MainModel->AllQueryDalta($examsessionQuery);

		$first=$examSession[0]->exam_session_id;
		$second=$examSession[1]->exam_session_id;
		$third=$examSession[2]->exam_session_id;


		$query="select subject_name
,sum(firs) firs
,sum(sec) sec
,sum(ann) ann from
(SELECT
subject_name,subject_id,
SUM(IF(exam_session_id = $first, mark_obtained, 0)) AS firs,
SUM(IF(exam_session_id = $second, mark_obtained, 0)) AS sec,
SUM(IF(exam_session_id = $third, mark_obtained, 0)) AS ann
FROM
(select students.student_name,exam_session_com.exam_session_name,exam_session_com.exam_session_id,subjects.subject_id,subjects.subject_name,marks.mark_obtained,marks.mark_gpa,marks.mark_grade_point from marks
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id
join sessions on sessions.session_id=exam_session_com.session_id
join subjects on subjects.subject_id=marks.subject_id
join students on students.student_id=marks.student_id
where sessions.session_id=$sessionId and marks.student_id=$studentId
) marks
GROUP BY
subject_id, exam_session_id) pivottable
group by subject_id";
		$data['marksheet']=$this->MainModel->AllQueryDalta($query);
		$data['first']=0;
		$data['second']=0;
		$data['final']=0;
		$i=0;

		foreach ($data['marksheet'] as $mark):
			$data['first']=$data['first']+$mark->firs;
			$data['second']=$data['second']+$mark->sec;
			$data['final']=$data['final']+$mark->ann;
			$i++;
		endforeach;
		$data['subjectCounter']=$i;

	echo json_encode($data);
	}


	public function edit($id)
    {
        $data['markdata']= $this->MainModel->getSingleData('mark_id', $id, 'marks', '*');

        $markId= $data['markdata']->mark_id;
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
        if (isset($markId)) {
            $data['title'] = "Mark update page ";
            $data['main'] = "Mark";
            $data['active'] = "Update mark";
            $data['pageContent'] = $this->load->view('management/marks/marks_edit', $data, true);
            $this->load->view('layouts/main', $data);
        } else {
            $this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
            redirect('student-list');
        }

    }

    public function update()
    {
        $mark_id = $this->input->post('mark_id');
        // check if the element exists before trying to edit it
        $markData= $this->MainModel->getSingleData('mark_id', $mark_id, 'marks', '*');
		$markId = $markData->mark_id;

        if (isset($markId)) {
			$data['exam_session_id'] = $this->input->post('exam_session_id');
			$data['subject_id'] = $this->input->post('subject_id');
			$data['mark_obtained'] = $this->input->post('mark_obtained');
			$data['mark_grade_point'] = $this->input->post('mark_grade_point');
			$data['student_id'] = $this->input->post('student_id');
			$data['mark_gpa'] = $this->input->post('mark_gpa');
			// var_dump($data);exit();
			$this->form_validation->set_rules('exam_session_id', 'Student name', 'required');
			$this->form_validation->set_rules('subject_id', 'Student name', 'required');
			$this->form_validation->set_rules('mark_obtained', 'Student name', 'required');
			$this->form_validation->set_rules('mark_gpa', 'Student name', 'required');
			$this->form_validation->set_rules('student_id', 'Student name', 'required');

			if ($this->form_validation->run()) {
                $result = $this->MainModel->updateData('mark_id', $markId, 'marks', $data);
                if ($result) {
                    $this->session->set_flashdata('message', "Mark updated successfully !!!!");
                    redirect('mark-list');
                }
            } else {

                $this->session->set_flashdata('error', "value reqiured");
                redirect('mark-update');
            }
        } else {
            $this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
            redirect('mark-list');
        }

    }

	public function multipleDataStore($subjectId)
	{
		$query = "select  students.student_name,students.student_id,students.student_roll,subjects.*   from subjects    join class_registrations on class_registrations.classreg_id=subjects.classreg_id join classreg_section_com
on classreg_section_com.classreg_id=class_registrations.classreg_id join student_classreg_section_com on student_classreg_section_com.classreg_section_id=classreg_section_com.classreg_section_id
join students on student_classreg_section_com.student_id=students.student_id where subjects.subject_id
=$subjectId";
		$data['studentSubjectRelations'] = $this->MainModel->AllQueryDalta($query);
		$query="select * from marks  join subjects on subjects.subject_id=marks.subject_id where subjects.subject_id=$subjectId";

        $data['studentMarkRelations'] = $this->MainModel->AllQueryDalta($query);
//echo '<pre>';
//		print_r($data['studentMarkRelations'] );exit();

        $data['title'] = "Mark  registration form ";
		$data['main'] = "Marks relation";
		$data['active'] = "add mark ";
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/marks_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function multipleMarkForm()
	{


		$data['title'] = "Mark  registration form ";
		$data['main'] = "Marks relation";
		$data['active'] = "add mark ";
		$query="select * from subjects join class_registrations on  class_registrations.classreg_id=subjects.classreg_id order by subject_id desc";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['examSessionRelations'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['pageContent'] = $this->load->view('management/marks/multiple_mark_form', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function multipleDataInsertInDB()
	{
		$studentDataArray = array();
		$gradePointDataArray = array();
		$gpaDataArray = array();
		$markDataArray = array();
		$data['subject_id'] = $this->input->post('subject_id');
		$data['exam_session_id'] = $this->input->post('exam_session_id');
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$studentId=$this->input->post('student_id');
		if(isset($studentId)) {
			$studentData = implode(',', $this->input->post('student_id'));
			$studentDataArray = explode(',', $studentData);
			$markData = implode(',', $this->input->post('mark_obtained'));
			$markDataArray = explode(',', $markData);
			$gpaData = implode(',', $this->input->post('mark_gpa'));
			$gpaDataArray = explode(',', $gpaData);
			$gradPointeData = implode(',', $this->input->post('mark_grade_point'));
			$gradePointDataArray = explode(',', $gradPointeData);
			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['student_id'] = $studentDataArray[$i];
				$data['mark_grade_point'] = $gradePointDataArray[$i];
				$data['mark_gpa'] = $gpaDataArray[$i];
				$data['mark_obtained'] = $markDataArray[$i];
				$result = $this->MainModel->insertData('marks', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Mark  added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('subject-list');
			}
		}
		else {

			$query = "select * from marks where exam_session_id=$examSessionId and  subject_id=$subjectId";
			$markData = $this->MainModel->AllQueryDalta($query);

			if ($markData > 0) {
				$this->Mark->markDelete($subjectId, $examSessionId);
			}
			$data['relationMessage'] = "You dont add any information in database !!!!!!!!!";
			$this->session->set_userdata($data);
			redirect('subject-list');
		}


	}

	public function mypdf()

	{
		$student_id = $this->input->post('student_id');
		$exam_session_id= $this->input->post('exam_session_id');
		$classreg_section_id= $this->input->post('classreg_section_id');
		$query = "select student_name,subject_name,exam_session_name,classreg_section_name,mark_obtained,mark_grade_point,mark_gpa from marks 
join student_classreg_section_com on student_classreg_section_com.student_id=marks.student_id
join students on students.student_id=student_classreg_section_com.student_id
join subjects on subjects.subject_id=marks.subject_id
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
where marks.exam_session_id=$exam_session_id and student_classreg_section_com.classreg_section_id=$classreg_section_id  and student_classreg_section_com.student_classreg_section_isActive=1
and students.student_id=$student_id";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		$exam_session_name=$data['students'][0]->exam_session_name;
		$classreg_section_name=$data['students'][0]->classreg_section_name;
//		echo '<pre>';
//		print_r($data['students']);exit();
		$totalMarks=0;
		$totalGpa=0;
		$subjectCount=0;
		$finalgpa=0;
		foreach($data['students'] as $student){
			$subjectCount++;
			$totalMarks=$totalMarks+$student->mark_obtained;
			$totalGpa=$totalGpa+$student->mark_grade_point;
		}

		$finalgpa=$totalGpa/$subjectCount;
		if($finalgpa==5){
			$data['gradePoint']='A+';

		}
		else if($finalgpa<5 and $finalgpa>=4){
			$data['gradePoint']='A';

		}
		else if($finalgpa<4 and $finalgpa>=3.5){
			$data['gradePoint']='A-';

		}
		else if($finalgpa<3.5 and $finalgpa>=3){
			$data['gradePoint']='B';

		}
		else if($finalgpa<3 and $finalgpa>=2){
			$data['gradePoint']='C';

		}
		else if($finalgpa<2 and $finalgpa>=1){
			$data['gradePoint']='D';

		}
		else {
			$data['gradePoint']='F';
		}
		$data['finalGpa']=sprintf("%.2f", $finalgpa);
		$data['finalmark']=sprintf("%.2f", $totalMarks);
//				echo '<pre>';
//		print_r($data);exit();
		$this->pdf->load_view('pdf',$data);
		$this->pdf->render();
		$this->pdf->stream($classreg_section_name."-".$exam_session_name."-".$student_id.".pdf");
	}


	public function destroy($id)
    {
        $markData= $this->MainModel->getSingleData('mark_id', $id, 'marks', '*');
		$markId = $markData->mark_id;
        if (isset($markId)) {
            $result = $this->MainModel->deleteData('mark_id', $markId, 'marks');
            if ($result) {
                $this->session->set_flashdata('message', "Mark deleted successfully !!!!");
                redirect('mark-list');
            }
        } else {
            $this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
            redirect('mark-list');
        }
    }
    public  function  markSheetGenerate(){

		$data['main'] = "Marksheet";
		$data['active'] = "view marksheet";
		$data['classData'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['examData'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$classreg_section_id = $this->input->post('classreg_section_id');
		$exam_session_id = $this->input->post('exam_session_id');
		$data['exam_Id'] = $exam_session_id;
		$data['classId'] = $classreg_section_id;

		if(isset($classreg_section_id) && isset($exam_session_id)){
			$subjectQuery="select subject_name,subject_id from subjects 
join class_registrations on class_registrations.classreg_id=subjects.classreg_id
join classreg_section_com on classreg_section_com.classreg_id=class_registrations.classreg_id
where classreg_section_com.classreg_section_id=$classreg_section_id and classreg_section_com.classreg_section_isActive=1
";
			$data['subjects']=$this->MainModel->AllQueryDalta($subjectQuery);
			$studentQuery="select student_name,student_phone,students.student_id from students
join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id

where student_classreg_section_com.student_classreg_section_isActive=1 and student_classreg_section_com.classreg_section_id=$classreg_section_id";
			$data['students']=$this->MainModel->AllQueryDalta($studentQuery);



		}
//		echo 'pre';
//		print_r($data);exit();
		$data['pageContent'] = $this->load->view('management/marksheet/marksheet_generate', $data, true);
		$this->load->view('layouts/main', $data);
	}


}
