<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClassRoomsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');

		$userId=$this->session->userdata('user_role');
		if($userId ==2){
			redirect('admin');

		}
	}

	public function index()
	{
		$data['main'] = "Class room";
		$data['active'] = "Class room view";
		$data['classRooms'] = $this->MainModel->getAllData('', 'class_room', '*', 'class_room_id DESC');
		$data['pageContent'] = $this->load->view('management/classRooms/class_rooms_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Class room  registration form ";
		$data['main'] = "Class room ";
		$data['active'] = "Add section";
		$data['pageContent'] = $this->load->view('management/classRooms/class_rooms_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['class_room_name'] = $this->input->post('class_room_name');
		$this->form_validation->set_rules('class_room_name', 'section name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('class_room', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Class room  added successfully !!!!");
				redirect('class-room-create');
			}
		} else {

			$this->session->set_flashdata('message', "value reqiured");
			redirect('class-room-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{

		$data['classRoom'] = $this->MainModel->getSingleData('class_room_id', $id, 'class_room', '*');
		$classRoomId = $data['classRoom']->class_room_id;
		if (isset($classRoomId)) {
			$data['title'] = "Class room  update page ";
			$data['main'] = "Class room ";
			$data['active'] = "Update Class room ";
			$data['pageContent'] = $this->load->view('management/classRooms/class_rooms_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('class-room-list');
		}

	}

	public function update()
	{
		$classRoomId = $this->input->post('class_room_id');
		// check if the element exists before trying to edit it
		$sectionData = $this->MainModel->getSingleData('class_room_id', $classRoomId, 'class_room', '*');
		$classRoomId = $sectionData->class_room_id;

		if (isset($classRoomId)) {
			$data['class_room_name'] = $this->input->post('class_room_name');
			$this->form_validation->set_rules('class_room_name', 'section name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('class_room_id', $classRoomId, 'class_room', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Class room  updated successfully !!!!");
					redirect('class-room-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('class-room-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('class-room-list');
		}

	}

	public function destroy($id)
	{
		$sectionData = $this->MainModel->getSingleData('class_room_id', $id, 'class_room', '*');
		$classRoomId = $sectionData->class_room_id;
		if (isset($classRoomId)) {
			$result = $this->MainModel->deleteData('class_room_id', $classRoomId, 'class_room');
			if ($result) {
				$this->session->set_flashdata('error', "Class room  deleted successfully !!!!");
				redirect('class-room-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('class-room-list');
		}
	}
}
