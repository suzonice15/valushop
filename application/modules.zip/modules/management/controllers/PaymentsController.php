<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PaymentsController extends MX_Controller {

					 public function __construct(){

						 $userId=$this->session->userdata('user_id');
						 if($userId ==null){
							 redirect('admin');

						 }
					 }
					 
					 public function index(){
						 
					 }
					 
					 public function create(){
						 
					 }
					 
					 public function store(Request $request){
							
							try {

							   

							} catch (Exception $exception) {

							   
							}
					 
					 }
					  
					 public function show($id){
						 
					 }
					 
					 public function edit($id){
						 
					 }
					 
					 public function update($id, Request $request){
					 
						try {

							   

							} catch (Exception $exception) {

							   
							}
					 }
					 
					 public function destroy($id){
					 
					 try {

							   

							} catch (Exception $exception) {

							   
							}
					 }
}
