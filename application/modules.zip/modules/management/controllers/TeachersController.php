<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TeachersController extends MX_Controller {

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Teachers";
		$data['active'] = "Teachers view";
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');

		$data['pageContent'] = $this->load->view('management/teachers/teachers_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Teacher registration form ";
		$data['main'] = "Teacher";
		$data['active'] = "Add teacher";
		$data['designations'] = $this->MainModel->getAllData('', 'designations', '*', 'designation_id DESC');
		$data['pageContent'] = $this->load->view('management/teachers/teachers_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{
        $data['class_name']=$this->input->post('class_name');
		if(isset($_FILES["teacher_picture_path"]["name"]))
		{
			if((($_FILES["teacher_picture_path"]["type"]=="image/jpg") || ($_FILES["teacher_picture_path"]["type"]=="image/jpeg") || ($_FILES["teacher_picture_path"]["type"]=="image/png") || ($_FILES["teacher_picture_path"]["type"]=="image/gif"))){
			$uploaded_image_path = "uploads/teachers/".time().'-'.$_FILES["teacher_picture_path"]["name"];

			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$this->load->library('upload', $config);
			if ($_FILES["teacher_picture_path"]["error"] > 0) {
				echo "Return Code: " . $_FILES["teacher_picture_path"]["error"] . "<br />";
			}
			else
			{
				move_uploaded_file ($_FILES["teacher_picture_path"]["tmp_name"],$uploaded_image_path);

				$config['image_library'] = 'gd2';
				$config['source_image'] = $uploaded_image_path;
				$config['create_thumb'] = false;
				$config['maintain_ratio'] = TRUE;
				$config['quality'] = '60%';
				$config['width'] = 300;
				$config['height'] = 300;
				$config['_image'] = $uploaded_image_path;
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$data['teacher_picture_path']=$uploaded_image_path;
			}
		}}
		//die();
		$data['teacher_full_name'] = $this->input->post('teacher_full_name');
		$data['teacher_nid'] = $this->input->post('teacher_nid');
		$data['teacher_sex'] = $this->input->post('teacher_sex');
		$data['teacher_religion'] = $this->input->post('teacher_religion');
		$data['teacher_blood_group'] = $this->input->post('teacher_blood_group');
		$data['teacher_email'] = $this->input->post('teacher_email');
		$data['teacher_address'] = $this->input->post('teacher_address');
		$data['teacher_contact_no'] = $this->input->post('teacher_contact_no');
		$data['designation_id'] = $this->input->post('designation_id');
		$data['teacher_joining_date'] = date('Y-m-d',strtotime($this->input->post('teacher_joining_date')));
		$data['teacher_mpo_date'] =  date('Y-m-d',strtotime($this->input->post('teacher_mpo_date')));
			$result = $this->MainModel->returnInsertId('teachers', $data);
			if($result) {
				/***************************traing information******************************/
				$qualification_name = implode(',', array_filter($this->input->post('qualification_name')));
				$qualification_name_array = explode(',', $qualification_name);
				$qualification_year = implode(',', array_filter($this->input->post('qualification_year')));
				$qualification_year_array = explode(',', $qualification_year);
				$qualification_result = implode(',', array_filter($this->input->post('qualification_result')));
				$qualification_result_array = explode(',', $qualification_result);
				$qualification_board = implode(',', array_filter($this->input->post('qualification_board')));
				$qualification_board_array = explode(',', $qualification_board);
				for ($i = 0; $i < sizeof($qualification_name_array); $i++) {
					$edu['teacher_id'] = $result;
					$edu['qualification_name'] = $qualification_name_array[$i];
					$edu['qualification_year'] = $qualification_year_array[$i];
					$edu['qualification_result'] = $qualification_result_array[$i];
					$edu['qualification_board'] = $qualification_board_array[$i];
					$this->MainModel->insertData('qualifications', $edu);
				}
				$teacher_training_name = implode(',', array_filter($this->input->post('teacher_training_name')));
				$teacher_training_name_array = explode(',', $teacher_training_name);
				$teacher_training_duration = implode(',', array_filter($this->input->post('teacher_training_duration')));
				$teacher_training_duration_array = explode(',', $teacher_training_duration);
				$teacher_training_starting_date = implode(',', array_filter($this->input->post('teacher_training_starting_date')));
				$teacher_training_starting_date_array = explode(',', $teacher_training_starting_date);
				$teacher_training_endingdate = implode(',', array_filter($this->input->post('teacher_training_endingdate')));
				$teacher_training_endingdate_array = explode(',', $teacher_training_endingdate);
				for ($i = 0; $i < sizeof($teacher_training_name_array); $i++) {
					$trining['teacher_id'] = $result;
					$trining['teacher_training_name'] = $teacher_training_name_array[$i];
					$trining['teacher_training_duration'] = $teacher_training_duration_array[$i];
					$trining['teacher_training_starting_date'] = $teacher_training_starting_date_array[$i];
					$trining['teacher_training_endingdate'] = $teacher_training_endingdate_array[$i];
					$this->MainModel->insertData('teacher_training', $trining);
				}

				$trainging_service_name = implode(',', array_filter($this->input->post('trainging_service_name')));
				$trainging_service_name_array = explode(',', $trainging_service_name);
				$trainging_service_duration = implode(',', array_filter($this->input->post('trainging_service_duration')));
				$trainging_service_duration_array = explode(',', $trainging_service_duration);
				$trainging_service_starting_date = implode(',', array_filter($this->input->post('trainging_service_starting_date')));
				$trainging_service_starting_date_array = explode(',', $trainging_service_starting_date);
				$trainging_service_ending_date = implode(',', array_filter($this->input->post('trainging_service_ending_date')));
				$trainging_service_ending_date_array = explode(',', $trainging_service_ending_date);
				for ($i = 0; $i < sizeof($trainging_service_name_array); $i++) {
					$service['teacher_id'] = $result;
					$service['trainging_service_name'] = $trainging_service_name_array[$i];
					$service['trainging_service_duration'] = $trainging_service_duration_array[$i];
					$service['trainging_service_starting_date'] = $trainging_service_starting_date_array[$i];
					$service['trainging_service_ending_date'] = $trainging_service_ending_date_array[$i];
					$this->MainModel->insertData('trainging_service', $service);
				}
			}

			if ($result) {
				$this->session->set_flashdata('message', "Teacher added successfully !!!!");
				redirect('teacher-create');
			}



	}

	public function show($id)
	{
		$query="select *  from   teachers
join designations on designations.designation_id=teachers.designation_id
where teachers.teacher_id=$id";
		$data['teacher'] = $this->MainModel->QuerySingleData($query);
		$serviceQuery = "select *  from  trainging_service where teacher_id=$id";
		$data['services'] = $this->MainModel->AllQueryDalta($serviceQuery);
		$trainingQuery = "select *  from  teacher_training where teacher_id=$id";
		$data['traininges'] = $this->MainModel->AllQueryDalta($trainingQuery);
		$qualificationQuery = "select *  from  qualifications  where teacher_id=$id";
		$data['qualifications'] = $this->MainModel->AllQueryDalta($qualificationQuery);

//print_r($data);exit();
		$teacher_id = $data['teacher']->teacher_id;
		if (isset($teacher_id)) {
			$data['title'] = "Teacher profile page";
			$data['main'] = "Teacher";
			$data['active'] = "pofile of teacher";
			$data['pageContent'] = $this->load->view('management/teachers/teachers_show', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
			redirect('teacher-list');
		}
	}

	public function edit($id)
	{
		$data['teacher'] = $this->MainModel->getSingleData('teacher_id', $id, 'teachers', '*');
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$teacher_id = $data['teacher']->teacher_id;
		$serviceQuery = "select *  from  trainging_service where teacher_id=$teacher_id";
		$data['services'] = $this->MainModel->AllQueryDalta($serviceQuery);
		$trainingQuery = "select *  from  teacher_training where teacher_id=$teacher_id";
		$data['traininges'] = $this->MainModel->AllQueryDalta($trainingQuery);
		$qualificationQuery = "select *  from  qualifications  where teacher_id=$teacher_id";
		$data['qualifications'] = $this->MainModel->AllQueryDalta($qualificationQuery);
		$data['designations'] = $this->MainModel->getAllData('', 'designations', '*', 'designation_id DESC');


		if (isset($teacher_id)) {
			$data['title'] = "Teacher update page ";
			$data['main'] = "Teacher";
			$data['active'] = "add Teacher";
			$data['pageContent'] = $this->load->view('management/teachers/teachers_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
			redirect('teacher-list');
		}

	}

	public function update()
	{
		$teacher_id = $this->input->post('teacher_id');
		// check if the element exists before trying to edit it
		$data_id['teacher'] = $this->MainModel->getSingleData('teacher_id', $teacher_id, 'teachers', '*');
		$teacherId = $data_id['teacher']->teacher_id;
		//var_dump($teacher_id);exit();

		if (isset($teacherId)) {
			$old_teacher_picture_path=$this->input->post('old_teacher_picture_path');
			$data['teacher_picture_path']=$this->input->post('old_teacher_picture_path');
			if(isset($_FILES["teacher_picture_path"]["name"]))
			{
				if((($_FILES["teacher_picture_path"]["type"]=="image/jpg") || ($_FILES["teacher_picture_path"]["type"]=="image/jpeg") || ($_FILES["teacher_picture_path"]["type"]=="image/png") || ($_FILES["teacher_picture_path"]["type"]=="image/gif"))){
					if(!empty($old_teacher_picture_path)){
						unlink($old_teacher_picture_path);

					}
					$uploaded_image_path = "uploads/teachers/".time().'-'.$_FILES["teacher_picture_path"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["teacher_picture_path"]["error"] > 0) {
						echo "Return Code: " . $_FILES["teacher_picture_path"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["teacher_picture_path"]["tmp_name"],$uploaded_image_path);								$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = TRUE;
						$config['quality'] = '60%';
						$config['width'] = 300;
						$config['height'] = 300;
						$config['_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['teacher_picture_path']=$uploaded_image_path;

					}
				}}
			$data['teacher_full_name'] = $this->input->post('teacher_full_name');
			$data['teacher_nid'] = $this->input->post('teacher_nid');
			$data['teacher_sex'] = $this->input->post('teacher_sex');
			$data['teacher_religion'] = $this->input->post('teacher_religion');
			$data['teacher_blood_group'] = $this->input->post('teacher_blood_group');
			$data['teacher_email'] = $this->input->post('teacher_email');
			$data['teacher_address'] = $this->input->post('teacher_address');
			$data['teacher_contact_no'] = $this->input->post('teacher_contact_no');
			$data['designation_id'] = $this->input->post('designation_id');
			$data['teacher_joining_date'] = date('Y-m-d',strtotime($this->input->post('teacher_joining_date')));
			$data['teacher_mpo_date'] =  date('Y-m-d',strtotime($this->input->post('teacher_mpo_date')));

				$result = $this->MainModel->updateData('teacher_id', $teacherId, 'teachers', $data);

				if ($result) {


					$qualification_name = implode(',', array_filter($this->input->post('qualification_name')));
					$qualification_name_array = explode(',', $qualification_name);
					$qualification_year = implode(',', array_filter($this->input->post('qualification_year')));
					$qualification_year_array = explode(',', $qualification_year);
					$qualification_result = implode(',', array_filter($this->input->post('qualification_result')));
					$qualification_result_array = explode(',', $qualification_result);
					$qualification_board = implode(',', array_filter($this->input->post('qualification_board')));
					$qualification_board_array = explode(',', $qualification_board);
					for ($i = 0; $i < sizeof($qualification_name_array); $i++) {
						$edu['qualification_name'] = $qualification_name_array[$i];
						$edu['qualification_year'] = $qualification_year_array[$i];
						$edu['qualification_result'] = $qualification_result_array[$i];
						$edu['qualification_board'] = $qualification_board_array[$i];
						$result = $this->MainModel->updateData('teacher_id', $teacherId, 'qualifications', $edu);

					}
					$teacher_training_name = implode(',', array_filter($this->input->post('teacher_training_name')));
					$teacher_training_name_array = explode(',', $teacher_training_name);
					$teacher_training_duration = implode(',', array_filter($this->input->post('teacher_training_duration')));
					$teacher_training_duration_array = explode(',', $teacher_training_duration);
					$teacher_training_starting_date = implode(',', array_filter($this->input->post('teacher_training_starting_date')));
					$teacher_training_starting_date_array = explode(',', $teacher_training_starting_date);
					$teacher_training_endingdate = implode(',', array_filter($this->input->post('teacher_training_endingdate')));
					$teacher_training_endingdate_array = explode(',', $teacher_training_endingdate);
					for ($i = 0; $i < sizeof($teacher_training_name_array); $i++) {
						$trining['teacher_training_name'] = $teacher_training_name_array[$i];
						$trining['teacher_training_duration'] = $teacher_training_duration_array[$i];
						$trining['teacher_training_starting_date'] = $teacher_training_starting_date_array[$i];
						$trining['teacher_training_endingdate'] = $teacher_training_endingdate_array[$i];
						$result = $this->MainModel->updateData('teacher_id', $teacherId, 'teacher_training', $trining);

					}

					$trainging_service_name = implode(',', array_filter($this->input->post('trainging_service_name')));
					$trainging_service_name_array = explode(',', $trainging_service_name);
					$trainging_service_duration = implode(',', array_filter($this->input->post('trainging_service_duration')));
					$trainging_service_duration_array = explode(',', $trainging_service_duration);
					$trainging_service_starting_date = implode(',', array_filter($this->input->post('trainging_service_starting_date')));
					$trainging_service_starting_date_array = explode(',', $trainging_service_starting_date);
					$trainging_service_ending_date = implode(',', array_filter($this->input->post('trainging_service_ending_date')));
					$trainging_service_ending_date_array = explode(',', $trainging_service_ending_date);
					for ($i = 0; $i < sizeof($trainging_service_name_array); $i++) {
						$service['trainging_service_name'] = $trainging_service_name_array[$i];
						$service['trainging_service_duration'] = $trainging_service_duration_array[$i];
						$service['trainging_service_starting_date'] = $trainging_service_starting_date_array[$i];
						$service['trainging_service_ending_date'] = $trainging_service_ending_date_array[$i];
						$this->MainModel->insertData('trainging_service', $service);
						$result = $this->MainModel->updateData('teacher_id', $teacherId, 'trainging_service', $service);

					}






					$this->session->set_flashdata('message', "Teacher updated successfully !!!!");
					redirect('teacher-list');


				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('teacher-update');
			}


	}

public  function  teacherMobile($mobile){
	$mobileNumber = $this->MainModel->getDataRow('teacher_contact_no', $mobile, 'teachers', '*');
	if($mobileNumber>0){
		echo "This mobile number is already exist please enter another mobile number ";
	}
	else {

		echo "";
	}

}


	public  function  teacherEmailCheck(){
		$teacher_email=$this->input->post('teacher_email');
		$emailTeacher = $this->MainModel->getDataRow('teacher_email', $teacher_email, 'teachers', '*');
		$emailStudent= $this->MainModel->getDataRow('student_email', $teacher_email, 'students', '*');

		if($emailTeacher>0){
			echo "This email are stored to database please try with other email ";
		}
		else if($emailStudent>0){

			echo "This email are stored to database please try with other email ";
		}
		else {
			echo "";

		}

	}


	public  function  teacherNid($nid){
		$teacherNid = $this->MainModel->getDataRow('teacher_nid', $nid, 'teachers', '*');
		if($teacherNid>0){
			echo "Please enter unique national id card number ";
		}
		else {

			echo "";
		}

	}

	public function destroy($id)
	{
		$data['Teacher'] = $this->MainModel->getSingleData('teacher_id', $id, 'Teachers', '*');
		$teacher_id = $data['Teacher']->teacher_id;
		if (isset($teacher_id)) {
			$result = $this->MainModel->deleteData('teacher_id', $id, 'Teachers');
			if ($result) {
				$this->session->set_flashdata('message', "Teacher deleted successfully !!!!");
				redirect('teacher-list');
			}
		} else {
			$this->session->set_flashdata('message', "The element you are trying to delete does not exist.");
			redirect('teacher-list');
		}
	}
	
}
