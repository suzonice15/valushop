<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  ShiftClassRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->model('ShiftClassRelation');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		///echo 'jfjfj';exit();
		$data['main'] = "Classes report";
		$data['active'] = "view classes report";
		$query = "select * from shift_classreg_section_com  join  classreg_section_com on classreg_section_com.classreg_section_id=
shift_classreg_section_com.classreg_section_id";
		$data['shiftClassSectionRelations'] = $this->MainModel->AllQueryDalta($query);
		$data['shifts'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');

		$data['pageContent'] = $this->load->view('management/shiftClassRelation/shiftClassRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{


		$data['title'] = "Shift ,  class and  section relation registration form ";
		$data['main'] = "Shift Class and Section Relation";
		$data['active'] = "Add shift ,  class and section relation  ";
		$query="select classreg_section_com.classreg_section_name,classreg_section_com.classreg_section_id from  classreg_section_com left join shift_classreg_section_com on classreg_section_com.classreg_section_id=shift_classreg_section_com.classreg_section_id 
where shift_classreg_section_com.classreg_section_id is null and shift_classreg_section_com.shift_classreg_section_isActive is null or shift_classreg_section_com.shift_classreg_section_isActive=0  ";
		$data['classSections'] = $this->MainModel->AllQueryDalta($query);

		//$data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['shift'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['pageContent'] = $this->load->view('management/shiftClassRelation/shiftClassRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['shift_classreg_section_name'] = $this->input->post('shift_classreg_section_name');
		$data['shift_id'] = $this->input->post('shift_id');

		$this->form_validation->set_rules('shift_id', 'shift  name', 'required');
		$this->form_validation->set_rules('shift_classreg_section_name', 'shift  name', 'required');
		$this->form_validation->set_rules('classreg_section_id', 'class name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('shift_classreg_section_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Shift relation with class and section added successfully !!!!");
				redirect('class-section-shift-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('shift-class-create');
		}


	}

	public function show($id)
	{

	}


	public function multipleDataStore($shiftId)
	{
		$query = "select shift_classreg_section_com.*,class_registrations.classreg_name,class_registrations.classreg_id   as classreg_id ,class_registrations.classreg_name as class_name from shift_classreg_section_com  right join class_registrations on shift_classreg_section_com.classreg_id=class_registrations.classreg_id
where class_registrations.classreg_id=$shiftId ";
		$data['classSections'] = $this->MainModel->AllQueryDalta($query);
		$data['shiftClassRelations'] = $this->MainModel->AllQueryDalta($query);
                //print_r($data);exit();
                
		$data['title'] = "Shift relation registration form ";
		$data['main'] = "Shift relation";
		$data['second'] = "Shift relation option";
		$data['active'] = "add Shift relation";
		$data['shifts'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['pageContent'] = $this->load->view('management/shiftClassRelation/shiftClassRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$shiftDataArray = array();
		//exit();
		$data['classreg_id'] = $this->input->post('classreg_id');
		$class_id = $this->input->post('classreg_id');
		$shiftData = implode(',', $this->input->post('shift_id'));
		$shiftDataArray = explode(',', $shiftData);
		foreach ($shiftDataArray as $index => $val) {
			$shiftDataArray[$index] = $val;
		}
		$shiftRelation = $this->MainModel->getDataRow('classreg_id', $class_id, 'shift_classreg_section_com', '*');
		if ($shiftRelation > 0) {
			$this->MainModel->deleteData('classreg_id', $class_id, 'shift_classreg_section_com');
		}
		for ($i = 0; $i < sizeof($shiftDataArray); $i++) {
			$data['shift_id'] = $shiftDataArray[$i];
			$result = $this->MainModel->insertData('shift_classreg_section_com', $data);

		}

		if ($result) {
                      $data['relationMessage']="Class relation with shift added successfully !!!!";
		 $this->session->set_userdata($data);
			//$this->session->set_flashdata('messege', "Class relation with shift added successfully !!!!");
			redirect('shift-list');
		}


	}

	public function edit($id)
	{
		$data['shiftClassSectionRelations'] = $this->MainModel->getSingleData('shift_classreg_section_id', $id, 'shift_classreg_section_com', '*');
		$shiftClassSectionId = $data['shiftClassSectionRelations']->shift_classreg_section_id;
		$data['classSectionRealtions'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['shift'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');


		if (isset($shiftClassSectionId)) {
			$data['title'] = "Shift & class relation update page ";
			$data['main'] = "Shift class relation";
			$data['second'] = "Shift class relation ";
			$data['active'] = "update Shift class ";
			$data['pageContent'] = $this->load->view('management/shiftClassRelation/shiftClassRelation_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('shift-class-list');
		}

	}

	public function update()
	{
		$shiftClassSectionId = $this->input->post('shift_classreg_section_id');
		// check if the element exists before trying to edit it
		$shiftClassData = $this->MainModel->getSingleData('shift_classreg_section_id', $shiftClassSectionId, 'shift_classreg_section_com', '*');
		$shiftClassSectionId = $shiftClassData->shift_classreg_section_id;

		if (isset($shiftClassSectionId)) {
			$data['classreg_section_id'] = $this->input->post('classreg_section_id');
			$data['shift_classreg_section_name'] = $this->input->post('shift_classreg_section_name');
			$data['shift_id'] = $this->input->post('shift_id');

			$this->form_validation->set_rules('shift_id', 'shift  name', 'required');
			$this->form_validation->set_rules('shift_classreg_section_name', 'shift  name', 'required');
			$this->form_validation->set_rules('classreg_section_id', 'class name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('shift_classreg_section_id', $shiftClassSectionId, 'shift_classreg_section_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Shift  relation with class and section updated successfully !!!!");
					redirect('class-section-shift-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('class-section-shift-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('class-section-shift-list');
		}

	}

	public function destroy($id)
	{
		$shiftClassData = $this->MainModel->getSingleData('shift_classreg_section_id', $id, 'shift_classreg_section_com', '*');
		$shiftClassDataId = $shiftClassData->shift_classreg_section_id;
		if (isset($shiftClassDataId)) {
			$result = $this->MainModel->deleteData('shift_classreg_section_id', $shiftClassDataId, 'shift_classreg_section_com');
			if ($result) {
				$this->session->set_flashdata('message', "Shift  relation with class and section deleted successfully !!!!");
				redirect('class-section-shift-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('class-section-shift-list');
		}
	}

	public function shiftClassSelection()
	{
		$shift_id= $this->input->post('shift_id');
		$class_id= $this->input->post('class_id');
		$query = "select  shift_name,classreg_name,section_name from shift_classreg_section_com  
join shifts on shifts.shift_id=shift_classreg_section_com.shift_id
join classreg_section_com on classreg_section_com.classreg_section_id=shift_classreg_section_com.classreg_section_id join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id
where shift_classreg_section_com.shift_id=$shift_id and class_registrations.classreg_id=$class_id";
		$shiftClassData = $this->MainModel->AllQueryDalta($query);
		echo json_encode($shiftClassData);


	}

}
