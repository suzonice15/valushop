<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  TeacherSubjectRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId = $this->session->userdata('user_id');
//		if ($userId == null) {
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		//echo 'jfjfj';exit();
		$data['main'] = "Teachers report";
		$data['active'] = "view teacher report";
		$query = "select teacher_subject_com.*,subject_name,teacher_full_name,classreg_name,teacher_contact_no from teacher_subject_com 
join teachers on teachers.teacher_id=teacher_subject_com.teacher_id  join
 subjects on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id
order by teacher_subject_com.teacher_subject_id ASC
";
		$data['teacherRelations'] = $this->MainModel->AllQueryDalta($query);
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');

		//print_r($data);exit();
		$data['pageContent'] = $this->load->view('management/teacherSubjectRelation/teacherSubjectRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Subject relation registration form";
		$data['main'] = "Teacher subject relation";
		$data['active'] = "Add teacher subject relation ";
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');
		$query = "select subjects.subject_id,subjects.subject_name,subjects.subject_code from 
subjects left join teacher_subject_com on subjects.subject_id=teacher_subject_com.subject_id 
where teacher_subject_com.subject_id is null and teacher_subject_com.teacher_subject_isActive is null or teacher_subject_com.teacher_subject_isActive=0";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('management/teacherSubjectRelation/teacherSubjectRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function classData()
	{
		$classreg_id = $this->input->post('classreg_id');
		$query = "select teacher_full_name,subject_name,classreg_name,teacher_contact_no from  teachers join teacher_subject_com on teacher_subject_com.teacher_id=teachers.teacher_id 
join subjects on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id
where subjects.classreg_id=$classreg_id";
		$classes = $this->MainModel->AllQueryDalta($query);
		echo json_encode($classes);


	}


	public function subjectData()
	{
		$subject_id = $this->input->post('subject_id');
		$query = "select teacher_full_name,subject_name,classreg_name,teacher_contact_no from  teachers join teacher_subject_com on teacher_subject_com.teacher_id=teachers.teacher_id 
join subjects on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id
where subjects.subject_id=$subject_id";
		$subjects = $this->MainModel->AllQueryDalta($query);
		echo json_encode($subjects);


	}

	public function teacherData()
	{
		$teacher_id = $this->input->post('teacher_id');
		$query = "select teacher_full_name,subject_name,classreg_name,teacher_contact_no from  teachers join teacher_subject_com on teacher_subject_com.teacher_id=teachers.teacher_id 
join subjects on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id
where teachers.teacher_id=$teacher_id";
		$teachers = $this->MainModel->AllQueryDalta($query);
		echo json_encode($teachers);


	}


	public function store()
	{

		$data['teacher_id'] = $this->input->post('teacher_id');
		$data['subject_id'] = $this->input->post('subject_id');
		$data['teacher_subject_name'] = $this->input->post('teacher_subject_name');
		//print_r($data);exit();

		$this->form_validation->set_rules('subject_id', 'subject  name', 'required');
		$this->form_validation->set_rules('teacher_id', 'teacher name', 'required');
		$this->form_validation->set_rules('teacher_subject_name', 'teacher name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('teacher_subject_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Teacher  relation with subject's added successfully !!!!");
				redirect('teacher-subject-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('teacher-subject-create');
		}


	}

	public function show($id)
	{

	}

	public function multipleDataStore($teacherId)
	{

		$data['teacher'] = $this->MainModel->getSingleData('teacher_id', $teacherId, 'teachers', '*');
		$data['teacherRelations'] = $this->MainModel->getAllData("teacher_id=$teacherId", 'teacher_subject_com', '*', 'subject_id DESC');

		$query = "select subjects.subject_id,subjects.subject_name,subjects.subject_code ,classreg_name from 
subjects left join teacher_subject_com on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on class_registrations.classreg_id=subjects.classreg_id
where teacher_subject_com.subject_id is null and teacher_subject_com.teacher_subject_isActive is null or teacher_subject_com.teacher_subject_isActive=0
union 
select subjects.subject_id,subjects.subject_name,subjects.subject_code,classreg_name from 
subjects left join teacher_subject_com on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on class_registrations.classreg_id=subjects.classreg_id
where teacher_subject_com.teacher_id=$teacherId and teacher_subject_com.teacher_subject_isActive=1";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		//print_r($data['subjects']);exit();
		//$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
		$data['title'] = "Subject relation registration form ";
		$data['main'] = "Teacher subject relation";
		$data['second'] = "Subject relation ";
		$data['active'] = "Add subject relation";
		$data['pageContent'] = $this->load->view('management/teacherSubjectRelation/teacherSubjectRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$subjectDataArray = array();
		$teacherSubjectDataArray = array();
		$data['teacher_id'] = $this->input->post('teacher_id');
		$teacherId = $this->input->post('teacher_id');
		$subjectDataId = $this->input->post('subject_id');
		if ($subjectDataId) {
			$subjectData = implode(',', $this->input->post('subject_id'));
			$teacherSubjectData = implode(',', array_filter($this->input->post('teacher_subject_name')));
			$subjectDataArray = explode(',', $subjectData);
			$teacherSubjectDataArray = explode(',', $teacherSubjectData);

			$teacherData = $this->MainModel->getDataRow('teacher_id', $teacherId, 'teacher_subject_com', '*');
			if ($teacherData > 0) {
				$this->MainModel->deleteData('teacher_id', $teacherId, 'teacher_subject_com');
			}

			for ($i = 0; $i < sizeof($subjectDataArray); $i++) {
				$data['teacher_id'] = $this->input->post('teacher_id');
				$data['teacher_subject_name'] = $teacherSubjectDataArray[$i];
				$data['teacher_subject_isActive'] = 1;

				$data['subject_id'] = $subjectDataArray[$i];

				$result = $this->MainModel->insertData('teacher_subject_com', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Teacher relation with subject added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('teacher-list');
			}
		} else {
			$teacherData = $this->MainModel->getDataRow('teacher_id', $teacherId, 'teacher_subject_com', '*');
			if ($teacherData > 0) {
				$this->MainModel->deleteData('teacher_id', $teacherId, 'teacher_subject_com');
			}
			$data['relationMessage'] = "You dont add any information in database !!!!";
			$this->session->set_userdata($data);
			redirect('teacher-list');

		}


	}

	public function edit($id)
	{
		$data['teacherRelation'] = $this->MainModel->getSingleData('teacher_subject_id', $id, 'teacher_subject_com', '*');
		//print_r($data);exit();
		$teacher_subject_id = $data['teacherRelation']->teacher_subject_id;
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');

		if (isset($teacher_subject_id)) {
			$data['title'] = "Teacher subject relation update page ";
			$data['main'] = "Teacher subject relation";
			$data['second'] = "Teacher subject relation ";
			$data['active'] = "Update teacher subject relation ";
			$data['pageContent'] = $this->load->view('management/teacherSubjectRelation/teacherSubjectRelation_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('teacher-subject-list');
		}

	}

	public function update()
	{
		$teacher_subject_id = $this->input->post('teacher_subject_id');
		// check if the element exists before trying to edit it
		$teacherSubjectRelation = $this->MainModel->getSingleData('teacher_subject_id', $teacher_subject_id, 'teacher_subject_com', '*');
		$teacherSubjectRelation = $teacherSubjectRelation->teacher_subject_id;

		if (isset($teacherSubjectRelation)) {
			$data['teacher_id'] = $this->input->post('teacher_id');
			$data['subject_id'] = $this->input->post('subject_id');
			$data['teacher_subject_name'] = $this->input->post('teacher_subject_name');
			//print_r($data);exit();

			$this->form_validation->set_rules('subject_id', 'subject  name', 'required');
			$this->form_validation->set_rules('teacher_id', 'teacher name', 'required');
			$this->form_validation->set_rules('teacher_subject_name', 'teacher name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('teacher_subject_id', $teacher_subject_id, 'teacher_subject_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Teacher  relation with subject updated successfully !!!!");
					redirect('teacher-subject-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('teacher-subject-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('teacher-subject-list');
		}

	}

	public function subjectReport()
	{
		$classreg_id = $this->input->post('classreg_id');
		$query = "select teacher_full_name,subject_name,classreg_name,teacher_contact_no from  teachers join teacher_subject_com on teacher_subject_com.teacher_id=teachers.teacher_id 
join subjects on subjects.subject_id=teacher_subject_com.subject_id join class_registrations on subjects.classreg_id=class_registrations.classreg_id
where subjects.classreg_id=$classreg_id";
		$data['teacherRelations'] = $this->MainModel->AllQueryDalta($query);
//		$data['pageContent'] = $this->load->view('management/Marks/classWiseMark', $data, true);
//		$this->load->view('layouts/main', $data);
		$this->pdf->load_view('management/TeacherSubjectRelation/subjectReport',$data);
		$this->pdf->render();
		$this->pdf->stream("mark.pdf");

	}

	public function destroy($id)
	{
		$teacher_subject_id = $this->MainModel->getSingleData('teacher_subject_id', $id, 'teacher_subject_com', '*');
		$teacher_subject_id = $teacher_subject_id->teacher_subject_id;
		if (isset($teacher_subject_id)) {
			$result = $this->MainModel->deleteData('teacher_subject_id', $id, 'teacher_subject_com');
			if ($result) {
				$this->session->set_flashdata('message', "Teacher  relation with subject deleted successfully !!!!");
				redirect('teacher-subject-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('teacher-subject-list');
		}
	}

}
