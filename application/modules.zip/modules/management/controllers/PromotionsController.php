<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  PromotionsController extends MX_Controller
{

    public function __construct()
    {
        $this->load->model('MainModel');
		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
    }

    public function index()
    {

    }

    public function create()
    {
        $data['title'] = "Class promotion";
        $data['main'] = "Promotion";
        $data['active'] = "Class promotion";
        $data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
        $data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
        $data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
        $data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
        $data['pageContent'] = $this->load->view('management/promotions/promotions_create', $data, true);
        $this->load->view('layouts/main', $data);
    }


    public function store()
    {



    }

    public function show($id)
    {

    }

    public function multipleDataStore()
    {


    }

    public function multipleDataInsertInDB()
    {


    }

    public function edit($id)
    {


    }

    public function update()
    {


    }

    public function destroy($id)
    {

    }

    public function StudentSelection()
    {
        $section_id = $this->input->post('section_id');
        $classreg_id = $this->input->post('classreg_id');

        $query = "select  students.student_id,students.student_name from students
join student_classreg_section_com  on students.student_id=student_classreg_section_com.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
where classreg_section_com.classreg_id=$classreg_id and student_classreg_section_com.student_classreg_section_isActive=1
 and classreg_section_com.section_id=COALESCE( nullif($section_id,0), classreg_section_com.section_id)";
        $students = $this->MainModel->AllQueryDalta($query);
        echo json_encode($students);
    }

    public function StudentTransfer()
	{

		$studentDataArray = array();
		$studentRollArray = array();
		$studentClassSectionName = array();
		$classSectionId = $this->input->post('class_section_id');
		$data['session_id'] = $this->input->post('session_id');
		$studentId = $this->input->post('student_id');
		if ($studentId) {
			$studentClassName = implode(',', array_filter($this->input->post('student_class_section_name')));
			$studentData = implode(',', array_filter($this->input->post('student_id')));
			$studentRollData = implode(',', array_filter($this->input->post('student_roll')));
			$studentDataArray = explode(',', $studentData);
			$studentRollArray = explode(',', $studentRollData);
			$studentClassSectionName = explode(',', $studentClassName);
			for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['classreg_section_id'] = $this->input->post('class_section_id');
				$data['student_id'] = $studentDataArray[$i];
				$data['student_roll'] = $studentRollArray[$i];
				$data['student_classreg_section_isActive'] = 1;
				$inactive['student_classreg_section_isActive'] = 0;
				$data['student_classreg_section_name'] = $studentClassSectionName[$i];
				$this->MainModel->updateData('student_id', $studentDataArray[$i], 'student_classreg_section_com', $inactive);

				$result = $this->MainModel->insertData('student_classreg_section_com', $data);

			}
			if ($result) {
				$data['relationMessage'] = "student transfer to  class added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('promotion-create');
			}
		}
		else {
			$data['relationMessage'] = "You dont transfer any student to new class !!!!";
			$this->session->set_userdata($data);
			redirect('promotion-create');
		}
	}


}
