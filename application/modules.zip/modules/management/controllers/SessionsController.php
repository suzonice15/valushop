<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SessionsController extends MX_Controller
{


	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Sessions";
		$data['active'] = "Sessions view";
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
		$data['pageContent'] = $this->load->view('management/sessions/sessions_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Session registration form ";
		$data['main'] = "Session";
		$data['active'] = "Add session";
		$data['pageContent'] = $this->load->view('management/sessions/sessions_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['session_name'] = $this->input->post('session_name');
		$data['session_start_date'] = date('Y-m-d', strtotime($this->input->post('session_start_date')));
		$data['session_end_date'] = date('Y-m-d', strtotime($this->input->post('session_end_date')));
		//var_dump($data);exit();
		$this->form_validation->set_rules('session_name', 'Session name', 'required');
		$this->form_validation->set_rules('session_start_date', 'session start  ', 'required');
		$this->form_validation->set_rules('session_end_date', 'session end ', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('sessions', $data);
			if ($result) {
				$this->session->set_flashdata('message', "sesion added successfully !!!!");
				redirect('session-create');
			}
		} else {
			$this->session->set_flashdata('message', "value required  of !!!!");
			redirect('session-create');
		}

	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['session'] = $this->MainModel->getSingleData('session_id', $id, 'sessions', '*');
		$sessionId = $data['session']->session_id;
		if (isset($sessionId)) {

			$data['title'] = "Session update page ";
			$data['main'] = "Session";
			$data['active'] = "Update session";
			$data['pageContent'] = $this->load->view('management/sessions/sessions_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('session-list');
		}
	}

	public function update()
	{


		$session_id = $this->input->post('session_id');
		// check if the element exists before trying to edit it
		$sessionData = $this->MainModel->getSingleData('session_id', $session_id, 'sessions', '*');
		//	var_dump($data_id['session']);exit();
		$sessionId = $sessionData->session_id;

		if (isset($sessionId)) {

			$data['session_name'] = $this->input->post('session_name');
			$data['session_start_date'] = date('Y-m-d', strtotime($this->input->post('session_start_date')));
			$data['session_end_date'] = date('Y-m-d', strtotime($this->input->post('session_end_date')));
			$this->form_validation->set_rules('session_name', 'Session name', 'required');
			$this->form_validation->set_rules('session_start_date', 'session start date ', 'required');
			$this->form_validation->set_rules('session_end_date', 'session end name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('session_id', $sessionId, 'sessions', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Session updated successfully !!!!");
					redirect('session-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('session-update');
			}
		}
	}

	public function destroy($id)
	{

		$sessionData = $this->MainModel->getSingleData('session_id', $id, 'sessions', '*');
		$sessionId = $sessionData->session_id;

		if (isset($sessionId)) {
			$result = $this->MainModel->deleteData('session_id', $sessionId, 'sessions');
			if ($result) {
				$this->session->set_flashdata('message', "Session deleted successfully !!!!");
				redirect('session-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('session-list');
		}

	}
}
