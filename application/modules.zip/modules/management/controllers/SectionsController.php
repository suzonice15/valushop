<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SectionsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');

//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Sections";
		$data['active'] = "Sections view";
		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
		$data['pageContent'] = $this->load->view('management/sections/sections_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Section registration form ";
		$data['main'] = "Section";
		$data['active'] = "Add section";
		$data['pageContent'] = $this->load->view('management/sections/sections_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['section_name'] = $this->input->post('section_name');
		$this->form_validation->set_rules('section_name', 'section name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('sections', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Section added successfully !!!!");
				redirect('section-create');
			}
		} else {

			$this->session->set_flashdata('message', "value reqiured");
			redirect('section-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{

		$data['section'] = $this->MainModel->getSingleData('section_id', $id, 'sections', '*');
		$sectionId = $data['section']->section_id;
		if (isset($sectionId)) {
			$data['title'] = "Section update page ";
			$data['main'] = "Section";
			$data['active'] = "Update section";
			$data['pageContent'] = $this->load->view('management/sections/sections_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('section-list');
		}

	}

	public function update()
	{
		$sectionId = $this->input->post('section_id');
		// check if the element exists before trying to edit it
		$sectionData = $this->MainModel->getSingleData('section_id', $sectionId, 'sections', '*');
		$sectionId = $sectionData->section_id;

		if (isset($sectionId)) {
			$data['section_name'] = $this->input->post('section_name');
			$this->form_validation->set_rules('section_name', 'section name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('section_id', $sectionId, 'sections', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Section updated successfully !!!!");
					redirect('section-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('section-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('section-list');
		}

	}

	public function destroy($id)
	{
		$sectionData = $this->MainModel->getSingleData('section_id', $id, 'sections', '*');
		$sectionId = $sectionData->section_id;
		if (isset($sectionId)) {
			$result = $this->MainModel->deleteData('section_id', $sectionId, 'sections');
			if ($result) {
				$this->session->set_flashdata('error', "Section deleted successfully !!!!");
				redirect('section-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('section-list');
		}
	}
}
