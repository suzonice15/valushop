<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SubjectsController extends MX_Controller {

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Subjects";
		$data['active'] = "Subjects view";
		$data['subjects'] = $this->MainModel->getAllData('', 'subjects', '*', 'subject_id DESC');
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['pageContent'] = $this->load->view('management/subjects/subjects_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Subject registration form ";
		$data['main'] = "Subject";
		$data['second'] = "Subject option";
		$data['active'] = "Add subject";
		$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['pageContent'] = $this->load->view('management/subjects/subjects_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['subject_name'] = $this->input->post('subject_name');
		$data['subject_code'] = $this->input->post('subject_code');
		$data['classreg_id'] = $this->input->post('classreg_id');
		$data['subject_status'] = $this->input->post('subject_status');
		$this->form_validation->set_rules('subject_name', 'Subject name', 'required');
		$this->form_validation->set_rules('subject_code', 'Subject code', 'required');
		$this->form_validation->set_rules('classreg_id', 'class  name', 'required');
		$this->form_validation->set_rules('subject_status', 'class  name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('subjects', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Subject added successfully !!!!");
				redirect('subject-create');
			}
		} else {

			$this->session->set_flashdata('message', "value reqiured");
			redirect('subject-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{
		$data['subject'] = $this->MainModel->getSingleData('subject_id', $id, 'subjects', '*');
		//var_dump($data['subject']);exit();
		$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');

		$subject_id = $data['subject']->subject_id;
		if (isset($subject_id)) {
			$data['title'] = "Subject update page ";
			$data['main'] = "Subject";
			$data['second'] = "Subject option";
			$data['active'] = "add Subject";
			$data['pageContent'] = $this->load->view('management/subjects/subjects_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
			redirect('subject-list');
		}

	}

	public function update()
	{
		$subject_id = $this->input->post('subject_id');
		// check if the element exists before trying to edit it
		$data_id['Subject'] = $this->MainModel->getSingleData('subject_id', $subject_id, 'subjects', '*');
		$subject_id = $data_id['Subject']->subject_id;

		if (isset($subject_id)) {
			$data['subject_name'] = $this->input->post('subject_name');
			$data['subject_code'] = $this->input->post('subject_code');
			$data['classreg_id'] = $this->input->post('classreg_id');
			$data['subject_status'] = $this->input->post('subject_status');
			$this->form_validation->set_rules('subject_name', 'Subject name', 'required');
			$this->form_validation->set_rules('subject_code', 'Subject code', 'required');
			$this->form_validation->set_rules('classreg_id', 'class  name', 'required');
			$this->form_validation->set_rules('subject_status', 'class  name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('subject_id', $subject_id, 'subjects', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Subject updated successfully !!!!");
					redirect('subject-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('message', "value reqiured");
				redirect('subject-update');
			}
		} else {
			$this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
			redirect('subject-list');
		}

	}
	public function classData()
	{
		$classreg_id = $this->input->post('classreg_id');
		$query = "select * from subjects join class_registrations on class_registrations.classreg_id=subjects.classreg_id where subjects.classreg_id=$classreg_id";
		$classes = $this->MainModel->AllQueryDalta($query);
		echo json_encode($classes);


	}


	public function subjectData()
	{
		$subject_id = $this->input->post('subject_id');
		$query = "select * from subjects join class_registrations on class_registrations.classreg_id=subjects.classreg_id where subjects.subject_id=$subject_id";
		$subjects = $this->MainModel->AllQueryDalta($query);
		echo json_encode($subjects);


	}
	public function destroy($id)
	{
		$data['subject'] = $this->MainModel->getSingleData('subject_id', $id, 'subjects', '*');
		$subject_id = $data['subject']->subject_id;
		if (isset($subject_id)) {
			$result = $this->MainModel->deleteData('subject_id', $id, 'subjects');
			if ($result) {
				$this->session->set_flashdata('message', "Subject deleted successfully !!!!");
				redirect('subject-list');
			}
		} else {
			$this->session->set_flashdata('message', "The element you are trying to delete does not exist.");
			redirect('subject-list');
		}
	}
}
