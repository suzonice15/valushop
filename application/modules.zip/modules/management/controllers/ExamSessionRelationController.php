<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  ExamSessionRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId = $this->session->userdata('user_id');
//		if ($userId == null) {
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Sessions report ";
		$data['active'] = "view Sessions  ";
		$query = "select exam_session_com.*,examination_name ,session_name from exam_session_com join examinations on examinations.examination_id=exam_session_com.examination_id  join sessions on sessions.session_id=
exam_session_com.session_id  order by exam_session_com.exam_session_id asc
";
		$data['examRelations'] = $this->MainModel->AllQueryDalta($query);
		//print_r($data);exit();
		$data['pageContent'] = $this->load->view('management/examSessionRelation/examSessionRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Examination and  session relation  registration form ";
		$data['main'] = "Examination <i class=\"fa fa-fw fa-exchange\"></i> Session Relation";
		$data['active'] = "Add examination and session relation";
		$data['exams'] = $this->MainModel->getAllData('', 'examinations', '*', 'examination_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
		$data['pageContent'] = $this->load->view('management/examSessionRelation/examSessionRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['examination_id'] = $this->input->post('examination_id');
		$data['session_id'] = $this->input->post('session_id');
		$data['exam_session_name'] = $this->input->post('exam_session_name');

		$this->form_validation->set_rules('session_id', 'exam  name', 'required');
		$this->form_validation->set_rules('examination_id', 'sesssion name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('exam_session_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Examination session relation added successfully !!!!");
				redirect('exam-session-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('exam-session-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{
		$data['examRelations'] = $this->MainModel->getSingleData('exam_session_id', $id, 'exam_session_com', '*');
		// print_r($data);exit();
		$examId = $data['examRelations']->exam_session_id;
		$data['exams'] = $this->MainModel->getAllData('', 'examinations', '*', 'examination_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');

		if (isset($examId)) {
			$data['title'] = "Examination and session relation update page";
			$data['main'] = "Examination <i class=\"fa fa-fw fa-exchange\"></i> session relation ";
			$data['active'] = "Update examination and session relation";
			$data['pageContent'] = $this->load->view('management/examSessionRelation/examSessionRelation_edit', $data, true);

			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('exam-session-list');
		}

	}

	public function update()
	{
		$examId = $this->input->post('exam_session_id');
		// check if the element exists before trying to edit it
		$examRelationData = $this->MainModel->getSingleData('exam_session_id', $examId, 'exam_session_com', '*');
		$examRelationDataId = $examRelationData->exam_session_id;

		if (isset($examRelationDataId)) {
			$data['examination_id'] = $this->input->post('examination_id');
			$data['session_id'] = $this->input->post('session_id');
			$data['exam_session_name'] = $this->input->post('exam_session_name');

			$this->form_validation->set_rules('session_id', 'exam  name', 'required');
			$this->form_validation->set_rules('examination_id', 'sesssion name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('exam_session_id', $examRelationDataId, 'exam_session_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Examination relation with session  updated successfully !!!!");
					redirect('exam-session-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('exam-session-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('exam-session-list');
		}

	}

	public function multipleDataStore($exam)
	{
		$query = "select * from exam_session_com right join sessions on sessions.session_id=exam_session_com.session_id
where sessions.session_id=$exam";
		$data['examSessionRelations'] = $this->MainModel->AllQueryDalta($query);
		//var_dump($data);exit();
		$data['title'] = "Examamination and session relation registration form ";
		$data['main'] = "Examination & Session relation";
		$data['active'] = "Add examination & session relation";
		//$data['class'] = $this->MainModel->getSingleData('class_reg_id', $classId, 'class_registrations', '*');

		//$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'class_reg_id DESC');
		$data['examinations'] = $this->MainModel->getAllData('', 'examinations', '*', 'examination_id DESC');
		$data['pageContent'] = $this->load->view('management/examSessionRelation/examSessionRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$sessionDataArray = array();
		$examSessionNames = array();
		$data['session_id'] = $this->input->post('session_id');
		$examinationId = $this->input->post('session_id');
		$examinationCheckId = $this->input->post('examination_id');

		if (isset($examinationCheckId)) {
			$sessionData = implode(',', $this->input->post('examination_id'));
			$examSessionData = implode(',', array_filter($this->input->post('exam_session_name')));


			$sessionDataArray = explode(',', $sessionData);
			$examSessionNames = explode(',', $examSessionData);

			$shiftId = $this->MainModel->getDataRow('session_id', $examinationId, 'exam_session_com', '*');
			if ($shiftId > 0) {
				$this->MainModel->deleteData('session_id', $examinationId, 'exam_session_com');
			}
			for ($i = 0; $i < sizeof($sessionDataArray); $i++) {
				$data['examination_id'] = $sessionDataArray[$i];
				$data['exam_session_name'] = $examSessionNames[$i];
				$data['exam_session_isActive'] = 1;
				$result = $this->MainModel->insertData('exam_session_com', $data);

			}
			if ($result) {
				$data['relationMessage'] = "Examination relation with session added successfully !!!!";
				$this->session->set_userdata($data);
				//$this->session->set_flashdata('messege', "Examination relation with session added successfully !!!!");
				redirect('session-list');
			}

		} else {
			$shiftId = $this->MainModel->getDataRow('session_id', $examinationId, 'exam_session_com', '*');
			if ($shiftId > 0) {
				$this->MainModel->deleteData('session_id', $examinationId, 'exam_session_com');
			}
			$data['relationMessage'] = "You don't add any data to database     !!!!";
			$this->session->set_userdata($data);
			//$this->session->set_flashdata('messege', "Examination relation with session added successfully !!!!");
			redirect('session-list');

		}


	}


	public function destroy($id)
	{
		$examRelationData = $this->MainModel->getSingleData('exam_session_id', $id, 'exam_session_com', ' * ');
		$examRelationDataId = $examRelationData->exam_session_id;
		if (isset($examRelationDataId)) {
			$result = $this->MainModel->deleteData('exam_session_id', $examRelationDataId, 'exam_session_com');
			if ($result) {
				$this->session->set_flashdata('message', "Examination relation with session  deleted successfully !!!!");
				redirect('exam-session-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('exam-session-list');
		}
	}

}
