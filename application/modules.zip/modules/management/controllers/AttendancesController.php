<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AttendancesController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->model('Attendance');

	}

	public function index()
	{
		$data['main'] = "Attendances";
		$data['active'] = "Attendance view";
		$query = "select attendances.*,students.student_name as student_name,tablename.section_name as section_name,tablename.classreg_name as class_name from attendances   join students on attendances.student_id=students.student_id 
join ( select classreg_section_com.* ,section_name ,classreg_name from classreg_section_com join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id 
join sections on sections.section_id=classreg_section_com.section_id)tablename on attendances.classreg_section_id=tablename.classreg_section_id
 ";
		$data['attendances'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');


		$data['pageContent'] = $this->load->view('management/attendances/attendances_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Take attendance";
		$data['main'] = "Attendances";
		$data['active'] = "Add attendance";
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/attendances/attendances_create', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleAttendaceCreate()
	{
		$data['title'] = "Take attendance";
		$data['main'] = "Attendances";
		$data['active'] = "Add attendance";


	$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/attendances/attendances_multiple_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function multipleAttendaceSave()
	{
		$data['title'] = "Take attendance";
		$data['main'] = "Attendances";
		$data['active'] = "Add attendance";
		$classreg_section_id = $this->input->post('classreg_section_id');
		$data['attendance_date'] = date('Y-m-d', strtotime($this->input->post('attendance_date')));
		$attendance_date = date('Y-m-d', strtotime($this->input->post('attendance_date')));
		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$query = "select student_classreg_section_com.*,student_name,student_roll from student_classreg_section_com join students on students.student_id=student_classreg_section_com.student_id
  where student_classreg_section_com.classreg_section_id=$classreg_section_id and student_classreg_section_com.student_classreg_section_isActive=1";
		$data['attendanceData'] = $this->MainModel->AllQueryDalta($query);
		$query = "select * from attendances where attendances.attendance_date='$attendance_date' and attendances.classreg_section_id=$classreg_section_id";
		$data['attendanceStudentResults'] = $this->MainModel->AllQueryDalta($query);
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');

//		print_r($data['attendanceStudentResults']);exit();
		if ($this->input->post('saveAttendance') == "Save Attendance") {
			$value['attendance_date'] = date('Y-m-d', strtotime($this->input->post('attendance_date')));
			$attendance_date = date('Y-m-d', strtotime($this->input->post('attendance_date')));
			$value['classreg_section_id'] = $this->input->post('classreg_section_id');
			$classreg_section_id = $this->input->post('classreg_section_id');
			$query = "select  DISTINCT attendances.classreg_section_id   from attendances where attendances.classreg_section_id=$classreg_section_id and attendances.attendance_date='$attendance_date'";
			$attendanceResult = $this->MainModel->SingleQueryData($query);
			if (!empty($attendanceResult)) {
				$this->Attendance->attendanceDataDelete($attendance_date, $classreg_section_id);
			}
			$studentqulery="select * from student_classreg_section_com where student_classreg_section_com.classreg_section_id=$classreg_section_id and student_classreg_section_com.student_classreg_section_isActive=1";
			$studentlists = $this->MainModel->AllQueryDalta($studentqulery);

			foreach ($studentlists as $student):
				$attendanceId = $this->input->post('status_' . $student->student_id);
				if ($attendanceId == 1) {
					$value['student_id'] = $student->student_id;
					$value['attendance_type'] = 1;
					$insertResult = $this->MainModel->insertData('attendances', $value);
				}


				else {
					$value['attendance_type'] = 0;
					$value['student_id'] = $student->student_id;
					$insertResult = $this->MainModel->insertData('attendances', $value);

				}

			endforeach;
			if ($insertResult):
				$this->session->set_flashdata('message', "Attendance  added successfully !!!!");
				redirect('attendance-multiple');
			endif;

		}

		$data['pageContent'] = $this->load->view('management/attendances/attendances_multiple_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{
		$studentDataArray = array();
		$data['class_id'] = $this->input->post('class_id');
		$data['section_id'] = $this->input->post('section_id');
		$studentData = implode(',', $this->input->post('student_id'));
		var_dump($studentData);
		exit();
		$studentDataArray = $explode(',', $studentData);

		$data['grade_point'] = $this->input->post('grade_point');
		$this->form_validation->set_rules('grade_name', 'grade name', 'required');
		$this->form_validation->set_rules('grade_point', 'grade point', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('grade', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Grade added successfully !!!!");
				redirect('grade-list');
			}
		} else {

			$this->session->set_flashdata('error', "All field need to be fill up ..................");
			redirect('grade-create');
		}


	}

	public function show($id)
	{

	}

	public function selectStudent()
	{
		$classregsection_id = $this->input->post('classreg_section_id');
		$classSectionData = $this->MainModel->getSingleData('classreg_section_id', $classregsection_id, 'classreg_section_com', '*');
		$class_id = $classSectionData->classreg_section_id;
		$query = "select student_classreg_section_com.*,students.student_name,students.student_id from student_classreg_section_com join students on student_classreg_section_com.student_id=students.student_id
where student_classreg_section_com.classreg_section_id=$class_id";
		$students = $this->MainModel->AllQueryDalta($query);
		$str = "";
		$str .= '<select  name="student_id" id="student_id" class="form-control">
				<option value="">--- Select student ---</option>';
		if (!empty($students)) {
			foreach ($students as $student) {
				$str .= '<option value="' . $student->student_id . '">' . $student->student_name . '</option>';
			}
		}
		$str .= '</select>';
		echo $str;

	}

	public function Attendance()
	{

		$data['attendance_date'] = date('Y-m-d', strtotime($this->input->post('attendance_date')));
		$data['attendance_type'] = $this->input->post('attendance_type');
		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['student_id'] = $this->input->post('student_id');
		$this->form_validation->set_rules('attendance_date', 'grade name', 'required');
		$this->form_validation->set_rules('attendance_type', 'grade name', 'required');
		$this->form_validation->set_rules('classreg_section_id', 'grade name', 'required');
		$this->form_validation->set_rules('student_id', 'grade name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('attendances', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Attendance added successfully !!!!");
				redirect('attendance-create');
			}
		} else {

			$this->session->set_flashdata('error', "All field need to be fill up ..................");
			redirect('attendance-create');
		}


	}

	public function studentSelectionData()
	{
		$classreg_section_id = $this->input->post('classreg_section_id');
		$query = "select student_classreg_section_com.student_id as studentId,student_name,student_father_name from student_classreg_section_com
join  students on students.student_id=student_classreg_section_com.student_id
 where student_classreg_section_com.classreg_section_id=$classreg_section_id and student_classreg_section_com.student_classreg_section_isActive=1";
		$students = $this->MainModel->AllQueryDalta($query);
		$str='<select   id="studentId" class="form-control select2"><option value="">select student </option>';
		foreach ($students as $student):
			$str .='<option value="'.$student->studentId.'">'.$student->student_name.'</option>';
		endforeach;
		$str .=	'</select>';
		echo $str;
	}

	public function edit($id)
	{


		$data['attendanceData'] = $this->MainModel->getSingleData('attendance_id', $id, 'attendances', '*');
		//print_r($data);exit();
		$attendaceId = $data['attendanceData']->attendance_id;
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');


		if ($attendaceId) {

			$data['title'] = "Attendance update page ";
			$data['main'] = "Attendance";
			$data['active'] = "Update attendance";
			$data['pageContent'] = $this->load->view('management/attendances/attendances_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('attendance-list');
		}


	}

	public function update()
	{
		$attendanceId = $this->input->post('attendance_id');
		// check if the element exists before trying to edit it
		$attendanceData = $this->MainModel->getSingleData('attendance_id', $attendanceId, 'attendances', '*');
		$attendanceId = $attendanceData->attendance_id;

		if (isset($attendanceId)) {
			$data['attendance_date'] = date('Y-m-d', strtotime($this->input->post('attendance_date')));
			$data['attendance_type'] = $this->input->post('attendance_type');
			$data['classreg_section_id'] = $this->input->post('classreg_section_id');
			$data['student_id'] = $this->input->post('student_id');
			$this->form_validation->set_rules('attendance_date', 'grade name', 'required');
			$this->form_validation->set_rules('attendance_type', 'grade name', 'required');
			$this->form_validation->set_rules('classreg_section_id', 'grade name', 'required');
			$this->form_validation->set_rules('student_id', 'grade name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('attendance_id', $attendanceId, 'attendances', $data);
				if ($result) {
					$this->session->set_flashdata('message', "attendance updated successfully !!!!");
					redirect('attendance-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "All field need to be fill up ..................");
				redirect('attendance-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('attendance-list');
		}


	}

	public  function classSectionAttendance(){

			$classreg_section_id= $this->input->post('classreg_section_id');
			$date_id= $this->input->post('date_id');
			$dateformate=date('Y-m-d',strtotime($date_id));


		$query = "SELECT attendance_date,attendance_type,classreg_name,section_name,student_name FROM attendances
join classreg_section_com on classreg_section_com.classreg_section_id=attendances.classreg_section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id
join students on students.student_id=attendances.student_id
WHERE attendance_date = '$dateformate' and attendances.classreg_section_id=$classreg_section_id";
			$data['examSesseionData'] = $this->MainModel->AllQueryDalta($query);
			$presentCount=0;
			$leaveCount=0;
			$absentCount=0;
			foreach ($data['examSesseionData'] as $attendance){
				if($attendance->attendance_type==0):
				$absentCount=$absentCount+1;
				elseif($attendance->attendance_type==2):
					$leaveCount=$leaveCount+1;
				else :
					$presentCount=$presentCount+1;
				endif;
			}

		$data['total']=$absentCount +$presentCount + $leaveCount;
		$data['absent']=$absentCount;
		$data['present']=$presentCount;
		$data['leave']=$leaveCount;
			echo json_encode($data);

	}

	public  function studentWiseAttendace(){

		$classreg_section_id= $this->input->post('classreg_section_id');
		$date2= date('Y-m-d', strtotime($this->input->post('date2')));
		$date1=date('Y-m-d', strtotime($this->input->post('date1')));
		$student_id= $this->input->post('student_id');


	$query ="SELECT attendance_date,attendance_type,classreg_name,section_name,student_name FROM attendances
join classreg_section_com on classreg_section_com.classreg_section_id=attendances.classreg_section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id join students on students.student_id=attendances.student_id WHERE attendances.attendance_date between '$date1' and  '$date2' and attendances.classreg_section_id=$classreg_section_id and attendances.student_id=$student_id";
		$data['attendaces'] = $this->MainModel->AllQueryDalta($query);

		$presentCount=0;
		$leaveCount=0;
		$absentCount=0;
		foreach ($data['attendaces'] as $attendance){
			if($attendance->attendance_type==0):
				$absentCount=$absentCount+1;
			elseif($attendance->attendance_type==2):
				$leaveCount=$leaveCount+1;
			else :
				$presentCount=$presentCount+1;
			endif;
		}

		$data['total']=$absentCount +$presentCount + $leaveCount;
		$data['absent']=$absentCount;
		$data['present']=$presentCount;
		$data['leave']=$leaveCount;

//			echo '<pre>';
//			print_r($examSesseionData);exit();
		echo json_encode($data);

	}

	public  function singleStudentAttendaceReport(){


		$data['main'] = "Student attendance";
		$data['active'] = "view attendance";

		$classreg_section_id= $this->input->post('classreg_section_id');
		$date2= date('Y-m-d', strtotime($this->input->post('date2')));
		$date1=date('Y-m-d', strtotime($this->input->post('date1')));
		$data['date1']=$date1;
		$data['date2']=$date2;

		$student_id= $this->input->post('student_id');
		$query ="SELECT attendance_date,attendance_type,classreg_name,section_name,student_name FROM attendances
join classreg_section_com on classreg_section_com.classreg_section_id=attendances.classreg_section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id join students on students.student_id=attendances.student_id WHERE attendances.attendance_date between '$date1' and  '$date2' and attendances.classreg_section_id=$classreg_section_id and attendances.student_id=$student_id";
		$data['attendaces'] = $this->MainModel->AllQueryDalta($query);
		$presentCount=0;
		$leaveCount=0;
		$absentCount=0;
		foreach ($data['attendaces'] as $attendance){
			if($attendance->attendance_type==0):
				$absentCount=$absentCount+1;
			elseif($attendance->attendance_type==2):
				$leaveCount=$leaveCount+1;
			else :
				$presentCount=$presentCount+1;
			endif;
		}

		$data['total']=$absentCount +$presentCount + $leaveCount;
		$data['absent']=$absentCount;
		$data['present']=$presentCount;
		$data['leave']=$leaveCount;
		$data['pageContent'] = $this->load->view('management/attendances/attendances_singleStudentAttendaceReport', $data, true);
		$this->load->view('layouts/main', $data);

	}
	public function studentSelectionlist()
	{
		$classreg_section_id = $this->input->post('classreg_section_id');
		$attendance_date = date('Y-m-d',strtotime($this->input->post('attendance_date')));
		$query = "
select attendances.*,students.student_id,student_name from attendances
join students on students.student_id=attendances.student_id
join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
 where attendances.classreg_section_id=$classreg_section_id and attendances.attendance_date='$attendance_date' and student_classreg_section_com.student_classreg_section_isActive=1";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		echo json_encode($data);


	}
	public  function classWiseStudentReportPrint(){

		$data['main'] = "Monthly attendance";
		$data['active'] = "view atttenace";


		$classreg_section_id= $this->input->post('classreg_section_id');
		$date_id= $this->input->post('date_id');
		$dateformate=date('Y-m-d',strtotime($date_id));


		$query = "SELECT attendance_date,attendance_type,classreg_name,section_name,student_name FROM attendances
join classreg_section_com on classreg_section_com.classreg_section_id=attendances.classreg_section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id
join students on students.student_id=attendances.student_id
WHERE attendance_date = '$dateformate' and attendances.classreg_section_id=$classreg_section_id";

		$data['examSesseionData'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');

		$presentCount=0;
		$leaveCount=0;
		$absentCount=0;
		foreach ($data['examSesseionData'] as $attendance){
			if($attendance->attendance_type==0):
				$absentCount=$absentCount+1;
			elseif($attendance->attendance_type==2):
				$leaveCount=$leaveCount+1;
			else :
				$presentCount=$presentCount+1;
			endif;
		}

		$data['total']=$absentCount +$presentCount + $leaveCount;
		$data['absent']=$absentCount;
		$data['present']=$presentCount;
		$data['leave']=$leaveCount;
		$data['attendances'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('management/attendances/attendances_classWiseStudentReportPrint', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function destroy($id)
	{
		// check if the element exists before trying to edit it
		$attendanceData = $this->MainModel->getSingleData('attendance_id', $id, 'attendances', '*');
		$attendanceId = $attendanceData->attendance_id;

		if (isset($attendanceId)) {
			$result = $this->MainModel->deleteData('attendance_id', $attendanceId, 'attendances');
			if ($result) {
				$this->session->set_flashdata('message', "Attendence deleted successfully !!!!");
				redirect('attendance-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('attendance-list');
		}
	}

public function month(){

		$data['title'] = "Montly attendance";
		$data['main'] = "Montly attendance";
		$data['active'] = "attendance";
		$classreg_section_id= $this->input->post('classreg_section_id');
		$data['ClassId']= $classreg_section_id;
		$data['session_Id']= $this->input->post('session_id');
		$data['monthId']= $this->input->post('month');
		if(isset($classreg_section_id)) {
			$studentQueryg = "select student_classreg_section_com.student_roll,student_name,student_classreg_section_com.student_roll,students.student_id from students
join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id

where student_classreg_section_com.student_classreg_section_isActive=1 and student_classreg_section_com.classreg_section_id=$classreg_section_id";
			$data['students']=$this->MainModel->AllQueryDalta($studentQueryg);

		}


		$data['classData'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
		$data['pageContent'] = $this->load->view('management/attendances/attendances_monthly', $data, true);
		$this->load->view('layouts/main', $data);



	}
	public function getAttendace($classreg_section_id,$student_id,$attendance_date){
		//$this->method_call =& get_instance();
		$query="select * from attendances where classreg_section_id=$classreg_section_id and student_id=$student_id and attendance_date='$attendance_date'";
		$result=$this->MainModel->SingleQueryData($query);
		return $result;



	}
}
