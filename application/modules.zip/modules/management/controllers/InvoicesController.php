<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InvoicesController extends MX_Controller {



	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->library('upload');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}

	}

	public function index()
	{
		$data['main'] = "Class wise student fee report";
		$data['active'] = "view student fee report";
		$query="select invoice_id,student_name,expense_category_name,invoice_issue_date,invoice_creation_time,classreg_section_name,student_father_name from invoices
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=invoices.student_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where student_classreg_section_com.student_classreg_section_isActive=1 order by invoice_id desc";
		$data['invoices'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');


		$data['pageContent'] = $this->load->view('management/Invoices/invoices_index', $data, true);
		$this->load->view('layouts/main', $data);
	}


    public function allFee()
    {
        $data['main'] = "Student fee list";
        $data['active'] = "view student fee list";
        $query="select invoice_id,student_name,expense_category_name,invoice_creation_time,classreg_section_name,invoice_amount,student_father_name from invoices
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=invoices.student_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where student_classreg_section_com.student_classreg_section_isActive=1 order by invoice_id desc";
        $data['invoices'] = $this->MainModel->AllQueryDalta($query);
        $data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');


        $data['pageContent'] = $this->load->view('management/Invoices/invoices_allFee', $data, true);
        $this->load->view('layouts/main', $data);
    }

	public function residentAll()
	{
		$data['main'] = "Resident Student fee ";
		$data['active'] = "view Resident fee ";
		$query="select   * from resident_fee join expense_category on expense_category.expense_category_id=resident_fee.expense_category_id
join classreg_section_com on classreg_section_com.classreg_section_id=resident_fee.classreg_section_id
join students on students.student_id=resident_fee.student_id order by resident_fee.resident_fee_id desc ";
		$data['invoices'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/Invoices/invoices_residentAll', $data, true);
		$this->load->view('layouts/main', $data);
	}




	public function create()
	{
		$data['title'] = "Student fee collection registration form ";
		$data['main'] = "Student fee";
		$data['active'] = "Add student fee";
		$data['classSectionRelations']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['expenseCategories']=$this->MainModel->getAllData('expense_category_status=1', 'expense_category', '*', 'expense_category_id DESC');
		$data['pageContent'] = $this->load->view('management/invoices/invoices_create', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function resident()
	{
		$data['title'] = "Student fee collection registration form ";
		$data['main'] = "Resident  fee";
		$data['active'] = "Add Resident fee";
		$data['classSectionRelations']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['expenseCategories']=$this->MainModel->getAllData('expense_category_status=2', 'expense_category', '*', 'expense_category_id DESC');
		$data['pageContent'] = $this->load->view('management/invoices/invoices_resident', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		date_default_timezone_set('Asia/Dhaka');


		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['student_id'] = $this->input->post('student_id');
		$expense_category_id = implode(',',$this->input->post('expense_category_id'));
		$expense_category_array=explode(',',$expense_category_id);
		$invoice_amount = implode(',',array_filter($this->input->post('invoice_amount')));
		$invoice_amount_array=explode(',',$invoice_amount);
        $data['invoice_issue_date'] = date('Y-m-d');
        $data['invoice_creation_time'] = date('Y-m-d',strtotime($this->input->post('invoice_creation_time')));


        for ( $i=0;$i<sizeof($expense_category_array);$i++){

            $data['expense_category_id']=$expense_category_array[$i];
            $data['invoice_amount']=$invoice_amount_array[$i];
            $data['invoice_status']=1;
            $invoiceId = $this->MainModel->returnInsertId('invoices', $data);
            if(isset($invoiceId)){
                $payment['classreg_section_id'] = $this->input->post('classreg_section_id');
                $payment['student_id'] = $this->input->post('student_id');
                $payment['expense_category_id'] = $expense_category_array[$i];
                $payment['payment_amount'] = $invoice_amount_array[$i];
                $payment['invoice_id'] = $invoiceId;
                $payment['payment_date'] =date("Y-m-d");
                $result = $this->MainModel->insertData('payment', $payment);

            }

        }


		if ($result) {
			echo "Student Fee collection successfully !!!!";
		}

	}

	public function residentSave()
	{

		date_default_timezone_set('Asia/Dhaka');


		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['student_id'] = $this->input->post('student_id');
		$expense_category_id = implode(',',$this->input->post('expense_category_id'));
		$expense_category_array=explode(',',$expense_category_id);
		$resident_fee_amount = implode(',',$this->input->post('resident_fee_amount'));
		$resident_fee_amount_array=explode(',',$resident_fee_amount);
		$data['resident_issue_date'] = date('Y-m-d');
	//	$data['resident_creation_time'] = date('Y-m-d',strtotime($this->input->post('resident_creation_time')));
		$resident_creation_time = implode(',',$this->input->post('resident_creation_time'));
		$resident_creation_time_array=explode(',',$resident_creation_time);

		for ( $i=0;$i<sizeof($expense_category_array);$i++){

			$data['expense_category_id']=$expense_category_array[$i];
			$data['resident_fee_amount']=$resident_fee_amount_array[$i];
			$data['resident_creation_time']=date('Y-m-d',strtotime($resident_creation_time_array[$i]));
			$data['resident_status']=1;
			$invoiceId = $this->MainModel->returnInsertId('resident_fee', $data);
			if(isset($invoiceId)){
				$payment['classreg_section_id'] = $this->input->post('classreg_section_id');
				$payment['student_id'] = $this->input->post('student_id');
				$payment['expense_category_id'] = $expense_category_array[$i];
				$payment['payment_amount'] = $resident_fee_amount_array[$i];
				$payment['invoice_id'] = $invoiceId;
				//$payment['payment_date'] =date("Y-m-d");
				$payment['payment_date']=date('Y-m-d',strtotime($resident_creation_time_array[$i]));
				$result = $this->MainModel->insertData('payment', $payment);
			}

		}


		if ($result) {
			echo "Resident  Student Fee collection successfully !!!!";
		}
		else {
			echo "Resident  Student Fee not  collection successfully !!!!";

		}

	}

	public function show($id)
	{

	}

	public function edit($id)
	{
		$data['Invoices'] = $this->MainModel->getSingleData('invoice_id', $id, 'invoices', '*');
		$data['classSectionRelations']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['expenseCategories']=$this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');
		$data['students']=$this->MainModel->getAllData('', 'students', '*', 'student_id DESC');

		$student_id = $data['Invoices']->invoice_id;
		if (isset($student_id)) {
			$data['title'] = "student  fee collection update page ";
			$data['main'] = "Student fee";
			$data['active'] = "update student fee";
			$data['pageContent'] = $this->load->view('management/invoices/invoices_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('Invoices-list');
		}

	}
	public function take($id)
	{
		$data['Invoices'] = $this->MainModel->getSingleData('invoice_id', $id, 'invoices', '*');
		$data['classSectionRelations']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['expenseCategories']=$this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');
		$data['students']=$this->MainModel->getAllData('', 'students', '*', 'student_id DESC');

		$student_id = $data['Invoices']->invoice_id;
		if (isset($student_id)) {
			$data['title'] = "student  fee collection update page ";
			$data['main'] = "Student fee";
			$data['active'] = "update student fee";
			$data['pageContent'] = $this->load->view('management/invoices/invoices_take', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('Invoices-list');
		}

	}

    public function addOldFee($id)
    {
        $data['classSectionRelations']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
        $data['students']=$this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
        $query="select classreg_section_com.classreg_section_name,student_id,classreg_section_com.classreg_section_id  from   student_classreg_section_com 
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
where student_classreg_section_com.student_classreg_section_isActive=1 and student_classreg_section_com.student_id=$id";
        $data['studentfee'] = $this->MainModel->QuerySingleData($query);
        $data['expenseCategories']=$this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');

//        echo '<pre>';
//        print_r( $data['studentfee']);exit();
            $data['title'] = "student  fee collection  page ";
            $data['main'] = "Student fee";
            $data['active'] = " student fee";
            $data['pageContent'] = $this->load->view('management/invoices/invoices_addOldFee', $data, true);
            $this->load->view('layouts/main', $data);


    }


	public function invoiceMake($id)
	{
		$query="select * from invoices 
join students on students.student_id=invoices.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where invoices.invoice_id=$id";
		$data['Invoices'] = $this->MainModel->QuerySingleData($query);
//		echo '<pre>';
//		print_r($data);exit();
		$paymentQuery="select * from payment where payment.invoice_id=$id";
		$data['payments'] = $this->MainModel->AllQueryDalta($paymentQuery);
		$data['schools'] = $this->MainModel->getSingleData('satinge_id', 1, 'satinge', '*');

		$data['main'] = "Student fee invoice";
			$data['active'] = "create invoice";
			$data['pageContent'] = $this->load->view('management/invoices/invoices_make', $data, true);
			$this->load->view('layouts/main', $data);


	}

	public function update()
	{

		date_default_timezone_set('Asia/Dhaka');

		$invoice_id = $this->input->post('invoice_id');
		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['student_id'] = $this->input->post('student_id');
		$data['expense_category_id'] = $this->input->post('expense_category_id');
		$data['expense_category_id'] = $this->input->post('expense_category_id');
		$data['expense_category_id'] = $this->input->post('expense_category_id');

//		
		$data['invoice_creation_time'] =date("Y-m-d h:i:sa");
		$result = $this->MainModel->updateData('invoice_id', $invoice_id, 'invoices', $data);


		if ($result) {
			$this->session->set_flashdata('message', "Fee collection update successfully !!!!");
			redirect('invoice-list');
		}



	}

	public function takeUpdate()
	{

		date_default_timezone_set('Asia/Dhaka');
        $invoice_amount = $this->input->post('invoice_amount');
        $invoice_amount_paid = $this->input->post('invoice_amount_paid');

		$invoice_id = $this->input->post('invoice_id');
		$amount_paid = $this->input->post('amount_paid');
		$totalPaidMoney =$amount_paid + $invoice_amount_paid;
        if($invoice_amount ==$totalPaidMoney){
            $data['invoice_status'] = 1;

        }
        elseif ($invoice_amount > $totalPaidMoney){

            $data['invoice_status'] = 2;
        }
        else {
            $data['invoice_status'] = 0;
        }
		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['student_id'] = $this->input->post('student_id');
		$data['expense_category_id'] = $this->input->post('expense_category_id');
		$data['invoice_amount'] = $this->input->post('invoice_amount');
		$data['invoice_amount_paid'] = $amount_paid+$this->input->post('invoice_amount_paid');
		$data['invoice_due '] = $this->input->post('invoice_due');
		$data['invoice_creation_time'] =date("Y-m-d h:i:sa");
		$result = $this->MainModel->updateData('invoice_id', $invoice_id, 'invoices', $data);

//		$invoiceId=$this->MainModel->updateDataReturnInsertId('invoice_id', $invoice_id, 'invoices', $data);
//		echo $invoiceId;exit();
		if(isset($result)){
			$payment['classreg_section_id'] = $this->input->post('classreg_section_id');
			$payment['student_id'] = $this->input->post('student_id');
			$payment['expense_category_id'] = $this->input->post('expense_category_id');
			$payment['payment_amount'] = $this->input->post('invoice_amount_paid');
			$payment['invoice_id'] = $invoice_id;
			$payment['payment_date'] =date("Y-m-d h:i:sa");
			$result = $this->MainModel->insertData('payment', $payment);

		}

		if ($result) {
			$this->session->set_flashdata('message', "Fee collection update successfully !!!!");
			redirect('invoice-list');
		}



	}


	public function destroy($id)
	{
		$Student = $this->MainModel->getSingleData('student_id', $id, 'students', '*');
		$student_id = $Student->student_id;
		if (isset($student_id)) {
			$result = $this->MainModel->deleteData('student_id', $id, 'students');
			if ($result) {
				$this->session->set_flashdata('message', "Invoices deleted successfully !!!!");
				redirect('Invoices-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('Invoices-list');
		}
	}


	public function studentData()
	{

        date_default_timezone_set('Asia/Dhaka');
        $year=date('Y');
     $month =$this->input->post('invoice_creation_time');
        $invoice_creation_time ="$year-$month";
	$classreg_section_id   = $this->input->post('classreg_section_id');
		$query = "select * from invoices 
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
where student_classreg_section_com.student_classreg_section_isActive=1 and invoices.invoice_creation_time like '$invoice_creation_time%' and invoices.classreg_section_id=$classreg_section_id
 ";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		echo json_encode($data);
	}

	public function classWiseFeeList()
	{

		date_default_timezone_set('Asia/Dhaka');
		$year=date('Y');
		$month =$this->input->post('invoice_creation_time');
		$invoice_creation_time ="$year-$month";
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$query = "select * from invoices 
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=student_classreg_section_com.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
where student_classreg_section_com.student_classreg_section_isActive=1 and invoices.invoice_creation_time like '$invoice_creation_time%' and invoices.classreg_section_id=$classreg_section_id";
		$data['students'] = $this->MainModel->AllQueryDalta($query);

		$data['main'] = "class wise fee print";
		$data['active'] = "fee print ";
		$data['pageContent'] = $this->load->view('management/invoices/invoices_classWiseFeePrint', $data, true);
		$this->load->view('layouts/main', $data);

	}


	public function singleStudentWiseData()
	{
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$student_id   = $this->input->post('student_id');
		$query = "select  invoices.*,classreg_section_name,expense_category_name ,student_name,student_father_name from invoices
join  expense_category on expense_category.expense_category_id=invoices.expense_category_id
 join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
 join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join students on students.student_id=student_classreg_section_com.student_id
where student_classreg_section_com.classreg_section_id=$classreg_section_id and 
student_classreg_section_com.student_classreg_section_isActive=1 and invoices.invoice_creation_time between '$dateId1' and '$dateId2' and invoices.student_id=$student_id
";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		echo json_encode($data);
	}

	public function studentWiseFeePrint()
	{
		$dateId1 = date('Y-m-d',strtotime($this->input->post('attendance_date1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('attendance_date2')));
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$student_id   = $this->input->post('student_id');
		$data['firstDate']   = $dateId1;
		$data['lastDate']   = $dateId2;
		$query = "select  invoices.*,classreg_section_name,expense_category_name ,student_name,student_father_name from invoices
join  expense_category on expense_category.expense_category_id=invoices.expense_category_id
 join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
 join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join students on students.student_id=student_classreg_section_com.student_id
where student_classreg_section_com.classreg_section_id=$classreg_section_id and 
student_classreg_section_com.student_classreg_section_isActive=1 and invoices.invoice_creation_time between '$dateId1' and '$dateId2' and invoices.student_id=$student_id
";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
//		echo '<pre>';
//		print_r($data);exit();
		$data['main'] = "Single student wise fee print";
		$data['active'] = "fee print ";
		$data['pageContent'] = $this->load->view('management/invoices/invoices_studentWiseFeePrint', $data, true);
		$this->load->view('layouts/main', $data);	}


	public function studentInvoice()
	{
		$data['main'] = "Student fee report";
		$data['active'] = "view fee report";
		$query="select invoice_id,student_name,expense_category_name,invoice_creation_time,classreg_section_name,invoice_amount,student_father_name from invoices
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=invoices.student_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where student_classreg_section_com.student_classreg_section_isActive=1 order by invoice_id desc";
		$data['invoices'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/Invoices/invoices_student_invoice', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function studentSelectionData()
	{
		$classreg_section_id = $this->input->post('classreg_section_id');
		$query = "select student_classreg_section_com.student_id as studentId,student_name,student_father_name from student_classreg_section_com
join  students on students.student_id=student_classreg_section_com.student_id
 where student_classreg_section_com.classreg_section_id=$classreg_section_id and student_classreg_section_com.student_classreg_section_isActive=1";
		$students = $this->MainModel->AllQueryDalta($query);
		$str='<select   id="studentId" class="form-control select2"><option value="">select student </option>';
		foreach ($students as $student):
			$str .='<option value="'.$student->studentId.'">'.$student->student_name.'</option>';
		endforeach;
		$str .=	'</select>';
		echo $str;
	}


	public function invoiceSelectionData()
	{
		$query = "SELECT * FROM invoices ORDER BY invoice_id DESC LIMIT 1 ";
		$invoiceId = $this->MainModel->QuerySingleData($query);
		if(empty($invoiceId)){
			$invoiceId =1;

		}
		else {
			$invoiceId = $invoiceId->invoice_id + 1;
		}

		echo  $invoiceId;
	}


	public function residentSelectionData()
	{
		$query = "SELECT * FROM resident_fee ORDER BY resident_fee_id DESC LIMIT 1 ";
		$invoiceId = $this->MainModel->QuerySingleData($query);
		if(empty($invoiceId)){
			$invoiceId =1;

		}
		else {
			$invoiceId = $invoiceId->resident_fee_id + 1;
		}

		echo  $invoiceId;
	}
public  function  residentStudent(){
	$data['main'] = "Resident  Student fee report";
	$data['active'] = "view Resident report";
	$query="select invoice_id,student_name,expense_category_name,invoice_creation_time,classreg_section_name,invoice_amount,student_father_name from invoices
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=invoices.student_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where student_classreg_section_com.student_classreg_section_isActive=1 order by invoice_id desc";
	$data['invoices'] = $this->MainModel->AllQueryDalta($query);
	$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
	$data['pageContent'] = $this->load->view('management/Invoices/invoices_residentStudent', $data, true);
	$this->load->view('layouts/main', $data);

}
public  function singleStudentWiseResidentData(){

	$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
	$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
	$classreg_section_id   = $this->input->post('classreg_section_id');
	$student_id   = $this->input->post('student_id');
	$query = "select *  from resident_fee
join expense_category on expense_category.expense_category_id=expense_category.expense_category_id 
join student_classreg_section_com on student_classreg_section_com.student_id=resident_fee.student_id
join students on students.student_id=student_classreg_section_com.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=resident_fee.classreg_section_id
where student_classreg_section_com.student_classreg_section_isActive=1 and resident_fee.resident_creation_time between '$dateId1' and '$dateId2'
and resident_fee.classreg_section_id=$classreg_section_id and expense_category.expense_category_status=2 and resident_fee.student_id=$student_id
";
	$data['students'] = $this->MainModel->AllQueryDalta($query);
	echo json_encode($data);
}

	public function residentClass()
	{
		$data['main'] = "Class wise Resident student fee report";
		$data['active'] = "view student fee report";
		$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/Invoices/invoices_residentClass', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public  function  residentClassData(){

		date_default_timezone_set('Asia/Dhaka');
		$year=date('Y');
		$month =$this->input->post('invoice_creation_time');
		$invoice_creation_time ="$year-$month";
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$query = "select *  from resident_fee
join expense_category on expense_category.expense_category_id=expense_category.expense_category_id 
join student_classreg_section_com on student_classreg_section_com.student_id=resident_fee.student_id
join students on students.student_id=student_classreg_section_com.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=resident_fee.classreg_section_id
where student_classreg_section_com.student_classreg_section_isActive=1 and resident_fee.resident_creation_time like '$invoice_creation_time%'
and resident_fee.classreg_section_id=$classreg_section_id and expense_category.expense_category_status=2
 ";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		echo json_encode($data);
	}




}
