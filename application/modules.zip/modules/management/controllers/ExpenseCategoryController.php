<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExpenseCategoryController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Category";
		$data['active'] = "View Category";
		$data['expenses'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');
		$data['pageContent'] = $this->load->view('management/expensesCategory/expenses_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Category registration form ";
		$data['main'] = "Category";
		$data['active'] = "Add Category";
		$data['pageContent'] = $this->load->view('management/expensesCategory/expenses_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['expense_category_name'] = $this->input->post('expense_category_name');
		$data['expense_category_status'] = $this->input->post('expense_category_status');
		$this->form_validation->set_rules('expense_category_name', 'Expenses name', 'required');
		$this->form_validation->set_rules('expense_category_status', 'Expenses name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('expense_category', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Category added successfully !!!!");
				redirect('expense-create');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('expense-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['expense'] = $this->MainModel->getSingleData('expense_category_id', $id, 'expense_category', '*');
		$expenseCategory = $data['expense']->expense_category_id;

		if ($expenseCategory) {

			$data['title'] = "Income And Expense update page ";
			$data['main'] = "Income And Expense category";
			$data['active'] = "Update Expenses";
			$data['pageContent'] = $this->load->view('management/expensesCategory/expenses_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('expense-list');
		}


	}

	public function update()
	{
		$expenseCategory = $this->input->post('expense_category_id');
		// check if the element exists before trying to edit it
		$shiftData = $this->MainModel->getSingleData('expense_category_id', $expenseCategory, 'expense_category', '*');
		$expenseCategory = $shiftData->expense_category_id;

		if (isset($expenseCategory)) {
            $data['expense_category_name'] = $this->input->post('expense_category_name');
            $data['expense_category_status'] = $this->input->post('expense_category_status');
            $this->form_validation->set_rules('expense_category_name', 'Expenses name', 'required');
            $this->form_validation->set_rules('expense_category_status', 'Expenses name', 'required');
            if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('expense_category_id', $expenseCategory, 'expense_category', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Expenses updated successfully !!!!");
					redirect('expense-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('expense-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('expense-list');
		}


	}


	public function destroy($id)
	{
		$expenseData = $this->MainModel->getSingleData('expense_category_id', $id, 'expense_category', '*');
		$expenseCategory = $expenseData->expense_category_id;

		if (isset($expenseCategory)) {
			$result = $this->MainModel->deleteData('expense_category_id', $expenseCategory, 'expense_category');
			if ($result) {


				$this->session->set_flashdata('message', "Expenses deleted successfully !!!!");
				redirect('expense-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('expense-list');
		}
	}


}
