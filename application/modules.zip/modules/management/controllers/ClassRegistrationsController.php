<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClassRegistrationsController extends MX_Controller {

	public function __construct(){
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
////		if($userId ==null){
////			redirect('admin');
////
////		}
	}

	public function index(){
		$data['main']="Classes";
		$data['active']="Classes view";
		$data['classResults']=$this->MainModel->getAllData('','class_registrations','*','classreg_id DESC');
		$data['pageContent']=$this->load->view('management/classRegistrations/classRegistrations_index',$data,true);
		$this->load->view('layouts/main',$data);
	}

	public function create(){
		$data['title']="Class registration form ";
		$data['main']="Class";
		$data['active']="Add class";
		$data['pageContent']=$this->load->view('management/classRegistrations/classRegistrations_create',$data,true);
		$this->load->view('layouts/main',$data);
	}


	public function store(){

		$data['classreg_name']=$this->input->post('classreg_name');
		$this->form_validation->set_rules('classreg_name', 'class name', 'required');
		if ($this->form_validation->run())
		{
			$result=$this->MainModel->insertData('class_registrations',$data);
			if($result){
				$this->session->set_flashdata('message', "Shift added successfully !!!!");
				redirect('class-list');
			}
		}
		else
		{
			$this->session->set_flashdata('error', "All field need to be fill up  !!!!");
				redirect('class-create');
		}
		
		}

	public function show($id){

	}

	public function edit($id){
		
		 
        $data['class'] = $this->MainModel->getSingleData('classreg_id', $id, 'class_registrations', '*');
		$class_reg_id=$data['class']->classreg_id;
        if (isset($class_reg_id)) {
            $data['title'] = "Class update page ";
            $data['main'] = "Class";
            $data['active'] = "Update class";
            $data['pageContent'] = $this->load->view('management/classRegistrations/classRegistrations_edit',$data,true);
            $this->load->view('layouts/main', $data);
        } else {
			 $this->session->set_flashdata('message', "The element you are trying to edit does not exist.");  
			 redirect('class-list');		 
		}
	}

	public function update(){
		
		
		 $classreg_id = $this->input->post('classreg_id');
        // check if the element exists before trying to edit it
        $data_id['class'] = $this->MainModel->getSingleData('classreg_id', $classreg_id, 'class_registrations', '*');
		$classreg_id=$data_id['class']->classreg_id;
		
			if(isset($classreg_id)) {
					$data['classreg_name'] = $this->input->post('classreg_name');
					$this->form_validation->set_rules('classreg_name', 'class name', 'required');
            if ($this->form_validation->run()) {
                $result = $this->MainModel->updateData('classreg_id',$classreg_id ,'class_registrations',$data);
                if ($result) {                  
					$this->session->set_flashdata('message', "class updated successfully !!!!");
                    redirect('class-list');
                }
            }
			else{
			//$data['message'] = "value reqiured";
                  //  $this->session->set_userdata($data);
					$this->session->set_flashdata('message', "value reqiured");
                    redirect('class-update');
		}
	}
	}

	public function destroy($id){
		
		$data['class'] = $this->MainModel->getSingleData('classreg_id', $id, 'class_registrations', '*');
		$class_reg_id=$data['class']->classreg_id;

        if (isset($class_reg_id)) {
        $result = $this->MainModel->deleteData('classreg_id',$id, 'class_registrations');
        if ($result) {          
			$this->session->set_flashdata('message', "class deleted successfully !!!!");
            redirect('class-list');
        }}
			else {
           $this->session->set_flashdata('message', "The element you are trying to delete does not exist.");
			  redirect('class-list');
			}
		
	}

}
