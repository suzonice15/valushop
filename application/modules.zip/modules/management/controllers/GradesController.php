<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GradesController extends MX_Controller {

	public function __construct()
	{
		$this->load->model('MainModel');
		$userId=$this->session->userdata('user_id');
		if($userId ==null){
			redirect('admin');

		}
	}

	public function index()
	{
		$data['main'] = "Grade";
		$data['active'] = "Grade view";
		$data['grades'] = $this->MainModel->getAllData('', 'grade', '*', 'grade_id DESC');

		$data['pageContent'] = $this->load->view('management/Grades/grades_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Grade registration form ";
		$data['main'] = "Grade";
		$data['active'] = "Add grade";
		$data['pageContent'] = $this->load->view('management/Grades/grades_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['grade_name'] = $this->input->post('grade_name');
		$data['grade_point'] = $this->input->post('grade_point');
		$this->form_validation->set_rules('grade_name', 'grade name', 'required');
		$this->form_validation->set_rules('grade_point', 'grade point', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('grade', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Grade added successfully !!!!");
				redirect('grade-list');
			}
		} else {

			$this->session->set_flashdata('error', "All field need to be fill up ..................");
			redirect('grade-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['gradeData'] = $this->MainModel->getSingleData('grade_id', $id, 'grade', '*');
		$gradeId = $data['gradeData']->grade_id;

		if ($gradeId) {

			$data['title'] = "Grade update page ";
			$data['main'] = "Grade";
			$data['active'] = "Update grade";
			$data['pageContent'] = $this->load->view('management/Grades/grades_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('grade-list');
		}


	}

	public function update()
	{
		$gradeId = $this->input->post('grade_id');
		// check if the element exists before trying to edit it
		$gradeData = $this->MainModel->getSingleData('grade_id', $gradeId, 'grade', '*');
		$gradeId = $gradeData->grade_id;

		if (isset($gradeId)) {
			$data['grade_name'] = $this->input->post('grade_name');
			$data['grade_point'] = $this->input->post('grade_point');
			$this->form_validation->set_rules('grade_name', 'grade name', 'required');
			$this->form_validation->set_rules('grade_point', 'grade point', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('grade_id', $gradeId, 'grade', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Grade updated successfully !!!!");
					redirect('grade-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "All field need to be fill up ..................");
				redirect('grade-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('grade-list');
		}


	}

	public function destroy($id)
	{
		$gradeData = $this->MainModel->getSingleData('grade_id', $id, 'grade', '*');
		$gradeId = $gradeData->grade_id;

		if (isset($gradeId)) {
			$result = $this->MainModel->deleteData('grade_id', $gradeId, 'grade');
			if ($result) {


				$this->session->set_flashdata('message', "Grade deleted successfully !!!!");
				redirect('grade-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('grade-list');
		}
	}
}
