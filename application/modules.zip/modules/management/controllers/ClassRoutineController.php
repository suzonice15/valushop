<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClassRoutineController extends MX_Controller {

	public function __construct(){
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index(){
		
		$data['main']="Class routine";
		$data['active']="class routine view";
		$data['classSections']=$this->MainModel->getAllData('','classreg_section_com','*','classreg_section_id DESC');
	//	$data['classRoutinelists']=$this->MainModel->getAllData('','class_routine','*','class_routine_id DESC');
		$data['pageContent']=$this->load->view('management/classRoutine/classRoutine_index',$data,true);
		$this->load->view('layouts/main',$data);
	}

	public function create(){
		$data['title']="Class routine registration form ";
		$data['main']="Class routine";
		$data['active']="add class routine";
		$data['classSections']=$this->MainModel->getAllData('','classreg_section_com','*','classreg_section_id DESC');
		$data['teachers']=$this->MainModel->getAllData('','teachers','*','teacher_id DESC');
		$data['classRooms']=$this->MainModel->getAllData('','class_room','*','class_room_id DESC');

		$data['pageContent']=$this->load->view('management/classRoutine/classRoutine_create',$data,true);
		$this->load->view('layouts/main',$data);
	}


	public function store(){

		$data['classreg_section_id']=$this->input->post('classreg_section_id');
		$data['subject_id']=$this->input->post('subject_id');
		$data['teacher_id']=$this->input->post('teacher_id');
		$data['class_room_id']=$this->input->post('class_room_id');
		$data['class_routine_day']=$this->input->post('class_routine_day');
		$data['class_routine_starting']=date('H:nn',strtotime($this->input->post('class_routine_starting')));
		$data['class_routine_ending']=date('H:nn',strtotime($this->input->post('class_routine_ending')));
//		echo '<pre>';
//		print_r($data);exit();
		$this->form_validation->set_rules('subject_id', 'shift name', 'required');
		if ($this->form_validation->run() )
		{
			$result = $this->MainModel->insertData('class_routine', $data);

			if($result){

				$this->session->set_flashdata('message', "add class routine successfully !!!!");
				redirect('class-routine-create');
			}
		}
		else
		{
			$this->session->set_flashdata('message', "value reqiured");
			redirect('class-routine-create');
		}


	}

	public function show()
	{

		$data['main'] = "Class routine";
		$data['active'] = "class routine view";
		$classreg_section_id = $this->input->post('classreg_section_id');
		$data['classreg_section'] = $this->input->post('classreg_section_id');
		if (isset($classreg_section_id)) {
			$query = "select class_routine_id,class_routine.class_routine_day,class_routine_ending,class_routine_starting,teacher_full_name,subject_name,subject_code,class_room_name from class_routine 
join subjects on subjects.subject_id=class_routine.subject_id
join teachers on teachers.teacher_id=class_routine.teacher_id
join class_room on class_room.class_room_id=class_routine.class_room_id
where class_routine.classreg_section_id=$classreg_section_id";

			$data['classRoutinelists'] = $this->MainModel->AllQueryDalta($query);
		}

		$data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/classRoutine/classRoutine_show', $data, true);
		$this->load->view('layouts/main', $data);
	}



	public function edit($id){
		$content['title']="Class routine update page ";
		$data['main']="Class routine";
		$data['second']="shift option";
		$data['active']="add shift";
		$data['classSections']=$this->MainModel->getAllData('','classreg_section_com','*','classreg_section_id DESC');
		$data['teachers']=$this->MainModel->getAllData('','teachers','*','teacher_id DESC');
		$data['classRooms']=$this->MainModel->getAllData('','class_room','*','class_room_id DESC');
		$data['subjects']=$this->MainModel->getAllData('','subjects','*','subject_id DESC');
		$data['classRoutineData']=$this->MainModel->getSingleData('class_routine_id',$id,'class_routine','*');
		$data['pageContent']=$this->load->view('management/classRoutine/classRoutine_edit',$data,true);
		$this->load->view('layouts/main',$data);
	}

	public function update(){

		$data['classreg_section_id']=$this->input->post('classreg_section_id');
		$classRoutineId=$this->input->post('class_routine_id');
		$data['subject_id']=$this->input->post('subject_id');
		$data['teacher_id']=$this->input->post('teacher_id');
		$data['class_room_id']=$this->input->post('class_room_id');
		$data['class_routine_day']=$this->input->post('class_routine_day');
		$data['class_routine_starting']=date('H:nn',strtotime($this->input->post('class_routine_starting')));
		$data['class_routine_ending']=date('H:nn',strtotime($this->input->post('class_routine_ending')));
//		echo '<pre>';
//		print_r($data);exit();
		$this->form_validation->set_rules('subject_id', 'shift name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->updateData('class_routine_id', $classRoutineId, 'class_routine', $data);
			if ($result) {
				$this->session->set_flashdata('message', "class routine updated successfully !!!!");
				redirect('class-routine-view');
			}
		} else {
			//$data['message'] = "value reqiured";
			//  $this->session->set_userdata($data);
			$this->session->set_flashdata('message', "value reqiured");
			redirect('class-routine-update');
		}



	}

	public function destroy($id)
	{
		$data['classRoutine'] = $this->MainModel->getSingleData('class_routine_id', $id, 'class_routine', '*');
		$classRoutineId = $data['classRoutine']->class_routine_id;
		if (isset($classRoutineId)) {
			$result = $this->MainModel->deleteData('class_routine_id', $id, 'class_routine');
			if ($result) {
				$this->session->set_flashdata('message', "Class routine deleted successfully !!!!");
				redirect('class-routine-view');
			}
		} else {
			$this->session->set_flashdata('message', "The element you are trying to delete does not exist.");
			redirect('class-routine-view');
		}
	}

	function  subjectSelection(){
		$classreg_section_id=$this->input->post('classreg_section_id');
		$query="select subjects.*  from subjects join classreg_section_com on classreg_section_com.classreg_id=subjects.classreg_id where classreg_section_com.classreg_section_id=$classreg_section_id";
		$subjects = $this->MainModel->AllQueryDalta($query);

		$str="<select name='subject_id' class='form-control'><option>--- select subject---</option>";
		foreach($subjects as $subject):

			$str .='<option value="'.$subject->subject_id.'">'.$subject->subject_name .'-'.$subject->subject_code.'</option>';
			endforeach;
			$str .='</select>';
		echo $str;

	}
}
