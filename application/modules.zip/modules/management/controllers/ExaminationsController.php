<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExaminationsController extends MX_Controller {

	 public function __construct()
    {
        $this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
    }

    public function index()
    {
        $data['main'] = "Examinations";
        $data['active'] = "Examination view";
        $data['examinations'] = $this->MainModel->getAllData('', 'examinations', '*', 'examination_id DESC');
        $data['pageContent'] = $this->load->view('management/examinations/examinations_index',$data,true);
        $this->load->view('layouts/main', $data);
    }

    public function create()
    {
        $data['title'] = "Examination registration form";
        $data['main'] = "Examination";
        $data['active'] = "Add examination";
        $data['pageContent'] = $this->load->view('management/examinations/examinations_create',$data,true);
        $this->load->view('layouts/main', $data);
    }


    public function store()
    {

        $data['examination_name'] = $this->input->post('examination_name');
        $this->form_validation->set_rules('examination_name', 'examination name', 'required');
        if ($this->form_validation->run()) {
            $result = $this->MainModel->insertData( 'examinations',$data);
            if ($result) {
               	$this->session->set_flashdata('message', "Examination added successfully !!!!");
                redirect('examination-create');
            }
        }
		else{
			
                    $this->session->set_flashdata('message', "value reqiured");
					redirect('examination-create');
		}


    }

    public function show($id)
    {

    }

    public function edit($id)
    {

        $data['examination'] = $this->MainModel->getSingleData('examination_id', $id, 'examinations', '*');
		$examination_id=$data['examination']->examination_id;
		//var_dump($examination_id);exit();
		//isset($data['examination']['examination_id'])
        if (isset($examination_id)) {

            $data['title'] = "Examination update page ";
            $data['main'] = "Examination";
            $data['active'] = "Update examination";
            $data['pageContent'] = $this->load->view('management/examinations/examinations_edit',$data,true);
            $this->load->view('layouts/main', $data);
        } else {
			 $this->session->set_flashdata('message', "The element you are trying to edit does not exist.");  
			 redirect('examination-list');
		}


    }

    public function update()
    {
        $examination_id = $this->input->post('examination_id');
        // check if the element exists before trying to edit it
        $examinationId = $this->MainModel->getSingleData('examination_id', $examination_id, 'examinations', '*');
		$examinationId=$examinationId->examination_id;
		
        if (isset($examinationId)) {
            $data['examination_name'] = $this->input->post('examination_name');
            $this->form_validation->set_rules('examination_name', 'examination name', 'required');
            if ($this->form_validation->run()) {
                $result = $this->MainModel->updateData('examination_id',$examinationId ,'examinations',$data);
                if ($result) {                  
					$this->session->set_flashdata('message', "Examination updated successfully !!!!");
                    redirect('examination-list');
                }
            }
			else{
			//$data['message'] = "value reqiured";
                  //  $this->session->set_userdata($data);
					$this->session->set_flashdata('error', "value reqiured");
                    redirect('examination-update');
		}
        } else {
          $this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
		  redirect('examination-list');
		}


    }

    public function destroy($id)
    {
		$examinationId= $this->MainModel->getSingleData('examination_id', $id, 'examinations', '*');
		$examinationId=$examinationId->examination_id;

        if (isset($examinationId)) {
        $result = $this->MainModel->deleteData('examination_id',$examinationId, 'examinations');
        if ($result) {
			$this->session->set_flashdata('message', "Examination deleted successfully !!!!");
            redirect('examination-list');
        }
        }
        else {
           $this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			  redirect('examination-list');
    }
}

}
