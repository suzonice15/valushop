<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExpenseController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}

	}

	public function incomeExpenseReportForm()
	{

		$data['main'] = "Profit/Loss";
		$data['active'] = "view profit and loss";
		$data['expenses'] = $this->MainModel->getAllData('', 'expense', '*', 'expense_id DESC');
		$query="select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
order by expense.expense_id desc";
		$data['expenses'] = $this->MainModel->AllQueryDalta($query);

		$data['pageContent'] = $this->load->view('management/expenses/expenses_income_report', $data, true);
		$this->load->view('layouts/main', $data);
	}



	public function index()
	{

		$data['main'] = "Expenses";
		$data['active'] = "Expenses view";
		$data['expenseCat'] = $this->MainModel->getAllData('expense_category_status=3', 'expense_category', '*', 'expense_category_id DESC');
		$query="select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
order by expense.expense_id desc";
		$data['expenses'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('management/expenses/expenses_index', $data, true);
		$this->load->view('layouts/main', $data);
	}


    public function allEexpense()
    {

        $data['main'] = "Expenses ";
        $data['active'] = " View expenses ";
        $data['expenseCat'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');
        $query="select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
order by expense.expense_id desc";
        $data['expenses'] = $this->MainModel->AllQueryDalta($query);
        $data['pageContent'] = $this->load->view('management/expenses/expenses_all_list', $data, true);
        $this->load->view('layouts/main', $data);
    }


	public function create()
	{
		$data['title'] = "Expenses registration form ";
		$data['main'] = "Expenses";
		$data['active'] = "Add Expenses";
		$data['expenseCategories'] = $this->MainModel->getAllData('expense_category_status=3', 'expense_category', '*', 'expense_category_id DESC');
		$data['pageContent'] = $this->load->view('management/expenses/expenses_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{
		date_default_timezone_set('Asia/Dhaka');
		$expense_category_id = implode(',',$this->input->post('expense_category_id'));
		$expense_category_array=explode(',',$expense_category_id);
		$income_amount = implode(',',$this->input->post('invoice_amount'));
		$income_amount_array=explode(',',$income_amount);
		$data['expense_date'] = date('Y-m-d');
		for ( $i=0;$i<sizeof($expense_category_array);$i++){
			$data['expense_category_id']=$expense_category_array[$i];
			$data['expense_amount']=$income_amount_array[$i];
			$result = $this->MainModel->returnInsertId('expense', $data);
		}
		if ($result) {
			echo "Expense added  successfully !!!!";
		}
		else {
			echo "Expense  does not added successfully !!!!";
		}
	}

	public function show($id)
	{

	}

	public function edit($id)
	{
		$data['expensesCatogry'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');


		$data['expense'] = $this->MainModel->getSingleData('expense_id', $id, 'expense', '*');
		$expenseId= $data['expense']->expense_id;

		if ($expenseId) {

			$data['title'] = "Expenses update page ";
			$data['main'] = "Expenses";
			$data['active'] = "Update Expenses";
			$data['pageContent'] = $this->load->view('management/expenses/expenses_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('expenses-list');
		}


	}

	public function update()
	{
		$expenseId = $this->input->post('expense_id');
		// check if the element exists before trying to edit it
		$expenseData = $this->MainModel->getSingleData('expense_id', $expenseId, 'expense', '*');
		$expenseDataId = $expenseData->expense_id;

		if (isset($expenseDataId)) {
			$data['expense_amount'] = $this->input->post('expense_amount');
			$data['expense_category_id'] = $this->input->post('expense_category_id');
			$data['expense_date'] = date('Y-m-d',strtotime($this->input->post('expense_date')));
			$data['expense_note'] = $this->input->post('expense_note');
			$this->form_validation->set_rules('expense_amount', 'Expenses name', 'required');
			$this->form_validation->set_rules('expense_category_id', 'Expenses name', 'required');
			$this->form_validation->set_rules('expense_date', 'Expenses name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('expense_id', $expenseDataId, 'expense', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Expenses updated successfully !!!!");
					redirect('expenses-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('expenses-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('expenses-list');
		}


	}

	public function expenseReport()
	{
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		$expense_category_id  = $this->input->post('expense_category_id');
		if($expense_category_id==1){
            $query="select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
where   expense.expense_date between '$dateId1' and '$dateId2'";

        }
		else {
            $query = "select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
where expense_category.expense_category_id=$expense_category_id and  expense.expense_date between '$dateId1' and '$dateId2'";

        }

        $total=0;
		$data['expenses'] = $this->MainModel->AllQueryDalta($query);
		foreach ( $data['expenses'] as $expens){
		    $total=$total+$expens->expense_amount;
        }
		$data['totalAmount']=$total;
		echo json_encode($data);

	}

	public function expensesReportRrint()
	{
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		$data['lastDate'] = $dateId2;
		$data['firstDate'] = $dateId1;
		$expense_category_id  = $this->input->post('expense_category_id');
		if($expense_category_id==1){
			$query="select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
where   expense.expense_date between '$dateId1' and '$dateId2'";
			$data['allCagegory']="All category";

		}
		else {
			$query = "select * from expense
join expense_category on expense_category.expense_category_id=expense.expense_category_id
where expense_category.expense_category_id=$expense_category_id and  expense.expense_date between '$dateId1' and '$dateId2'";

		}

		$total=0;
		$data['expenses'] = $this->MainModel->AllQueryDalta($query);
		foreach ( $data['expenses'] as $expens){
			$total=$total+$expens->expense_amount;
		}
		$data['totalAmount']=$total;
//		echo '<pre>';
//		print_r($data);exit();
		$data['main'] = "Expenses report print";
		$data['active'] = "View expenses report page";
		$data['pageContent'] = $this->load->view('management/expenses/expenses_report_print', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function destroy($id)
	{
		$expenseData = $this->MainModel->getSingleData('expense_id', $id, 'expense', '*');
		$expenseId = $expenseData->expense_id;

		if (isset($expenseId)) {
			$result = $this->MainModel->deleteData('expense_id', $expenseId, 'expense');
			if ($result) {
				$this->session->set_flashdata('message', "Expenses deleted successfully !!!!");
				redirect('expenses-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('expenses-list');
		}
	}

	public function incomeExpenseReport()
	{

	$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		$expenseQuery = "select sum(expense_amount) as expensAmount from expense where expense.expense_date between '$dateId1' and '$dateId2'";
		$studentfeeQuery="select sum(invoice_amount) as invoice_amount from invoices where invoices.invoice_issue_date between '$dateId1' and '$dateId2'";
		$studentAbasicfeeQuery="select sum(resident_fee_amount)  as resident_fee_amount from  resident_fee 
where resident_fee.resident_issue_date between '$dateId1' and '$dateId2'";
		$receiveQuery="select sum(receive_amount)  as receive_amount from  receive 
where receive.receive_date between '$dateId1' and '$dateId2'";
		$incomesQuery="select sum(income_amount)  as income_amount from  incomes 
where incomes.income_date between '$dateId1' and '$dateId2'";
		$studentAbasicfee = $this->MainModel->AllQueryDalta($studentAbasicfeeQuery);
		$receive = $this->MainModel->AllQueryDalta($receiveQuery);
		$expense = $this->MainModel->AllQueryDalta($expenseQuery);
		$studentfee = $this->MainModel->AllQueryDalta($studentfeeQuery);
		$incomes = $this->MainModel->AllQueryDalta($incomesQuery);
		$data['totalIncome']=0;
		$data['expense']=0;
		$data['studentfee']=$studentfee[0]->invoice_amount;
		$data['studentAbasicfee']=$studentAbasicfee[0]->resident_fee_amount;
		$data['receive']=$receive[0]->receive_amount;
		$data['incomes']=$incomes[0]->income_amount;
		$data['expense']=$expense[0]->expensAmount;
        $data['gain']=0;
        $data['los']=0;

		$data['totalIncome']=$data['incomes']+$data['studentfee']+$data['studentAbasicfee']+$data['receive'];
		if($data['totalIncome']>=$data['expense']){
			$data['gain']=$data['totalIncome']-$data['expense'];
		}
		else {
			$data['los']=$data['expense']-$data['totalIncome'];
		}

		echo json_encode($data);
	}
	public  function  expenseSelectionData(){

		$query = "SELECT * FROM expense ORDER BY expense_id DESC LIMIT 1 ";
		$incomeId = $this->MainModel->QuerySingleData($query);
		if (empty($incomeId)) {
			$incomeData = 1;

		} else {
			$incomeData = $incomeId->expense_id + 1;
		}

		echo $incomeData;
	}



}
