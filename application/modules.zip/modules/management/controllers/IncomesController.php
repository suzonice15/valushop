<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class IncomesController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Total Incomes report";
		$data['active'] = "View incomes report ";
		$query = "select incomes.* ,expense_category_name from incomes 
join expense_category on expense_category.expense_category_id=incomes.expense_category_id order by incomes.income_id desc";
		$data['incomes'] = $this->MainModel->AllQueryDalta($query);
		$data['expenscat'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function allIncome()
	{
		$data['main'] = "Madrasah Incomes";
		$data['active'] = "View incomes ";

		$query = "select incomes.* ,expense_category_name from incomes 
join expense_category on expense_category.expense_category_id=incomes.expense_category_id order by incomes.income_id desc";
		$data['incomes'] = $this->MainModel->AllQueryDalta($query);
		$data['expenscat'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_all_incomes', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Income registration form ";
		$data['main'] = "Madrasah  Incomes";
		$data['active'] = "Add income";
		$data['expenseCategories'] = $this->MainModel->getAllData('expense_category_status=5', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_create', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function moneyForm()
	{
		$data['title'] = "Income registration form ";
		$data['main'] = "Money Received";
		$data['active'] = "Add Money Received";
		$data['expensesCatogry'] = $this->MainModel->getAllData('expense_category_status=4', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_moneyForm', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{


		date_default_timezone_set('Asia/Dhaka');



		$expense_category_id = implode(',',$this->input->post('expense_category_id'));
		$expense_category_array=explode(',',$expense_category_id);
		$income_amount = implode(',',$this->input->post('income_amount'));
		$income_amount_array=explode(',',$income_amount);
		$data['income_date'] = date('Y-m-d');

		for ( $i=0;$i<sizeof($expense_category_array);$i++){

			$data['expense_category_id']=$expense_category_array[$i];
			$data['income_amount']=$income_amount_array[$i];

			$result = $this->MainModel->returnInsertId('incomes', $data);


		}


		if ($result) {
			echo "Income added  successfully !!!!";
		}
		else {
			echo "Income  does not added successfully !!!!";

		}



	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['income'] = $this->MainModel->getSingleData('income_id', $id, 'incomes', '*');
		$incomeId = $data['income']->income_id;
		$data['expensesCatogry'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');

		if ($incomeId) {

			$data['title'] = "Income update page ";
			$data['main'] = "Income";
			$data['active'] = "Update Income";
			$data['pageContent'] = $this->load->view('management/incomes/incomes_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('Income-list');
		}


	}

	public function update()
	{
		$incomeId = $this->input->post('income_id');
		// check if the element exists before trying to edit it
		$incomeData = $this->MainModel->getSingleData('income_id', $incomeId, 'incomes', '*');
		$incomeId = $incomeData->income_id;

		if (isset($incomeId)) {
			$data['expense_category_id'] = $this->input->post('expense_category_id');
			$data['income_amount'] = $this->input->post('income_amount');
			$data['income_note'] = $this->input->post('income_note');
			$data['income_date'] = date('Y-m-d', strtotime($this->input->post('income_date')));
			$this->form_validation->set_rules('income_amount', 'Income name', 'required');
			$this->form_validation->set_rules('income_date', 'Income name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('income_id', $incomeId, 'incomes', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Income updated successfully !!!!");
					redirect('income-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('income-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('income-list');
		}


	}


	public function destroy($id)
	{
		$incomeData = $this->MainModel->getSingleData('income_id', $id, 'incomes', '*');
		$incomeId = $incomeData->income_id;

		if (isset($incomeId)) {
			$result = $this->MainModel->deleteData('income_id', $incomeId, 'incomes');
			if ($result) {


				$this->session->set_flashdata('message', "Income deleted successfully !!!!");
				redirect('income-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('income-list');
		}
	}

	public function incomeReport()
	{
		$dateId1 = date('Y-m-d', strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d', strtotime($this->input->post('dateId2')));
		$expense_category_id = $this->input->post('expense_category_id');
		if ($expense_category_id == 1) {
			$incomeQuery = "select * from incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where  incomes.income_date between '$dateId1' and '$dateId2'";
			$studentFeeQuery = "select * from invoices
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where   invoices.invoice_issue_date between '$dateId1' and '$dateId2'";
			$studentAbasicQuery = "select *  from resident_fee 
join expense_category on expense_category.expense_category_id=resident_fee.expense_category_id
where resident_fee.resident_issue_date between '$dateId1' and '$dateId2'";
			$danQuery = "select *  from receive 
join expense_category on expense_category.expense_category_id=receive.expense_category_id
where receive.receive_date between '$dateId1' and '$dateId2'";
		} else {
			$incomeQuery = "select * from incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where incomes.expense_category_id=$expense_category_id and incomes.income_date between '$dateId1' and '$dateId2'";
			$studentFeeQuery = "select * from invoices
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where invoices.expense_category_id=$expense_category_id and  invoices.invoice_issue_date between '$dateId1' and '$dateId2'";
			$studentAbasicQuery = "select *  from resident_fee 
join expense_category on expense_category.expense_category_id=resident_fee.expense_category_id
where resident_fee.resident_issue_date between '$dateId1' and '$dateId2' and resident_fee.expense_category_id=$expense_category_id";
			$danQuery = "select *  from receive 
join expense_category on expense_category.expense_category_id=receive.expense_category_id
where receive.receive_date between '$dateId1' and '$dateId2' and receive.expense_category_id=$expense_category_id";

		}
		$data['incomes'] = $this->MainModel->AllQueryDalta($incomeQuery);
		$data['studentFee'] = $this->MainModel->AllQueryDalta($studentFeeQuery);
		$data['studentAbasic'] = $this->MainModel->AllQueryDalta($studentAbasicQuery);
		$data['dan'] = $this->MainModel->AllQueryDalta($danQuery);
		$studentFeeTotal = 0;
		$incomeTotal = 0;
		$studentAbasicTotal = 0;
		$danTotal = 0;
		foreach ($data['studentFee'] as $fee) {

			$studentFeeTotal = $studentFeeTotal + $fee->invoice_amount;
		}
		foreach ($data['incomes'] as $income) {

			$incomeTotal = $incomeTotal + $income->income_amount;
		}

		foreach ($data['studentAbasic'] as $studentAbasic) {

			$studentAbasicTotal = $studentAbasicTotal + $studentAbasic->resident_fee_amount;
		}
		foreach ($data['dan'] as $dan) {

			$danTotal = $danTotal + $dan->receive_amount;
		}
		$data['totalIncome'] = $incomeTotal + $studentFeeTotal+$studentAbasicTotal+$danTotal;
		echo json_encode($data);
	}

	public function incomeReportPrint()
	{
		$dateId1 = date('Y-m-d', strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d', strtotime($this->input->post('dateId2')));
		$expense_category_id = $this->input->post('expense_category_id');
		$data['firstDate'] = $dateId1;
		$data['lastDate'] = $dateId2;
		if ($expense_category_id == 1) {
			$incomeQuery = "select * from incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where  incomes.income_date between '$dateId1' and '$dateId2'";
			$feeQuery = "select * from invoices
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where   invoices.invoice_creation_time between '$dateId1' and '$dateId2'";
			$data['allCagegory'] = "All category";
		} else {
			$incomeQuery = "select * from incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where incomes.expense_category_id=$expense_category_id and incomes.income_date between '$dateId1' and '$dateId2'";
			$feeQuery = "select * from invoices
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where invoices.expense_category_id=$expense_category_id and  invoices.invoice_creation_time between '$dateId1' and '$dateId2'";

		}
		$data['incomes'] = $this->MainModel->AllQueryDalta($incomeQuery);
		$data['fees'] = $this->MainModel->AllQueryDalta($feeQuery);
		$feeTotal = 0;
		$incomeTotal = 0;
		foreach ($data['fees'] as $fee) {

			$feeTotal = $feeTotal + $fee->invoice_amount_paid;
		}
		foreach ($data['incomes'] as $income) {

			$incomeTotal = $incomeTotal + $income->income_amount;
		}
		$data['totalIncome'] = $incomeTotal + $feeTotal;
		$data['main'] = "Income report print";
		$data['active'] = "print income";
		$data['pageContent'] = $this->load->view('management/incomes/incomes_ReportPrint', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function receiveSelectionData()
	{
		$query = "SELECT * FROM receive ORDER BY receive_id DESC LIMIT 1 ";
		$invoiceId = $this->MainModel->QuerySingleData($query);
		if (empty($invoiceId)) {
			$invoiceId = 1;

		} else {
			$invoiceId = $invoiceId->receive_id + 1;
		}

		echo $invoiceId;
	}

	public function receviedSave()
	{
		date_default_timezone_set('Asia/Dhaka');


		$data['receive_data_name'] = $this->input->post('receive_data_name');
		$data['receive_amount'] = $this->input->post('receive_amount');
		$data['receive_adaikari'] = $this->input->post('receive_adaikari');
		$data['receive_address'] = $this->input->post('receive_address');
		$data['expense_category_id'] = $this->input->post('expense_category_id');
		$data['receive_date'] = date("Y-m-d");
		$result = $this->MainModel->insertData('receive', $data);
		if ($result) {
			echo "Received Money Successfully !!!!!!!!!!!!";
		} else {
			echo "Received Money does not Successfully !!!!!!!!!!!!";
		}


	}

	public function moneylist()
	{
		$data['main'] = "Money Received ";
		$data['active'] = "View Money Received";
		$query = "select  * from  receive 
join expense_category on expense_category.expense_category_id=receive.expense_category_id
order by receive.receive_id desc";
		$data['receives'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('management/incomes/incomes_moneylist', $data, true);
		$this->load->view('layouts/main', $data);

	}

	public function incomeRosidSelectionData()
	{

		$query = "SELECT * FROM incomes ORDER BY income_id DESC LIMIT 1 ";
		$incomeId = $this->MainModel->QuerySingleData($query);
		if (empty($incomeId)) {
			$incomeData = 1;

		} else {
			$incomeData = $incomeId->income_id + 1;
		}

		echo $incomeData;
	}

	public  function moneyRecievedReportForm(){
		$data['main'] = "Money Received report ";
		$data['active'] = "View Money Received report";
		$query = "select  * from  receive 
join expense_category on expense_category.expense_category_id=receive.expense_category_id
order by receive.receive_id desc";
		$data['receives'] = $this->MainModel->AllQueryDalta($query);
		$data['expenscat'] = $this->MainModel->getAllData('expense_category_status=4', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_moneyRecievedReport', $data, true);
		$this->load->view('layouts/main', $data);


	}

	public  function moneyRecievedReport(){
		$classreg_section_id = $this->input->post('classreg_section_id');
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		if($classreg_section_id==1){
$query="select *  from  receive
join expense_category on expense_category.expense_category_id=receive.expense_category_id
where  receive.receive_date  between '$dateId1' and '$dateId2'";
		} else {

			$query="select *  from  receive
join expense_category on expense_category.expense_category_id=receive.expense_category_id
where  receive.receive_date  between '$dateId1' and '$dateId2' and receive.expense_category_id=$classreg_section_id";
		}
		$receive = $this->MainModel->AllQueryDalta($query);
		$data['receive'] = $this->MainModel->AllQueryDalta($query);
		$total=0;
		foreach ($receive as $recive){
			$total=$total+$recive->receive_amount;

		}
		$data['total']=$total;
		echo json_encode($data);


	}
	public  function madrasahIncomeReportForm(){

		$data['main'] = "Madrasah Income report ";
		$data['active'] = "View Madrasah Income report";

		$data['expenscat'] = $this->MainModel->getAllData('expense_category_status=5', 'expense_category', '*', 'expense_category_id DESC');

		$data['pageContent'] = $this->load->view('management/incomes/incomes_madrasahIncomeReportForm', $data, true);
		$this->load->view('layouts/main', $data);

	}
	public  function MadrasahIncomeReport(){

		$classreg_section_id = $this->input->post('classreg_section_id');
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		if($classreg_section_id==1){
			$query="select *  from  incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where incomes.income_date between '$dateId1' and  '$dateId2'";
		} else {

			$query="select *  from  incomes
join expense_category on expense_category.expense_category_id=incomes.expense_category_id
where incomes.income_date between '$dateId1' and  '$dateId2' and incomes.expense_category_id=$classreg_section_id";
		}
		$receive = $this->MainModel->AllQueryDalta($query);
		$data['receive'] = $this->MainModel->AllQueryDalta($query);
		$total=0;
		foreach ($receive as $recive){
			$total=$total+$recive->income_amount;

		}
		$data['total']=$total;
		echo json_encode($data);

	}
	public  function  incomeExpenseReportOnePage(){

		$data['main'] = "Income|Expense One page report  ";
		$data['active'] = "View income |expense  report";
		$data['expenseCatt'] = $this->MainModel->getAllData('expense_category_status=3', 'expense_category', '*', 'expense_category_id DESC');

		$data['expenscat'] = $this->MainModel->getAllData('', 'expense_category', '*', 'expense_category_id DESC');


//		$data['expenscat'] = $this->MainModel->getAllData('expense_category_status=4', 'expense_category', '*', 'expense_category_id DESC');
		$data['pageContent'] = $this->load->view('management/incomes/incomes_incomeExpenseReportOnePage', $data, true);
		$this->load->view('layouts/main', $data);


	}

}




