<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ShiftsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Shifts";
		$data['active'] = "Shifts view";
		$data['shifts'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');

		$data['pageContent'] = $this->load->view('management/shifts/shifts_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Shift registration form ";
		$data['main'] = "Shift";
		$data['active'] = "Add shift";
		$data['pageContent'] = $this->load->view('management/shifts/shifts_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['shift_name'] = $this->input->post('shift_name');
		$this->form_validation->set_rules('shift_name', 'shift name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('shifts', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Shift added successfully !!!!");
				redirect('shift-create');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('shift-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['shift'] = $this->MainModel->getSingleData('shift_id', $id, 'shifts', '*');
		$shiftId = $data['shift']->shift_id;

		if ($shiftId) {

			$data['title'] = "Shift update page ";
			$data['main'] = "Shift";
			$data['active'] = "Update shift";
			$data['pageContent'] = $this->load->view('management/shifts/shifts_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('shift-list');
		}


	}

	public function update()
	{
		$shiftId = $this->input->post('shift_id');
		// check if the element exists before trying to edit it
		$shiftData = $this->MainModel->getSingleData('shift_id', $shiftId, 'shifts', '*');
		$shiftId = $shiftData->shift_id;

		if (isset($shiftId)) {
			$data['shift_name'] = $this->input->post('shift_name');
			$this->form_validation->set_rules('shift_name', 'shift name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('shift_id', $shiftId, 'shifts', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Shift updated successfully !!!!");
					redirect('shift-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('shift-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('shift-list');
		}


	}

	public function multipleDataStore($shiftId)
	{

		$data['shiftData'] = $this->MainModel->getSingleData('shift_id', $shiftId, 'shifts', '*');
		$data['shiftClassSectionRelations'] = $this->MainModel->getAllData("shift_id=$shiftId", 'shift_classreg_section_com', '*', 'shift_id DESC');


		//print_r($data);exit();
		$data['title'] = "Shift class section relation registration form ";
		$data['main'] = "Shift class section relation";
		$data['active'] = "add Shift class section relation";
		$query="select classreg_section_com.classreg_section_name,classreg_section_com.classreg_section_id from  classreg_section_com left join shift_classreg_section_com on classreg_section_com.classreg_section_id=shift_classreg_section_com.classreg_section_id
where shift_classreg_section_com.classreg_section_id is null and shift_classreg_section_com.shift_classreg_section_isActive is null or shift_classreg_section_com.shift_classreg_section_isActive=0
union 
select classreg_section_com.classreg_section_name,classreg_section_com.classreg_section_id from  classreg_section_com  join shift_classreg_section_com on classreg_section_com.classreg_section_id=shift_classreg_section_com.classreg_section_id
where shift_classreg_section_com.shift_id=$shiftId and  shift_classreg_section_com.shift_classreg_section_isActive=1
 
 ";
		$data['classSectionRelations'] = 		 $this->MainModel->AllQueryDalta($query);

		$data['pageContent'] = $this->load->view('management/Shifts/Shifts_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$classSectionDataArray = array();
		$shiftClassSectionDataArray = array();
		$data['shift_id'] = $this->input->post('shift_id');
		$shiftId= $this->input->post('shift_id');
		$classSectionId= $this->input->post('classreg_section_id');
		if(isset($classSectionId)) {
			$classSectionData = implode(',', $this->input->post('classreg_section_id'));

			$shiftClassSectionData = implode(',', array_filter($this->input->post('shift_classreg_section_name')));

			$classSectionDataArray = explode(',', $classSectionData);
			$shiftClassSectionDataArray = explode(',', $shiftClassSectionData);
			$shiftId = $this->MainModel->getDataRow('shift_id', $shiftId, 'shift_classreg_section_com', '*');
			if ($shiftId > 0) {
				$this->MainModel->deleteData('shift_id', $shiftId, 'shift_classreg_section_com');
			}
			for ($i = 0; $i < sizeof($classSectionDataArray); $i++) {
				$data['classreg_section_id'] = $classSectionDataArray[$i];
				$data['shift_classreg_section_name'] = $shiftClassSectionDataArray[$i];
				$data['shift_classreg_section_isActive'] = 1;

				$result = $this->MainModel->insertData('shift_classreg_section_com', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Shift relation with class section added successfully !!!!";
				$this->session->set_userdata($data);
				//$this->session->set_flashdata('messege', "Shift relation with class section added successfully !!!!");
				redirect('shift-list');
			}
		}
		else{
			if ($shiftId > 0) {
				$this->MainModel->deleteData('shift_id', $shiftId, 'shift_classreg_section_com');
			}

			$data['relationMessage'] = "You dont add  any  information to database  !!!!";
			$this->session->set_userdata($data);
			redirect('shift-list');

		}


	}


	public function destroy($id)
	{
		$shiftData = $this->MainModel->getSingleData('shift_id', $id, 'shifts', '*');
		$shiftId = $shiftData->shift_id;

		if (isset($shiftId)) {
			$result = $this->MainModel->deleteData('shift_id', $shiftId, 'shifts');
			if ($result) {


				$this->session->set_flashdata('message', "Shift deleted successfully !!!!");
				redirect('shift-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('shift-list');
		}
	}


}
