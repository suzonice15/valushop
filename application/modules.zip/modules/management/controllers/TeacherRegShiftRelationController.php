<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  TeacherRegShiftRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->model('TeacherRegShiftRelation');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		///echo 'jfjfj';exit();
		$data['main'] = "shifts report";
		$data['active'] = "view shift report";
		$query = "select teacher_shift_com.* ,shifts.shift_name as shift_name ,teachers.teacher_contact_no,teachers.teacher_full_name as teacher_name  from teacher_shift_com join teachers on teacher_shift_com.teacher_id=teachers.teacher_id join shifts on teacher_shift_com.shift_id=shifts.shift_id 
order by teacher_shift_com.teacher_shift_id desc
";
		$data['teacherRelation'] = $this->MainModel->AllQueryDalta($query);
		$data['shifts'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');

		//print_r($data);exit();
		$data['pageContent'] = $this->load->view('management/teacherRegShiftRelation/teacherRegShiftRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Teacher & shift relation registration form ";
		$data['main'] = "Teacher & Shift Relation";
		$data['active'] = "Add teacher & shift   relation";
		$query="select teachers.teacher_id,teachers.teacher_full_name  from teachers  left join teacher_shift_com on teachers.teacher_id=teacher_shift_com.teacher_id 
where teacher_shift_com.teacher_id is null and teacher_shift_com.teacher_shift_isActive is null or teacher_shift_com.teacher_shift_isActive=0";
		$data['teacher'] = $this->MainModel->AllQueryDalta($query);

		//88$data['teacher'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');
		$data['shift'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');
		$data['pageContent'] = $this->load->view('management/teacherRegShiftRelation/teacherRegShiftRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['teacher_id'] = $this->input->post('teacher_id');
		$data['shift_id'] = $this->input->post('shift_id');
		$data['teacher_shift_name'] = $this->input->post('teacher_shift_name');

		$this->form_validation->set_rules('teacher_id', 'Teacher  name', 'required');
		$this->form_validation->set_rules('shift_id', 'shift name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('teacher_shift_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Teacher shift relation with shift added successfully !!!!");
				redirect('teacher-shift-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('teacher-shift-create');
		}


	}

	public function show($id)
	{

	}

	public function multipleDataStore($shiftId)
	{
		$query = "select teacher_shift_com.* ,teacher_shift_com.teacher_shift_name as teacher_shift_name, shifts.shift_id as shift_id,shifts.shift_name as
 shift_name from teacher_shift_com right join shifts  on teacher_shift_com.shift_id =shifts.shift_id where shifts.shift_id
=$shiftId  ";
		$data['shiftRelation'] = $this->TeacherRegShiftRelation->DataFromClassRelation($query);
		//print_r($data['shiftRelation']);exit();


		$data['title'] = "Teacher relation registration form ";
		$data['main'] = "Teacher relation";
		$data['second'] = "Teacher relation option";
		$data['active'] = "add Teacher relation";
		$query="select teachers.teacher_id,teachers.teacher_full_name  from teachers  left join teacher_shift_com on teachers.teacher_id=teacher_shift_com.teacher_id 
where teacher_shift_com.teacher_id is null and teacher_shift_com.teacher_shift_isActive is null or teacher_shift_com.teacher_shift_isActive=0
union
SELECT teachers.teacher_id,teachers.teacher_full_name  FROM teacher_shift_com 
join teachers on teacher_shift_com.teacher_id=teachers.teacher_id
where teacher_shift_com.teacher_shift_id=$shiftId and teacher_shift_com.teacher_shift_isActive=1";
		$data['teachers'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('management/teacherRegShiftRelation/teacherRegShiftRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$teacherDataArray = array();
		$teacherShiftDataArray = array();
		$data['shift_id'] = $this->input->post('shift_id');
		$shift_id = $this->input->post('shift_id');

		$teacherId=$this->input->post('teacher_id');
		if (isset($teacherId)) {
			$teacherData = implode(',', $this->input->post('teacher_id'));
			$teacherShiftData = implode(',', array_filter($this->input->post('teacher_shift_name')));


			$teacherDataArray = explode(',', $teacherData);
			$teacherShiftDataArray = explode(',', $teacherShiftData);

			$shiftId = $this->MainModel->getDataRow('shift_id', $shift_id, 'teacher_shift_com', '*');
			if ($shiftId > 0) {
				$this->MainModel->deleteData('shift_id', $shift_id, 'teacher_shift_com');
			}
			for ($i = 0; $i < sizeof($teacherDataArray); $i++) {
				$data['shift_id'] = $this->input->post('shift_id');
				$data['teacher_id'] = $teacherDataArray[$i];
				$data['teacher_shift_name'] = $teacherShiftDataArray[$i];
				$data['teacher_shift_isActive'] = 1;

				$result = $this->MainModel->insertData('teacher_shift_com', $data);
			}

			if ($result) {
				$data['relationMessage'] = "shift relation with teacher added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('shift-list');
			}
		} else {

			$shiftId = $this->MainModel->getDataRow('shift_id', $shift_id, 'teacher_shift_com', '*');
			if ($shiftId > 0) {
				$this->MainModel->deleteData('shift_id', $shift_id, 'teacher_shift_com');
			}
			$data['relationMessage'] = "You don't add any data to database     !!!!";
			$this->session->set_userdata($data);
			//$this->session->set_flashdata('messege', "Examination relation with session added successfully !!!!");
			redirect('shift-list');

		}


	}

	public function edit($id)
	{
		$data['teacherRelation'] = $this->MainModel->getSingleData('teacher_shift_id', $id, 'teacher_shift_com', '*');
		// print_r($data);exit();
		$teacher_shift_id = $data['teacherRelation']->teacher_shift_id;
		$data['teacher'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');
		$data['shift'] = $this->MainModel->getAllData('', 'shifts', '*', 'shift_id DESC');

		if (isset($teacher_shift_id)) {
			$data['title'] = "Teacher & shift relation update page ";
			$data['main'] = "Teacher & Shift Relation";
			$data['active'] = "Update teacher &  shift relation";
			$data['pageContent'] = $this->load->view('management/teacherRegShiftRelation/teacherRegShiftRelation_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('teacher-shift-list');
		}

	}

	public function update()
	{
		$classReg_section_id = $this->input->post('teacher_shift_id');
		// check if the element exists before trying to edit it
		$ClassRelation = $this->MainModel->getSingleData('teacher_shift_id', $classReg_section_id, 'teacher_shift_com', '*');
		$classReg_section_id = $ClassRelation->teacher_shift_id;

		if (isset($classReg_section_id)) {
			$data['teacher_id'] = $this->input->post('teacher_id');
			$data['shift_id'] = $this->input->post('shift_id');
			$data['teacher_shift_name'] = $this->input->post('teacher_shift_name');


			$this->form_validation->set_rules('shift_id', 'Teacher shift relation name', 'required');
			$this->form_validation->set_rules('teacher_id', 'Teacher shift relation name', 'required');
			$this->form_validation->set_rules('teacher_shift_name', 'Teacher shift relation name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('teacher_shift_id', $classReg_section_id, 'teacher_shift_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Teacher shift relation with section updated successfully !!!!");
					redirect('teacher-shift-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('teacher-shift-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('teacher-shift-list');
		}

	}

public  function  shiftSelection(){
		$shiftId=$this->input->post('shift_id');
		$query="select teacher_full_name ,teacher_contact_no,shift_name from teacher_shift_com join shifts on shifts.shift_id=teacher_shift_com.shift_id join teachers on teachers.teacher_id=teacher_shift_com.teacher_id where  teacher_shift_com.shift_id=$shiftId";
	$shifts= $this->MainModel->AllQueryDalta($query);
	echo json_encode($shifts);


}

	public  function  teacherSelection(){
		$teacherId=$this->input->post('teacher_id');
		$query="select teacher_full_name ,teacher_contact_no,shift_name from teacher_shift_com join shifts on shifts.shift_id=teacher_shift_com.shift_id join teachers on teachers.teacher_id=teacher_shift_com.teacher_id where  teacher_shift_com.teacher_id=$teacherId";
		$teachers= $this->MainModel->AllQueryDalta($query);
		echo json_encode($teachers);


	}


	public  function  shiftReport(){
		$shiftId=$this->input->post('shift_id');
		$query="select teacher_full_name ,teacher_contact_no,shift_name from teacher_shift_com join shifts on shifts.shift_id=teacher_shift_com.shift_id join teachers on teachers.teacher_id=teacher_shift_com.teacher_id where  teacher_shift_com.shift_id=$shiftId";
		$data['teacherRelation']= $this->MainModel->AllQueryDalta($query);
		$this->pdf->load_view('management/TeacherRegShiftRelation/shiftReport',$data);
		$this->pdf->render();
		$this->pdf->stream("mark.pdf");



	}

	public function destroy($id)
	{
		$ClassRelation = $this->MainModel->getSingleData('teacher_shift_id', $id, 'teacher_shift_com', '*');
		$teacher_shift_id = $ClassRelation->teacher_shift_id;
		if (isset($teacher_shift_id)) {
			$result = $this->MainModel->deleteData('teacher_shift_id', $id, 'teacher_shift_com');
			if ($result) {
				$this->session->set_flashdata('message', "Teacher shift relation with section deleted successfully !!!!");
				redirect('teacher-shift-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('teacher-shift-list');
		}
	}

}
