<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property  MainModel
 */
class HolidayController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}

	}

	public function index()
	{
		$data['main'] = "Holiday";
		$data['active'] = "view holiday";
		$data['holidays'] = $this->MainModel->getAllData('', 'events', '*', 'event_id DESC');

		$data['pageContent'] = $this->load->view('management/holidays/holidays_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Holiday registration form ";
		$data['main'] = "Holiday";
		$data['active'] = "Add holiday";
		$data['pageContent'] = $this->load->view('management/holidays/holidays_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{


		$data['event_title'] = $this->input->post('event_title');
		$data['event_start_date'] = date('Y-m-d', strtotime($this->input->post('event_start_date')));
		$data['event_end_date'] = date('Y-m-d', strtotime($this->input->post('event_end_date')));
		$this->form_validation->set_rules('event_title', 'holiday name', 'required');
		$this->form_validation->set_rules('event_start_date', 'holiday code', 'required');
		$this->form_validation->set_rules('event_end_date', 'holiday code', 'required');

		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('events', $data);
			if ($result) {
				$this->session->set_flashdata('message', "holiday added successfully !!!!");
				redirect('holiday-create');
			}
		} else {

			$this->session->set_flashdata('error', "All field need to fillUp");
			redirect('holiday-create');
		}


	}

	public function show($id)
	{
		
	}

	public function edit($id)
	{
		$data['event'] = $this->MainModel->getSingleData('event_id', $id, 'events', '*');
		$event_id = $data['event']->event_id;
		if (isset($event_id)) {
			$data['title'] = "holiday update page ";
			$data['main'] = "holiday";
			$data['active'] = "update holiday";
			$data['pageContent'] = $this->load->view('management/holidays/holidays_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('holiday-list');
		}

	}

	public function update()
	{
		$event_id = $this->input->post('event_id');
		$holiday = $this->MainModel->getSingleData('event_id', $event_id, 'events', '*');
		$eventId = $holiday->event_id;
		if (isset($eventId)) {


			$data['event_title'] = $this->input->post('event_title');
			$data['event_start_date'] = date('Y-m-d', strtotime($this->input->post('event_start_date')));
			$data['event_end_date'] = date('Y-m-d', strtotime($this->input->post('event_end_date')));
			$this->form_validation->set_rules('event_title', 'holiday name', 'required');
			$this->form_validation->set_rules('event_start_date', 'holiday code', 'required');
			$this->form_validation->set_rules('event_end_date', 'holiday code', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('event_id', $event_id, 'events', $data);
				if ($result) {
					$this->session->set_flashdata('message', "holiday updated successfully !!!!");
					redirect('holiday-list');
				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('holiday_update');
			}
		}
		else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('holiday-list');
		}

	}

	public  function  studentMobile($mobile){
		$mobileNumber = $this->MainModel->getDataRow('student_phone', $mobile, 'events', '*');
		if($mobileNumber>0){
			echo "This mobile number is already exist please enter another mobile number ";
		}
		else {

			echo "";
		}

	}

	public function destroy($id)
	{
		$holiday = $this->MainModel->getSingleData('event_id', $id, 'events', '*');
		$event_id = $holiday->event_id;
		if (isset($event_id)) {
			$result = $this->MainModel->deleteData('event_id', $id, 'events');
			if ($result) {
				$this->session->set_flashdata('message', "holiday deleted successfully !!!!");
				redirect('holiday-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('holiday-list');
		}
	}
}
