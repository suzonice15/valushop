<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property  MainModel
 */
class StudentsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->library('image_lib');
		$this->load->library('upload');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}

	}

	public function index()
	{
		$data['main'] = "Students";
		$data['active'] = "Students view";
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');

		$data['pageContent'] = $this->load->view('management/students/students_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Student registration form ";
		$data['main'] = "Student";
		$data['active'] = "Add student";
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');

		$data['pageContent'] = $this->load->view('management/students/students_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		if (isset($_FILES["student_picture_path"]["name"])) {
			if ((($_FILES["student_picture_path"]["type"] == "image/jpg") || ($_FILES["student_picture_path"]["type"] == "image/jpeg") || ($_FILES["student_picture_path"]["type"] == "image/png") || ($_FILES["student_picture_path"]["type"] == "image/gif"))) {

				if ($_FILES["student_picture_path"]["error"] > 0) {
					echo "Return Code: " . $_FILES["student_picture_path"]["error"] . "<br />";
				} else {
					$uploaded_image_path = "uploads/students/" . time() . '-' . $_FILES["student_picture_path"]["name"];
					$uploaded_file_path = "uploads/students/" . $_FILES["student_picture_path"]["name"];

					if (!file_exists($uploaded_file_path)) {
						move_uploaded_file($_FILES["student_picture_path"]["tmp_name"], $uploaded_image_path);
						// resize image
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = FALSE;
						$config['maintain_ratio'] = FALSE;
						$config['new_image'] = $uploaded_image_path;
						$config['quality'] = '60%';
						$config['width'] = 300;
						$config['height'] = 300;
						$this->image_lib->clear();
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
						$data['student_picture_path'] = $config['source_image'];
					}
				}
			}
		}
		$data['student_name'] = $this->input->post('student_name');
		$data['student_father_name'] = $this->input->post('student_father_name');
		$data['student_mother_name'] = $this->input->post('student_mother_name');
		$data['student_birthday'] = date('d-m-Y', strtotime($this->input->post('student_birthday')));
		$data['student_sex'] = $this->input->post('student_sex');
		$data['student_religion'] = $this->input->post('student_religion');
		$data['student_blood_group'] = $this->input->post('student_blood_group');
		$data['student_address'] = $this->input->post('student_address');
		$data['student_phone'] = $this->input->post('student_phone');
		$data['student_email'] = $this->input->post('student_email');
		$this->form_validation->set_rules('student_name', 'Student name', 'required');
		$this->form_validation->set_rules('student_father_name', 'Student name', 'required');
		$this->form_validation->set_rules('student_mother_name', 'Student name', 'required');
		$this->form_validation->set_rules('student_sex', 'Student name', 'required');
		$this->form_validation->set_rules('student_religion', 'Student name', 'required');
		$this->form_validation->set_rules('student_address', 'Student name', 'required');
		$this->form_validation->set_rules('student_phone', 'Student code', 'required');

		if ($this->form_validation->run()) {
			$studentId = $this->MainModel->returnInsertId('students', $data);
			$newData['student_id']=$studentId;
			$newData['session_id'] = $this->input->post('session_id');
			$newData['student_classreg_section_isActive'] =1;
			$newData['student_roll']=$this->input->post('student_roll');
			$newData['classreg_section_id'] = $this->input->post('classreg_section_id');
			$newData['student_classreg_section_name'] = $this->input->post('student_classreg_section_name');
			$result = $this->MainModel->insertData('student_classreg_section_com', $newData);
			if ($result) {
				$this->session->set_flashdata('message', "Student added successfully !!!!");
				redirect('student-create');
			}
		} else {

			$this->session->set_flashdata('error', "All field need to fillUp");
			redirect('student-create');
		}


	}

	public function show($id)
	{
		$data['studentId'] = $this->MainModel->getSingleData('student_id', $id, 'students', '*');
		$student_id = $data['studentId']->student_id;
		if (isset($student_id)) {
			$data['title'] = "Student profile page";
			$data['main'] = "Student";
			$data['second'] = "Student option";
			$data['active'] = "pofile of Student";
			$query="select * from students
 join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
 join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
 join sessions on sessions.session_id=student_classreg_section_com.session_id
 where students.student_id=$student_id";
			$data['student']=$this->MainModel->QuerySingleData($query);

			$data['pageContent'] = $this->load->view('management/students/students_show', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-list');
		}
	}

	public function edit($id)
	{
		$data['studentId'] = $this->MainModel->getSingleData('student_id', $id, 'students', '*');
		$student_id = $data['studentId']->student_id;
		if (isset($student_id)) {
			$data['title'] = "Student update page ";
			$data['main'] = "Student";
			$data['second'] = "Student option";
			$data['active'] = "update Student";
			$query="select * from students
 join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
 where students.student_id=$student_id";
			$data['student']=$this->MainModel->QuerySingleData($query);
			$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
			$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');



			$data['pageContent'] = $this->load->view('management/students/students_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-list');
		}

	}

	public function update()
	{
		$student_id = $this->input->post('student_id');
		$Student = $this->MainModel->getSingleData('student_id', $student_id, 'students', '*');
		$studentId = $Student->student_id;


		if (isset($studentId)) {

			$old_student_picture_path=$this->input->post('old_student_picture_path');
			$data['student_picture_path']=$this->input->post('old_student_picture_path');
			if(isset($_FILES["student_picture_path"]["name"]))
			{
				if((($_FILES["student_picture_path"]["type"]=="image/jpg") || ($_FILES["student_picture_path"]["type"]=="image/jpeg") || ($_FILES["student_picture_path"]["type"]=="image/png") || ($_FILES["student_picture_path"]["type"]=="image/gif"))){
					if(!empty($old_student_picture_path)){
						unlink($old_student_picture_path);

					}
					$uploaded_image_path = "uploads/students/".time().'-'.$_FILES["student_picture_path"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["student_picture_path"]["error"] > 0) {
						echo "Return Code: " . $_FILES["student_picture_path"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["student_picture_path"]["tmp_name"],$uploaded_image_path);
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 300;
						$config['height'] = 300;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['student_picture_path']=$uploaded_image_path;

					}
				}
			}

				$data['student_name'] = $this->input->post('student_name');
				$data['student_father_name'] = $this->input->post('student_father_name');
				$data['student_mother_name'] = $this->input->post('student_mother_name');
				$data['student_birthday'] = $this->input->post('student_birthday');
				$data['student_sex'] = $this->input->post('student_sex');
				$data['student_religion'] = $this->input->post('student_religion');
				$data['student_blood_group'] = $this->input->post('student_blood_group');
				$data['student_address'] = $this->input->post('student_address');
				$data['student_phone'] = $this->input->post('student_phone');
				$data['student_email'] = $this->input->post('student_email');
				$this->form_validation->set_rules('student_name', 'Student name', 'required');
				$this->form_validation->set_rules('student_father_name', 'Student name', 'required');
				$this->form_validation->set_rules('student_mother_name', 'Student name', 'required');
				$this->form_validation->set_rules('student_sex', 'Student name', 'required');
				$this->form_validation->set_rules('student_religion', 'Student name', 'required');
				$this->form_validation->set_rules('student_address', 'Student name', 'required');
				$this->form_validation->set_rules('student_phone', 'Student code', 'required');
				if ($this->form_validation->run()) {
					$result = $this->MainModel->updateData('student_id', $student_id, 'students', $data);
					$newData['student_id']=$this->input->post('student_id');
					$newData['student_roll']=$this->input->post('student_roll');
					$newData['session_id'] = $this->input->post('session_id');
					$newData['student_classreg_section_isActive'] =1;
					$newData['classreg_section_id'] = $this->input->post('classreg_section_id');
					$newData['student_classreg_section_name'] = $this->input->post('student_classreg_section_name');
					$result = $this->MainModel->updateData('student_id', $student_id, 'student_classreg_section_com', $newData);


					if ($result) {
						$this->session->set_flashdata('message', "Student updated successfully !!!!");
						redirect('student-list');
					}
				} else {

					$this->session->set_flashdata('message', "value reqiured");
					redirect('student-update');
				}
			}
		 else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-list');
		}

	}

	public  function  studentMobile($mobile){
		$mobileNumber = $this->MainModel->getDataRow('student_phone', $mobile, 'students', '*');
		if($mobileNumber>0){
			echo "This mobile number is already exist please enter another mobile number ";
		}
		else {

			echo "";
		}

	}

	public function destroy($id)
	{
		$Student = $this->MainModel->getSingleData('student_id', $id, 'students', '*');
		$student_id = $Student->student_id;
		if (isset($student_id)) {
			$result = $this->MainModel->deleteData('student_id', $id, 'students');
			if ($result) {
				$this->session->set_flashdata('message', "Student deleted successfully !!!!");
				redirect('student-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('student-list');
		}
	}
	public  function  studentEmailCheck(){
		$teacher_email=$this->input->post('student_email');
		$emailTeacher = $this->MainModel->getDataRow('teacher_email', $teacher_email, 'teachers', '*');
		$emailStudent= $this->MainModel->getDataRow('student_email', $teacher_email, 'students', '*');

		if($emailTeacher>0){
			echo "This email are stored to database please try with other email ";
		}
		else if($emailStudent>0){

			echo "This email are stored to database please try with other email ";
		}
		else {
			echo "";

		}

	}

}
