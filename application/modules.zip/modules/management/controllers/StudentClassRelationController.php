<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  StudentClassRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$this->load->model('StudentClassRelation');
//		$userId = $this->session->userdata('user_id');
//		if ($userId == null) {
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Students reports";
		$data['active'] = "view  students report";
		$query = "select * from student_classreg_section_com  join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id order by student_classreg_section_id DESC";
		$data['studentClassSectionRelations'] = $this->MainModel->AllQueryDalta($query);
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');

		$data['pageContent'] = $this->load->view('management/studentClassRelation/studentClassRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Student , class  and section relation  registration form ";
		$data['main'] = "Student , Class and Section Relation";
		$data['active'] = "Add student , class and section relation";
		$query = "select students.student_id as student_id ,students.student_name,student_classreg_section_com.student_classreg_section_isActive from students 
left join student_classreg_section_com on students.student_id=student_classreg_section_com.student_id 
where student_classreg_section_com.student_id is null 
and student_classreg_section_com.student_classreg_section_isActive is null
 or student_classreg_section_com.student_classreg_section_isActive=0";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		//var_dump($data['students'] );exit();
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');


		//	$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('management/studentClassRelation/studentClassRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['classreg_section_id'] = $this->input->post('classreg_section_id');
		$data['session_id'] = $this->input->post('session_id');
		$data['student_id'] = $this->input->post('student_id');
		$data['student_classreg_section_name'] = $this->input->post('student_classreg_section_name');

		//var_dump($data);exit();
		$this->form_validation->set_rules('student_classreg_section_name', 'Teacher  name', 'required');
		$this->form_validation->set_rules('session_id', 'session  name', 'required');
		$this->form_validation->set_rules('student_id', 'Teacher  name', 'required');
		$this->form_validation->set_rules('classreg_section_id', 'shift name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('student_classreg_section_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "student  relation with section and class added successfully !!!!");
				redirect('student-class-section-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('student-class-section-create');
		}


	}

	public function show($id)
	{

	}

	public function multipleDataStore($classSectionId)
	{
		$query = "select * from student_classreg_section_com right join classreg_section_com on classreg_section_com.classreg_section_id=
student_classreg_section_com.classreg_section_id where classreg_section_com.classreg_section_id=$classSectionId";
		$data['studentRelations'] = $this->MainModel->AllQueryDalta($query);        //echo '<pre>';

		//var_dump($data);exit();
		$data['title'] = "Student relation with class registration form ";
		$data['main'] = "Student class relation ";
		$data['active'] = "Add student relation";
		$query = "select students.student_id,students.student_name from students 
left join student_classreg_section_com on students.student_id=student_classreg_section_com.student_id 
where student_classreg_section_com.student_id is null
and student_classreg_section_com.student_classreg_section_isActive is null
 or student_classreg_section_com.student_classreg_section_isActive=0
union
SELECT students.student_id,students.student_name FROM schoole_management_db.student_classreg_section_com 
join students on student_classreg_section_com.student_id=students.student_id
where student_classreg_section_com.classreg_section_id=$classSectionId and student_classreg_section_com.student_classreg_section_isActive=1";
		$data['students'] = $this->MainModel->AllQueryDalta($query);

		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
		$data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');

		//echo '<pre>';

		//$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['pageContent'] = $this->load->view('management/studentClassRelation/studentClassRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{

		$studentDataArray = array();
		$studentClassDataArray = array();
		$class_id = $this->input->post('classreg_section_id');
		$data['session_id'] = $this->input->post('session_id');
		$studentId=$this->input->post('student_id');
		if(isset($studentId)) {
			$studentData = implode(',', $this->input->post('student_id'));
			$studentDataArray = explode(',', $studentData);
			$studentClassData = implode(',', array_filter($this->input->post('student_classreg_section_name')));


			$studentClassDataArray = explode(',', $studentClassData);
		for ($i = 0; $i < sizeof($studentDataArray); $i++) {
				$data['classreg_section_id'] = $this->input->post('classreg_section_id');
				$data['student_id'] = $studentDataArray[$i];
				$data['student_classreg_section_isActive'] = 1;
				$inactive['student_classreg_section_isActive'] = 0;
				$data['student_classreg_section_name'] = $studentClassDataArray[$i];
				$result = $this->MainModel->updateData('student_id', $studentDataArray[$i], 'student_classreg_section_com', $inactive);
				$result = $this->MainModel->insertData('student_classreg_section_com', $data);
			}

			if ($result) {
				$data['relationMessage'] = "student relation with class added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('student-class-section-multiple-relation');
			}
		}
else {
	$classData = $this->MainModel->getDataRow('classreg_section_id', $class_id, 'student_classreg_section_com', '*');
	if ($classData > 0) {
		$this->MainModel->deleteData('classreg_section_id', $class_id, 'student_classreg_section_com');
	}
	$data['relationMessage'] = "You dont add any information in database !!!!!!!";
	$this->session->set_userdata($data);
	redirect('student-class-section-multiple-relation');


}


	}




	public function multipleStudentRelationForm(){


		$data['title'] = "Admit student to class";
		$data['main'] = "Admit student";
		$data['active'] = "Add student to class ";
		$data['classSections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
		$data['pageContent'] = $this->load->view('management/StudentClassRelation/studentClassRelation_Multiple_Form', $data, true);
		$this->load->view('layouts/main', $data);
	}



	public function StudentSelection()
	{
		$classreg_sectionId = $this->input->post('classreg_section_id');
		$sessionId = $this->input->post('session_id');

		$query = "select students.*,student_classreg_section_com.*,students.student_id as studentId ,student_classreg_section_com.student_id as student_classId ,students.student_name from student_classreg_section_com join
 students on students.student_id=student_classreg_section_com.student_id 
where classreg_section_id=$classreg_sectionId and session_id=$sessionId and student_classreg_section_com.student_classreg_section_isActive=1";
		$students = $this->MainModel->AllQueryDalta($query);
		//var_dump($students);exit();
		echo json_encode($students);
	}


	public function MultipleStudentSelection()
	{
		$classreg_sectionId = $this->input->post('classreg_section_id');
		$sessionId = $this->input->post('session_id');

		$query = " select student_classreg_section_com.student_id as student_com_id,students.student_id,students.student_name,student_classreg_section_com.student_classreg_section_name from students 
left join student_classreg_section_com on students.student_id=student_classreg_section_com.student_id 
where student_classreg_section_com.student_id is null
and student_classreg_section_com.student_classreg_section_isActive is null
 or student_classreg_section_com.student_classreg_section_isActive=0
union
SELECT  student_classreg_section_com.student_id as student_com_id,students.student_id,students.student_name ,student_classreg_section_com.student_classreg_section_name FROM schoole_management_db.student_classreg_section_com 
join students on student_classreg_section_com.student_id=students.student_id
where student_classreg_section_com.classreg_section_id=$classreg_sectionId and student_classreg_section_com.session_id=$sessionId and student_classreg_section_com.student_classreg_section_isActive=1";
		$students = $this->MainModel->AllQueryDalta($query);
		//var_dump($students);exit();
		echo json_encode($students);
	}


	public function edit($id)
	{
		$data['studentClassRelation'] = $this->MainModel->getSingleData('student_classreg_section_id', $id, 'student_classreg_section_com', '*');
		$studentClassId = $data['studentClassRelation']->student_classreg_section_id;
		$data['classSectionRelations'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');

		if (isset($studentClassId)) {
			$data['title'] = "Studnet and class relation update page ";
			$data['main'] = "Studnet  Class and Section relation";
			$data['active'] = "update Studnet  class ,section relation";
			$data['pageContent'] = $this->load->view('management/studentClassRelation/studentClassRelation_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-class-list');
		}

	}

	public function update()
	{
		$studentClassSectionRelationId = $this->input->post('student_classreg_section_id');

		$studentClassData = $this->MainModel->getSingleData('student_classreg_section_id', $studentClassSectionRelationId, 'student_classreg_section_com', '*');

		$studentClassId = $studentClassData->student_classreg_section_id;

		if (isset($studentClassId)) {

			$data['classreg_section_id'] = $this->input->post('classreg_section_id');
			$data['student_id'] = $this->input->post('student_id');
			$data['student_classreg_section_name'] = $this->input->post('student_classreg_section_name');

			$this->form_validation->set_rules('student_classreg_section_name', 'Teacher  name', 'required');
			$this->form_validation->set_rules('student_id', 'Teacher  name', 'required');
			$this->form_validation->set_rules('classreg_section_id', 'shift name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('student_classreg_section_id', $studentClassId, 'student_classreg_section_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Student  relation with class and section updated successfully !!!!");
					redirect('student-class-section-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('student-class-section-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-class-section-list');
		}

	}
	public function sectionData()
	{
		$section_id = $this->input->post('section_id');
	$classreg_id = $this->input->post('classreg_id');
		$query = "select class_registrations.classreg_name,sections.section_name,sessions.session_name,student_name,student_father_name,student_phone from student_classreg_section_com 
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join sections on sections.section_id=classreg_section_com.section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id 
join sessions on sessions.session_id=student_classreg_section_com.session_id
join students on students.student_id=student_classreg_section_com.student_id
where class_registrations.classreg_id=$classreg_id and sections.section_id=$section_id and  student_classreg_section_com.student_classreg_section_isActive=1
";

		$data['students'] = $this->MainModel->AllQueryDalta($query);
		$i=0;
		foreach ($data['students'] as $student){
			$i++;
		}
		$data['total']=$i;

		echo json_encode($data);
	}

	public function classData()
	{
		$classreg_id = $this->input->post('classreg_id');
		$query = "
select class_registrations.classreg_name,sections.section_name,sessions.session_name,student_father_name,student_name,student_phone from student_classreg_section_com 
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join sections on sections.section_id=classreg_section_com.section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id 

join sessions on sessions.session_id=student_classreg_section_com.session_id
join students on students.student_id=student_classreg_section_com.student_id
where class_registrations.classreg_id=$classreg_id and student_classreg_section_com.student_classreg_section_isActive=1
";
		$clases = $this->MainModel->AllQueryDalta($query);
		echo json_encode($clases);


	}


	public function sessionData()
	{
		$section_id = $this->input->post('section_id');
		$classreg_id = $this->input->post('classreg_id');
		$session_id = $this->input->post('session_id');
		$query = "select class_registrations.classreg_name,sections.section_name,student_father_name,sessions.session_name,student_name,student_phone from student_classreg_section_com 
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join sections on sections.section_id=classreg_section_com.section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id 
join sessions on sessions.session_id=student_classreg_section_com.session_id
join students on students.student_id=student_classreg_section_com.student_id
where class_registrations.classreg_id=$classreg_id and sections.section_id=$section_id and  student_classreg_section_com.session_id=$session_id and    student_classreg_section_com.student_classreg_section_isActive=1
";
		$data['subjects'] = $this->MainModel->AllQueryDalta($query);
		$i=0;
		foreach ($data['subjects'] as $subject){
			$i++;
		}
		$data['total']=$i;
		echo json_encode($data);


	}

//	public function studentReport()
//	{
//		$section_id = $this->input->post('section_id');
//		$classreg_id = $this->input->post('classreg_id');
//		$session_id = $this->input->post('session_id');
//		$query = "select * from student_classreg_section_com  join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id order by student_classreg_section_id DESC";
//		$data['studentClassSectionRelations'] = $this->MainModel->AllQueryDalta($query);
//		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
//		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
//		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
//		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');
//		$query = "select class_registrations.classreg_name,sections.section_name,sessions.session_name,student_name,student_father_name,student_phone from student_classreg_section_com
//join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
//join sections on sections.section_id=classreg_section_com.section_id
//join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
//join sessions on sessions.session_id=student_classreg_section_com.session_id
//join students on students.student_id=student_classreg_section_com.student_id
//where class_registrations.classreg_id=$classreg_id and sections.section_id=$section_id and  student_classreg_section_com.session_id=$session_id and    student_classreg_section_com.student_classreg_section_isActive=1
//";
//		$data['studentClassSectionRelations'] = $this->MainModel->AllQueryDalta($query);
////		$data['pageContent'] = $this->load->view('management/Marks/classWiseMark', $data, true);
////		$this->load->view('layouts/main', $data);
//		$this->pdf->load_view('management/StudentClassRelation/studentReport',$data);
//		$this->pdf->render();
//		$this->pdf->stream("mark.pdf");
//
//	}
	public  function studentClassSectionReport(){
		$data['main'] = "Student report";
		$data['active'] = "view student report ";

		$section_id = $this->input->post('section_id');
		$classreg_id = $this->input->post('classreg_id');
		$session_id = $this->input->post('session_id');
				$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');

		$query="select * from  students join student_classreg_section_com on student_classreg_section_com.student_id=students.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join sections on sections.section_id=classreg_section_com.section_id
join sessions on sessions.session_id=student_classreg_section_com.session_id 
where student_classreg_section_com.student_classreg_section_isActive=1 and sessions.session_id=$session_id and sections.section_id=$section_id and class_registrations.classreg_id=$classreg_id";

		$data['studentClassSectionRelations'] = $this->MainModel->AllQueryDalta($query);
		$i=0;
		foreach ($data['studentClassSectionRelations'] as $students){
			$i++;
		}
		$data['total']=$i;
		$data['pageContent'] = $this->load->view('management/StudentClassRelation/studentReport', $data, true);
		$this->load->view('layouts/main', $data);


	}




	public function destroy($id)
	{
		$studentClassData = $this->MainModel->getSingleData('student_classreg_section_id', $id, 'student_classreg_section_com', '*');
		$studentClassId = $studentClassData->student_classreg_section_id;
		if (isset($studentClassId)) {
			$result = $this->MainModel->deleteData('student_classreg_section_id', $studentClassId, 'student_classreg_section_com');
			if ($result) {
				$this->session->set_flashdata('message', "Student relation with class and section deleted successfully !!!!");
				redirect('student-class-section-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('student-class-section-list');
		}
	}

}
