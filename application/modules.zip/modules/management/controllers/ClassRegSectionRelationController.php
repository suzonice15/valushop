<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClassRegSectionRelationController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		//$this->load->model('Management/classRegSectionRelation');
	//	$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "Class report";
		$data['active'] = "view class report";
		$query = "select classreg_section_com.*, class_registrations.classreg_name as class_name , sections.section_name as section_name from classreg_section_com 
 				join class_registrations on classreg_section_com.classreg_id=class_registrations.classreg_id join
 				sections on classreg_section_com.section_id=sections.section_id order by  classreg_section_com.classreg_section_id desc
				";
		$data['classRelation'] = $this->MainModel->AllQueryDalta($query);
		$data['classes'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');

		$data['pageContent'] = $this->load->view('management/classRegSectionRelation/classRegSectionRelation_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Class & section relation registration form ";
		$data['main'] = "Class & Section Relation";
		$data['active'] = "Add Class & section  relation";
		$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['section'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
		$data['pageContent'] = $this->load->view('management/classRegSectionRelation/classRegSectionRelation_create', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function store()
	{


		$data['classreg_id'] = $this->input->post('classreg_id');
		$data['section_id'] = $this->input->post('section_id');
		$data['classreg_section_name'] = $this->input->post('classreg_section_name');

		$this->form_validation->set_rules('classreg_section_name', 'Class  name', 'required');
		$this->form_validation->set_rules('classreg_id', 'Class  name', 'required');
		$this->form_validation->set_rules('section_id', 'Section  name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('classreg_section_com', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Class relation with section added successfully !!!!");
				redirect('class-section-list');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('class-section-create');
		}


	}

	public function show($id)
	{

	}

	public function multipleDataStore($sectionId)
	{
		$query = "select * from classreg_section_com  right join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
where class_registrations.classreg_id
=$sectionId";
		$data['classSectionRelations'] = $this->MainModel->AllQueryDalta($query);
	//	var_dump($data);exit();
		$data['title'] = "Class  and section relation registration form ";
		$data['main'] = "Class & Section relation";
		$data['active'] = "Add class & section relation";
		//$data['class'] = $this->MainModel->getSingleData('class_reg_id', $classId, 'class_registrations', '*');

		//$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'class_reg_id DESC');
		$data['sections'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');
		$data['pageContent'] = $this->load->view('management/classRegSectionRelation/classRegSectionRelation_multiple_store', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function multipleDataInsertInDB()
	{
		$sectionDataArray = array();
		$classSectionNames = array();
		$data['classreg_id'] = $this->input->post('classreg_id');
		$classId = $this->input->post('classreg_id');
		$sectionId=$this->input->post('section_id');
		if($sectionId) {
			$sectionData = implode(',', $this->input->post('section_id'));
			$classSectionData = implode(',', array_filter($this->input->post('classreg_section_name')));
			$sectionDataArray = explode(',', $sectionData);
			$classSectionNames = explode(',', $classSectionData);

			$classDataId = $this->MainModel->getDataRow('classreg_id', $classId, 'classreg_section_com', '*');
			if ($classDataId > 0) {
				$this->MainModel->deleteData('classreg_id', $classId, 'classreg_section_com');
			}
			for ($i = 0; $i < sizeof($sectionDataArray); $i++) {
				$data['section_id'] = $sectionDataArray[$i];
				$data['classreg_section_name'] = $classSectionNames[$i];
				$data['classreg_section_isActive'] = 1;
				$result = $this->MainModel->insertData('classreg_section_com', $data);

			}

			if ($result) {
				$data['relationMessage'] = "Multiple Class relation with session added successfully !!!!";
				$this->session->set_userdata($data);
				redirect('class-list');
			}
		}
		else{

			$classDataId = $this->MainModel->getDataRow('classreg_id', $classId, 'classreg_section_com', '*');
			if ($classDataId > 0) {
				$this->MainModel->deleteData('classreg_id', $classId, 'classreg_section_com');
			}
			$data['relationMessage'] = "You dont add any content to database !!!!";
			$this->session->set_userdata($data);
			redirect('class-list');
		}


	}
	public function edit($id)
	{
		$data['ClassRelation'] = $this->MainModel->getAllData("classreg_id=$id", 'classreg_section_com', '*', 'classreg_id DESC');
		//var_dump($data);exit();
		//$classReg_section_id = $data['ClassRelation']->classreg_section_id;
		$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['section'] = $this->MainModel->getAllData('', 'sections', '*', 'section_id DESC');

		//if (isset($classReg_section_id)) {
		$data['title'] = "Class relation update page ";
		$data['main'] = "Class relation";
		$data['second'] = "Class relation option";
		$data['active'] = "Update Class relation";
		$data['pageContent'] = $this->load->view('management/classRegSectionRelation/classRegSectionRelation_edit', $data, true);
		$this->load->view('layouts/main', $data);
		/*} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('class-section-list');
		}*/

	}

	public function update()
	{
		$classReg_section_id = $this->input->post('classreg_section_id');
		// check if the element exists before trying to edit it
		$ClassRelation = $this->MainModel->getSingleData('classreg_section_id', $classReg_section_id, 'classreg_section_com', '*');
		$classReg_section_id = $ClassRelation->classreg_section_id;

		if (isset($classReg_section_id)) {
			$data['classreg_id'] = $this->input->post('classreg_id');
			$data['section_id'] = $this->input->post('section_id');
			$data['classreg_section_name'] = $this->input->post('classreg_section_name');


			$this->form_validation->set_rules('classreg_id', 'Class relation name', 'required');
			$this->form_validation->set_rules('section_id', 'Class relation name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('classreg_section_id', $classReg_section_id, 'classreg_section_com', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Class relation with section updated successfully !!!!");
					redirect('class-section-list');
				}
			} else {

				$this->session->set_flashdata('error', "value reqiured");
				redirect('class-section-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('class-section-list');
		}

	}

	public function destroy($id)
	{
		$ClassRelation = $this->MainModel->getSingleData('classreg_id', $id, 'classreg_section_com', '*');
		$classReg_section_id = $ClassRelation->classreg_id;
		if (isset($classReg_section_id)) {
			$result = $this->MainModel->deleteData('classreg_id', $classReg_section_id, 'classreg_section_com');
			if ($result) {
				$this->session->set_flashdata('message', "Class relation with section deleted successfully !!!!");
				redirect('class-section-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('class-section-list');
		}
	}

	public function selector()
	{
	redirect(base_url() . 'Management/classRegSectionRelationController/multipleDataStore/'.$this->input->post('$classreg_id'));

	}

}
