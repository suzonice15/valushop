<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SatingesController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->library('form_validation');
		$this->load->library('image_lib');
	}



	public function create()
	{
		$data['title'] = "Software sating Update form ";
		$data['main'] = "Software sating";
		$data['active'] = "Update Software sating";
        $data['sating'] = $this->MainModel->getSingleData('satinge_id', '1', 'satinge', '*');
        $data['pageContent'] = $this->load->view('management/satinges/satinges_create', $data, true);
		$this->load->view('layouts/main', $data);
	}



	public function update()
	{


			$old_satinge_logo=$this->input->post('old_satinge_logo');
			$data['satinge_logo']=$this->input->post('old_satinge_logo');
			if(isset($_FILES["satinge_logo"]["name"]))
			{
				if((($_FILES["satinge_logo"]["type"]=="image/jpg") || ($_FILES["satinge_logo"]["type"]=="image/jpeg") || ($_FILES["satinge_logo"]["type"]=="image/png") || ($_FILES["satinge_logo"]["type"]=="image/gif"))){
					if(!empty($old_satinge_logo)){
						unlink($old_satinge_logo);

					}
					$uploaded_image_path = "uploads/".time().'-'.$_FILES["satinge_logo"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["satinge_logo"]["error"] > 0) {
						echo "Return Code: " . $_FILES["satinge_logo"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["satinge_logo"]["tmp_name"],$uploaded_image_path);
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 500;
						$config['height'] = 390;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['satinge_logo']=$uploaded_image_path;

					}
				}
			}
		$data['satinge_name'] = $this->input->post('satinge_name');
		$data['satinge_slug'] = $this->input->post('satinge_slug');
		$data['satinge_mobile'] = $this->input->post('satinge_mobile');
		$data['satinge_email'] = $this->input->post('satinge_email');
		$data['satinge_address'] = $this->input->post('satinge_address');
			$this->form_validation->set_rules('satinge_name', 'Software satings name', 'required');
			$this->form_validation->set_rules('satinge_slug', 'Software satings name', 'required');
			$this->form_validation->set_rules('satinge_mobile', 'Software satings name', 'required');
			$this->form_validation->set_rules('satinge_email', 'Software satings name', 'required');
			$this->form_validation->set_rules('satinge_address', 'Software satings name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('satinge_id', 1, 'satinge', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Software satings updated successfully !!!!");
					redirect('sating-create');
				}
			} else {

                $this->session->set_flashdata('message', "value reqiured");
                redirect('sating-create');
			}


	}

//	public function destroy($id)
//	{
//		$Software satingsData = $this->MainModel->getSingleData('Software satings_id', $id, 'Software satings', '*');
//		$Software satingsId = $Software satingsData->Software satings_id;
//		if (isset($Software satingsId)) {
//			$result = $this->MainModel->deleteData('Software satings_id', $Software satingsId, 'Software satings');
//			if ($result) {
//				$this->session->set_flashdata('message', "Software satings deleted successfully !!!!");
//				redirect('Software satings-list');
//			}
//		} else {
//			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
//			redirect('Software satings-list');
//		}
//	}
}
