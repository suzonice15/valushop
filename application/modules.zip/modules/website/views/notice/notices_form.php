<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label"> Notice Name<span style="color:red">*</span></label>

    <div class="col-sm-9">
        <input type="text"  value="<?php if (isset($galery)) echo $galery->notice_name; ?>"
               class="form-control" name="notice_name" placeholder="Provide notice name">

        <input type="hidden" id="field-1" name="notice_id"
               value="<?php if (isset($galery)) echo $galery->notice_id; ?>" class="form-control">
    </div>
</div>
<?php if(!empty($galery->notice_pdf)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-2 control-label">Notice pdf/docx</label>
		<div class="col-sm-9">
			<iframe src="<?php echo base_url(); if(isset($galery)){ echo $galery->notice_pdf;} ?>" width="300" height="400" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%;" allowfullscreen> </iframe>

			<input type="hidden"  class="form-control" name="old_notice_pdf" value="<?php  if(isset($galery)){ echo $galery->notice_pdf;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Notice pdf/docx</label>
	<div class="col-sm-9">
		<input type="file"  class="form-control" name="notice_pdf">
	</div>
</div>
