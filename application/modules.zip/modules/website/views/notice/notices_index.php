
<div class="col-md-offset-1 col-md-10">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-success" href="<?php echo base_url();?>galery-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
				<th>Name</th>
				<th>pdf</th>

				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($notices)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($notices as $slider):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $slider->notice_name; ?></td>
						<td><?php
							if(!empty($slider->notice_pdf)):
								?>
								<iframe src="<?php echo base_url();echo $slider->notice_pdf; ?>" width="300" height="400" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%;" allowfullscreen> </iframe>
							<?php
							else:
								?>
								<img width="70" height="50"  src="<?php echo base_url() ?>uploads/teachers/teacher.png"/>
							<?php endif;
							?></td>


<td>
	<?php if($slider->notice_active==1) :?>
	<a href="<?php echo base_url() ?>notice-active/<?php echo $slider->notice_id; ?>"
	<span class="glyphicon glyphicon-arrow-up btn btn-info"></span>
	<?php else : ?>
	<a href="<?php echo base_url() ?>notice-active/<?php echo $slider->notice_id; ?>"
	<span class="glyphicon glyphicon-arrow-down btn btn-dropbox"></span>
	<?php endif;?>

	</a>
	<a href="<?php echo base_url() ?>notice-edit/<?php echo $slider->notice_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>

							<a href="<?php echo base_url() ?>notice-delete/<?php echo $slider->notice_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>


						</td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
