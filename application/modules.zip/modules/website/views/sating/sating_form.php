<div class="form-group">
	<label class="col-sm-3 control-label" for="exampleFormControlTextarea1">About Amana Agro Science</label>
	<div class="col-sm-9">
	<textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  name="satting_about_company" rows="9"><?php echo $sating->satting_about_company;?></textarea>
</div>
</div>

<div class="form-group">
	<label class="col-sm-3 control-label" for="exampleFormControlTextarea1">Welcome to  Amana Agro Science product</label>
	<div class="col-sm-9">
		<textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  name="satting_about_product" rows="9"><?php echo $sating->satting_about_product;?></textarea>
	</div>
</div>
<div class="form-group">
	<label class="col-sm-3 control-label" for="exampleFormControlTextarea1">Statistics of Amana Agro Science </label>
	<div class="col-sm-9">
		<textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  name="satting_about_satatics" rows="9"><?php echo $sating->satting_about_satatics;?></textarea>
	</div>
</div>
<input type="text" name="satting_id" value="<?php echo $sating->satting_id?>">



