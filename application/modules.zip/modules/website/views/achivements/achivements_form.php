<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label"> Name<span style="color:red">*</span></label>

    <div class="col-sm-8">
        <input type="text" id="field-1" value="<?php if (isset($galery)) echo $galery->achivement_name; ?>"
               class="form-control" name="achivement_name" placeholder="Provide achivement name">

        <input type="hidden" id="field-1" name="achivement_id"
               value="<?php if (isset($galery)) echo $galery->achivement_id; ?>" class="form-control">
    </div>
</div>

<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label"> Description<span style="color:red">*</span></label>

    <div class="col-sm-8">
        <textarea type="text"
               class="form-control"  rows="20" cols="20" name="achivement_description" placeholder="Provide achivement name"><?php if (isset($galery)) echo $galery->achivement_description; ?></textarea>
       
    </div>
</div>
<?php if(!empty($galery->achivement_picture)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-3 control-label">achivement picture</label>
		<div class="col-sm-8">
			<img width="70" height="50" src="<?php echo base_url(); if(isset($galery)){ echo $galery->achivement_picture;} ?>"/>

			<input type="hidden"  class="form-control" name="old_achivement_picture" value="<?php  if(isset($galery)){ echo $galery->achivement_picture;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">achivement picture</label>
	<div class="col-sm-8">
		<input type="file"  class="form-control" name="achivement_picture">
	</div>
</div>
