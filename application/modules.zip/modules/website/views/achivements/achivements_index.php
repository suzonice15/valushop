
<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-success" href="<?php echo base_url();?>achivement-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Serial</th>
				<th>Picture</th>
								<th>Name</th>
								<th>Description</th>


				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($sliders)):

				$count = 0;
				//var_dump($count);exit();
				foreach ($sliders as $slider):

					?>
					<tr>
						<td><?php echo ++$count; ?></td>
						<td><?php
							if(!empty($slider->achivement_picture)):
								?>
								<img width="70" height="50" src="<?php echo base_url();echo $slider->achivement_picture; ?>"/>
							<?php
							else:
								?>
								<img width="70" height="50"  src="<?php echo base_url() ?>uploads/teachers/teacher.png"/>
							<?php endif;
							?></td>
												
						<td><?php echo $slider->achivement_name; ?></td>
												<td><?php echo $slider->achivement_description; ?></td>



<td>
							<a href="<?php echo base_url() ?>achivement-edit/<?php echo $slider->achivement_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url()?>achivement-delete/<?php echo $slider->achivement_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>


						</td>

					</tr>

					<?php
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
