<div class="form-group">
    <label for="field-1" class="col-sm-4 control-label">Member Name<span style="color:red">*</span></label>

    <div class="col-sm-8">
        <input type="text" id="field-1" value="<?php if (isset($marketer)) echo $marketer->marketer_name; ?>"
               class="form-control" name="marketer_name" placeholder="Provide member name">
        <span id="spanId" style="color:red"> <?php echo form_error('marketer_name');  ?></span>

        <input type="hidden" id="field-1" name="marketer_id"
               value="<?php if (isset($marketer)) echo $marketer->marketer_id; ?>" class="form-control">
    </div>
</div>


<div class="form-group">
    <label for="field-1" class="col-sm-4 control-label">Member Phone number<span style="color:red">*</span></label>

    <div class="col-sm-8">
        <input type="text" id="field-1" value="<?php if (isset($marketer)) echo $marketer->marketer_mobile; ?>"
               class="form-control" name="marketer_mobile" placeholder="Provide member phone">

        <span id="spanId" style="color:red"> <?php echo form_error('marketer_mobile');  ?></span>
    </div>
</div>
<div class="form-group">
    <label for="field-1" class="col-sm-4 control-label">Member email <span style="color:red"></span></label>

    <div class="col-sm-8">
        <input type="text" id="field-1" value="<?php if (isset($marketer)) echo $marketer->marketer_email; ?>"
               class="form-control" name="marketer_email" placeholder="Provide member email">

    </div>
</div>


<div class="form-group">
	<label for="field-1" class="col-sm-4 control-label">Member address <span style="color:red"></span></label>

	<div class="col-sm-8">
		<input type="text" id="field-1" value="<?php if (isset($marketer)) echo $marketer->marketer_address; ?>"
			   class="form-control" name="marketer_address" placeholder="Provide Member address">

	</div>
</div>
<div class="form-group">
	<label  class="col-sm-4 control-label">Designation <span style="color:red"> </span></label>
	<div class="col-md-8">
		<select required name="designation_id" class="form-control select2" id="teacher_title" class="form-control">
			<option value="">Select Job title</option>
			<?php if(isset($designations)): foreach ($designations as $designation):?>
				<option value="<?php echo $designation->designation_id;?>"><?php echo $designation->designation_name;?></option>
			<?php endforeach;endif;?>



		</select>
	</div>

</div>


<div class="form-group">
	<label for="field-1" class="col-sm-4 control-label">Member Status <span style="color:red"></span></label>

	<div class="col-sm-8">
		<select name="marketer_status" class="form-control">
			<option> select member type</option>
			<option value="1"> Departmental man</option>
			<option value="2"> Govornor Body man</option>
		</select>

	</div>
</div>



<?php if(!empty($marketer->marketer_picture_path)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-4 control-label">Member picture</label>
		<div class="col-sm-8">
			<img width="70" height="50" src="<?php echo base_url(); if(isset($marketer)){ echo $marketer->marketer_picture_path;} ?>"/>

			<input type="hidden"  class="form-control" name="old_marketer_picture_path" value="<?php  if(isset($marketer)){ echo $marketer->marketer_picture_path;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-4 control-label">Member picture</label>
	<div class="col-sm-8">
		<input type="file"  class="form-control" name="marketer_picture_path">
	</div>
</div>






					
