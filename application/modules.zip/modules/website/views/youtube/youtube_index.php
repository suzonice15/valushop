
<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-success" href="<?php echo base_url();?>youtube-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">
<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Video Name</th>
				<th>Video</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($youtubes)):

				$count = 1;
				//var_dump($count);exit();
				foreach ($youtubes as $youtube):

					?>
					<tr>
						<td><?php echo $count; ?></td>
						<td><?php echo $youtube->youtube_name; ?></td>
						<td>

							<iframe src="<?php echo $youtube->youtube_video; ?>" allow="autoplay; encrypted-media" allowfullscreen="" width="200" height="200" frameborder="0"></iframe>

						</td>



<td>
							<a href="<?php echo base_url() ?>youtube-edit/<?php echo $youtube->youtube_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>
							<a href="<?php echo base_url() ?>youtube-delete/<?php echo $youtube->youtube_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>


						</td>

					</tr>

					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>
	</div>
	</div>

</div>
</div>
