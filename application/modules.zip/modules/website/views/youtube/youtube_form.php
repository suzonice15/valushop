<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label">Youtube Video Name<span style="color:red">*</span></label>

    <div class="col-sm-8">
        <input type="text" id="field-1" value="<?php if (isset($youtube)) echo $youtube->youtube_name; ?>"
               class="form-control" name="youtube_name" placeholder="Provide Youtube Video Name">

        <input type="hidden" id="field-1" name="youtube_id"
               value="<?php if (isset($youtube)) echo $youtube->youtube_id; ?>" class="form-control">
    </div>
</div>


<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Youtube Video Link<span style="color:red">*</span></label>

	<div class="col-sm-8">
		<input type="text" id="field-1" value="<?php if (isset($youtube)) echo $youtube->youtube_video; ?>"
			   class="form-control" name="youtube_video" placeholder="Provide Youtube Video Link">


	</div>
</div>

