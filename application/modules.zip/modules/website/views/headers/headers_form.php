<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label">Madrasah  Name<span style="color:red"> *</span></label>

    <div class="col-sm-8">
        <input type="text"   name="header_one" value="<?php if (isset($header)){ echo $header->header_one; }?>"
               class="form-control" >


    </div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Madrasah Arabic name<span style="color:red"> *</span></label>

	<div class="col-sm-8">
		<input type="text" name="header_arrabic" value="<?php if (isset($header)) echo $header->header_arrabic; ?>"
			   class="form-control"  >

	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Madrasah address<span style="color:red"> *</span></label>

	<div class="col-sm-8">
		<input type="text" name="header_address" value="<?php if (isset($header)) echo $header->header_address; ?>"
			   class="form-control"  >

	</div>
</div>


<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label">Madrasah location<span style="color:red"> *</span></label>

    <div class="col-sm-8">
        <input type="text" name="header_two" value="<?php if (isset($header)) echo $header->header_two; ?>"
               class="form-control"  >

    </div>
</div>


<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label"> Mobile <span style="color:red"> *</span></label>

    <div class="col-sm-8">
        <input type="text" name="header_mobile"  value="<?php if (isset($header)) echo $header->header_mobile; ?>"
               class="form-control" >

    </div>
</div>


<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label"> Email<span style="color:red"> *</span></label>

    <div class="col-sm-8">
        <input type="text" name="header_email" value="<?php if (isset($header)) echo $header->header_email; ?>"
               class="form-control"  >

    </div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Google location<span style="color:red"> *</span></label>

	<div class="col-sm-8">
		<textarea type="text" name="header_location" value=""
			   class="form-control"  ><?php if (isset($header)) echo $header->header_location; ?>
		</textarea>

	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Welcome text </label>
	<div class="col-sm-8">
			 <textarea id="editor1" name="welcome" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->welcome; ?>
                    </textarea>
	</div>

</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Facebook Link  </label>

	<div class="col-sm-8">
		<input type="text"   name="front_end_setting_facebook" value="<?php if (isset($header)){ echo $header->front_end_setting_facebook; }?>"
			   class="form-control" >


	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Twiter Link</label>

	<div class="col-sm-8">
		<input type="text"   name="front_end_setting_twiter" value="<?php if (isset($header)){ echo $header->front_end_setting_twiter; }?>"
			   class="form-control" >


	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Youtube Link</label>

	<div class="col-sm-8">
		<input type="text"   name="front_end_setting_youtube" value="<?php if (isset($header)){ echo $header->front_end_setting_youtube; }?>"
			   class="form-control" >


	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Google plus Link</label>

	<div class="col-sm-8">
		<input type="text"   name="front_end_setting_google" value="<?php if (isset($header)){ echo $header->front_end_setting_google; }?>"
			   class="form-control" >


	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">linkedIn Link</label>

	<div class="col-sm-8">
		<input type="text"   name="front_end_setting_linked" value="<?php if (isset($header)){ echo $header->front_end_setting_linked; }?>"
			   class="form-control" >


	</div>
</div>



<?php if(!empty($header->logo)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-2 control-label">Picture </label>
		<div class="col-sm-8">
			<img width="70" height="50" src="<?php echo base_url(); if(isset($header)){ echo $header->logo;} ?>"/>

			<input type="hidden"  class="form-control" name="old_logo" value="<?php  if(isset($header)){ echo $header->logo;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">logo </label>
	<div class="col-sm-8">
		<input type="file"  class="form-control" name="logo">
	</div>
</div>


<?php if(!empty($header->advicetiment_image)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-2 control-label">Advisement picture </label>
		<div class="col-sm-8">
			<img width="70" height="50" src="<?php echo base_url(); if(isset($header)){ echo $header->advicetiment_image;} ?>"/>

			<input type="hidden"  class="form-control" name="old_advicetiment_image" value="<?php  if(isset($header)){ echo $header->advicetiment_image;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Advisement picture </label>
	<div class="col-sm-8">
		<input type="file"  class="form-control" name="advicetiment_image">
	</div>
</div>





