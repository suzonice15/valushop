
<?php if(!empty($header->principal_picture)):?>
	<div class="form-group">
		<label for="field-1" class="col-sm-2 control-label">Principal picture </label>
		<div class="col-sm-8">
			<img width="70" height="50" src="<?php echo base_url(); if(isset($header)){ echo $header->principal_picture;} ?>"/>

			<input type="hidden"  class="form-control" name="old_principal_picture" value="<?php  if(isset($header)){ echo $header->principal_picture;} ?>">
		</div>
	</div>
<?php endif;?>
<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Principal picture </label>
	<div class="col-sm-8">
		<input type="file"  class="form-control" name="principal_picture">
	</div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">অধ্যক্ষের বাণী</label>
	<div class="col-sm-8">
			 <textarea id="editor1"  name="page_principale_message" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_principale_message; ?>
                    </textarea>
	</div>

</div>


<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">মাদরাসা সম্পর্কে </label>
	<div class="col-sm-8">
			 <textarea id="editor1"  class="textarea" class="textarea" name="page_about" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_about; ?>
                    </textarea>
	</div>

</div>



<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">লক্ষ্য ও উদ্দেশ্য  </label>
	<div class="col-sm-8">
			 <textarea id="editor1" class="textarea" name="page_purpose" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_purpose; ?>
                    </textarea>
	</div>

</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">মূলনীতি </label>
	<div class="col-sm-8">
			 <textarea  id="editor1" class="textarea" name="page_principle" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_principle; ?>
                    </textarea>
	</div>

</div>



<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">শিক্ষা সফর </label>
	<div class="col-sm-8">
			 <textarea id="editor1" class="textarea" name="page_edu_travel" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_edu_travel ; ?>
                    </textarea>
	</div>

</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">ক্লাব </label>
	<div class="col-sm-8">
			 <textarea id="editor1" class="textarea" name="page_club" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_club; ?>
                    </textarea>
	</div>

</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">ক্রীড়া </label>
	<div class="col-sm-8">
			 <textarea id="editor1" class="textarea" name="page_play" rows="20" cols="100">
				 <?php if (isset($header)) echo $header->page_play; ?>
                    </textarea>
	</div>

</div>

