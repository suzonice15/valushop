
<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		<h3 class="box-title"><a class="btn btn-success" href="<?php echo base_url();?>news-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>


	</div>
	<div class="box-body">

		<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Heading</th>
				<th>Description</th>
				<th>news</th>

				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if (isset($news)):

				$count = 0;
				//var_dump($count);exit();
				foreach ($news as $new):

					?>
					<tr>
						<td><?php echo ++$count; ?></td>
						<td><?php echo $new->news_name; ?></td>
						<td><?php echo $new->news_body; ?></td>
						<?php if($new->news_update==1) :?>
							<td>
								<input type="button" value="Update" class="btn btn-block btn-primary btn-xs "/>
							</td>
						<?php else : ?>
							<td>
								<input type="button" value="General" class="btn btn-block btn-info btn-xs "/>
							</td>
						<?php endif;?>


<td>
	<?php if($new->news_update==1) :?>
	<a href="<?php echo base_url() ?>news-active/<?php echo $new->news_id; ?>"
	<span class="glyphicon glyphicon-arrow-up btn btn-info"></span>
	<?php else : ?>
	<a href="<?php echo base_url() ?>news-active/<?php echo $new->news_id; ?>"
	<span class="glyphicon glyphicon-arrow-down btn btn-dropbox"></span>
	<?php endif;?>

	</a>
	<a href="<?php echo base_url() ?>news-edit/<?php echo $new->news_id; ?>"
							<span class="glyphicon glyphicon-edit btn btn-success"></span>
							</a>

							<a href="<?php echo base_url() ?>news-delete/<?php echo $new->news_id; ?>"
							   onclick="return confirm('Are you want to delete this information :press Ok for delete otherwise Cancel')">
								<span class="glyphicon glyphicon-trash btn btn-danger"></span>
							</a>


						</td>

					</tr>

					<?php
				endforeach;
			endif; ?>

			</tbody>

		</table>


	</div>

</div>
</div>
