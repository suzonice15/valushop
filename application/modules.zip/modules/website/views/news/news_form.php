<div class="form-group">
    <label for="field-1" class="col-sm-2 control-label"> News Name<span style="color:red">*</span></label>

    <div class="col-sm-9">
        <input type="text"  value="<?php if (isset($news)) echo $news->news_name; ?>"
               class="form-control" name="news_name" placeholder="Provide news Heading">

        <input type="hidden" id="field-1" name="news_id"
               value="<?php if (isset($news)) echo $news->news_id; ?>" class="form-control">
    </div>
</div>
	<div class="form-group">
		<label for="field-1" class="col-sm-2 control-label">News description</label>
		<div class="col-sm-9">
			 <textarea id="editor1" name="news_body" rows="20" cols="100">
				 <?php if (isset($news)) echo $news->news_body; ?>
                    </textarea>
		</div>

	</div>

<div class="form-group">
	<label for="field-1" class="col-sm-2 control-label">Update status</label>
	<div class="col-sm-9">
		<select name="news_update" class="form-control">
			<option value="0">General </option>
			<option value="1">update</option>

		</select>
	</div>

</div>

