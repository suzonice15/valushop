<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NewsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		$this->load->library('image_lib');
		$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');


	}
	}

	public function index()
	{
		$data['main'] = "News";
		$data['active'] = "News images view";
		$data['news'] = $this->MainModel->getAllData('', 'news', '*', 'news_id DESC');
		$data['pageContent'] = $this->load->view('website/news/news_index', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}

	public function create()
	{
		$data['title'] = "News registration form ";
		$data['main'] = "News";
		$data['active'] = "Add News";
		$data['pageContent'] = $this->load->view('website/news/news_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}


	public function store()
	{




		$data['news_update'] = $this->input->post('news_update');
		$data['news_name'] = $this->input->post('news_name');
		$data['news_body'] = trim($this->input->post('news_body'));
		$this->form_validation->set_rules('news_name', 'galery name','required' );
		$this->form_validation->set_rules('news_body', 'galery name','required' );

		if ($this->form_validation->run() ==true) {
			$result = $this->MainModel->insertData('news', $data);
			if ($result) {
				$this->session->set_flashdata('message', "news added successfully !!!!");
				redirect('news-list');
			}
		} else {
			redirect('news-create');
		}


	}

    public function show($id)
    {

    }

	public function edit($id)
	{

		$data['news'] = $this->MainModel->getSingleData('news_id', $id, 'news', '*');
		$galeryId = $data['news']->news_id;
		if (isset($galeryId)) {
			$data['title'] = "News update page ";
			$data['main'] = "News";
			$data['active'] = "Update News";
			$data['pageContent'] = $this->load->view('website/news/news_edit', $data, true);
			$this->load->view('adminwebsite/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('news-list');
		}

	}

	public function newsActive($id)
	{

		$dataa['notice'] = $this->MainModel->getSingleData('news_id', $id, 'news', '*');
		$galeryId = $dataa['notice']->news_update;
		if ($galeryId==1) {
			$data['news_update'] = 0;

		} else {
			$data['news_update'] = 1;

		}
		$result = $this->MainModel->updateData('news_id', $id, 'news', $data);
		if ($result) {
			$this->session->set_flashdata('message', "news update updated successfully !!!!");
			redirect('news-list');
		}

	}

	public function update()
	{
		$student_id = $this->input->post('news_id');
		$Student = $this->MainModel->getSingleData('news_id', $student_id, 'news', '*');
		$news_idId = $Student->news_id;
		if (isset($news_idId)) {
			$data['news_update'] = $this->input->post('news_update');
			$data['news_name'] = $this->input->post('news_name');
			$data['news_body'] = trim($this->input->post('news_body'));
			$this->form_validation->set_rules('news_name', 'galery name','required' );
			$this->form_validation->set_rules('news_body', 'galery name','required' );
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('news_id', $news_idId, 'news', $data);
				if ($result) {
					$this->session->set_flashdata('message', "news updated successfully !!!!");
					redirect('news-list');
				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('news-update');
			}
		}
		else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('news-list');
		}

	}

	public function destroy($id)
	{
        $memberData = $this->MainModel->getSingleData('news_id', $id, 'news', '*');
		$galeryId = $memberData->news_id;
		if (isset($galeryId)) {
			$result = $this->MainModel->deleteData('news_id', $galeryId, 'news');
			if ($result) {
				$this->session->set_flashdata('message', "news deleted successfully !!!!");
				redirect('news-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('news-list');
		}
	}
}
