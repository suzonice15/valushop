<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HeadersController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->library('form_validation');
		$this->load->library('image_lib');
		$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');
	}
	}



	public function create()
	{
		$data['title'] = "header Update form ";
		$data['main'] = "header";
		$data['active'] = "Update header";
        $data['header'] = $this->MainModel->getSingleData('header_id', '1', 'headers', '*');

        //var_dump($data['header']);exit();

        $data['pageContent'] = $this->load->view('website/headers/headers_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}



	public function update()
	{


			$old_logo=$this->input->post('old_logo');
		$data['logo']=$this->input->post('old_logo');
		$old_advicetiment_image=$this->input->post('old_advicetiment_image');
		$data['advicetiment_image']=$this->input->post('old_advicetiment_image');
			if(isset($_FILES["logo"]["name"]))
			{
				if((($_FILES["logo"]["type"]=="image/jpg") || ($_FILES["logo"]["type"]=="image/jpeg") || ($_FILES["logo"]["type"]=="image/png") || ($_FILES["logo"]["type"]=="image/gif"))){
					if(!empty($old_logo)){
						unlink($old_logo);

					}
					$uploaded_image_path = "uploads/sliders/".time().'-'.$_FILES["logo"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["logo"]["error"] > 0) {
						echo "Return Code: " . $_FILES["logo"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["logo"]["tmp_name"],$uploaded_image_path);
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 500;
						$config['height'] = 390;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['logo']=$uploaded_image_path;

					}
				}
			}
		if(isset($_FILES["advicetiment_image"]["name"]))
		{
			if((($_FILES["advicetiment_image"]["type"]=="image/jpg") || ($_FILES["advicetiment_image"]["type"]=="image/jpeg") || ($_FILES["advicetiment_image"]["type"]=="image/png") || ($_FILES["advicetiment_image"]["type"]=="image/gif"))){
				if(!empty($old_advicetiment_image)){
					unlink($old_advicetiment_image);

				}
				$uploaded_image_path = "uploads/sliders/".time().'-'.$_FILES["advicetiment_image"]["name"];
				$config['allowed_types'] = 'jpg|jpeg|png|gif';
				$this->load->library('upload', $config);
				if ($_FILES["advicetiment_image"]["error"] > 0) {
					echo "Return Code: " . $_FILES["advicetiment_image"]["error"] . "<br />";
				}
				else
				{
					move_uploaded_file ($_FILES["advicetiment_image"]["tmp_name"],$uploaded_image_path);
					$config['image_library'] = 'gd2';
					$config['source_image'] = $uploaded_image_path;
					$config['create_thumb'] = false;
					$config['maintain_ratio'] = FALSE;
					$config['quality'] = '60%';
					$config['width'] = 1585;
					$config['height'] = 803;
					$config['new_image'] = $uploaded_image_path;
					$this->load->library('image_lib', $config);
					$this->image_lib->resize();
					$data['advicetiment_image']=$uploaded_image_path;

				}
			}
		}
		$data['header_one'] = $this->input->post('header_one');
		$data['header_arrabic'] = $this->input->post('header_arrabic');
		$data['header_address'] = $this->input->post('header_address');
		$data['header_location'] = $this->input->post('header_location');
		$data['welcome'] = $this->input->post('welcome');
		$data['header_two'] = $this->input->post('header_two');
		$data['header_mobile'] = $this->input->post('header_mobile');
		$data['header_email'] = $this->input->post('header_email');
		$data['front_end_setting_facebook'] = $this->input->post('front_end_setting_facebook');
		$data['front_end_setting_linked'] = $this->input->post('front_end_setting_linked');
		$data['front_end_setting_twiter'] = $this->input->post('front_end_setting_twiter');
		$data['front_end_setting_google'] = $this->input->post('front_end_setting_google');
		$data['front_end_setting_youtube'] = $this->input->post('front_end_setting_youtube');

		$this->form_validation->set_rules('header_one', 'headers name', 'required');
			$this->form_validation->set_rules('header_two', 'headers name', 'required');
			$this->form_validation->set_rules('header_mobile', 'headers name', 'required');
			$this->form_validation->set_rules('header_email', 'headers name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('header_id', 1, 'headers', $data);
				if ($result) {
					$this->session->set_flashdata('message', "headers updated successfully !!!!");
					redirect('header-create');
				}
			} else {

                $this->session->set_flashdata('message', "value reqiured");
                redirect('header-create');
			}


	}

	public function destroy($id)
	{
		$headersData = $this->MainModel->getSingleData('headers_id', $id, 'headers', '*');
		$headersId = $headersData->headers_id;
		if (isset($headersId)) {
			$result = $this->MainModel->deleteData('headers_id', $headersId, 'headers');
			if ($result) {
				$this->session->set_flashdata('message', "headers deleted successfully !!!!");
				redirect('headers-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('headers-list');
		}
	}
}
