<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PagesController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->library('form_validation');

$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');
			}
			}



	public function create()
	{
		$data['title'] = "Pages Update form ";
		$data['main'] = "Pages";
		$data['active'] = "Update Pages";
        $data['header'] = $this->MainModel->getSingleData('page_id', '1', 'pages', '*');
        $data['pageContent'] = $this->load->view('website/pages/pages_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}



	public function update()
	{




			if(isset($_FILES["principal_picture"]["name"]))
			{
				$old_principal_picture=$this->input->post('old_principal_picture');
				$data['principal_picture']=$this->input->post('old_principal_picture');
				if((($_FILES["principal_picture"]["type"]=="image/jpg") || ($_FILES["principal_picture"]["type"]=="image/jpeg") || ($_FILES["principal_picture"]["type"]=="image/png") || ($_FILES["principal_picture"]["type"]=="image/gif"))){
					if(!empty($old_principal_picture)){
						unlink($old_principal_picture);

					}
					$uploaded_image_path = "uploads/sliders/".time().'-'.$_FILES["principal_picture"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["principal_picture"]["error"] > 0) {
						echo "Return Code: " . $_FILES["principal_picture"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["principal_picture"]["tmp_name"],$uploaded_image_path);
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 500;
						$config['height'] = 390;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['principal_picture']=$uploaded_image_path;

					}
				}
			}


		$data['page_about'] = trim($this->input->post('page_about'));
		$data['page_principle'] = trim($this->input->post('page_principle'));
		$data['page_purpose'] = trim($this->input->post('page_purpose'));
		$data['page_principale_message'] =trim( $this->input->post('page_principale_message'));
		$data['page_play'] = trim($this->input->post('page_play'));
		$data['page_club'] = trim($this->input->post('page_club'));
		$data['page_edu_travel'] = trim($this->input->post('page_edu_travel'));


				$result = $this->MainModel->updateData('page_id', 1, 'pages', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Page updated successfully !!!!");
					redirect('page-create');
				}



	}

	public function destroy($id)
	{
		$headersData = $this->MainModel->getSingleData('headers_id', $id, 'headers', '*');
		$headersId = $headersData->headers_id;
		if (isset($headersId)) {
			$result = $this->MainModel->deleteData('headers_id', $headersId, 'headers');
			if ($result) {
				$this->session->set_flashdata('message', "headers deleted successfully !!!!");
				redirect('headers-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('headers-list');
		}
	}
}
