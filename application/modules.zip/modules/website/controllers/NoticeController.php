<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class NoticeController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		$this->load->library('image_lib');
		$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');


	}
	}

	public function index()
	{
		$data['main'] = "Notice";
		$data['active'] = "Notice  view";
		$data['notices'] = $this->MainModel->getAllData('', 'notice', '*', 'notice_id DESC');
		$data['pageContent'] = $this->load->view('website/notice/notices_index', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}

	public function create()
	{
		$data['title'] = "Notice registration form ";
		$data['main'] = "Notice";
		$data['active'] = "Add Notice";
		$data['pageContent'] = $this->load->view('website/notice/notices_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}


	public function store()
	{


		if (isset($_FILES["notice_pdf"]["name"])) {
			$config['upload_path']          = 'uploads/';
			$config['allowed_types']        = 'pdf|docx';
			$config['max_size']    = 0;

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('notice_pdf'))
			{
				$error = array('error' => $this->upload->display_errors());

				$this->create();
			}
			else
			{
				$pdf = $this->upload->data();
				$data['notice_pdf'] = $config['upload_path'].$pdf['file_name'];
			}
		}

		$data['notice_name'] = $this->input->post('notice_name');
		$this->form_validation->set_rules('notice_name', 'galery name','required' );

		if ($this->form_validation->run() ==true) {
			$result = $this->MainModel->insertData('notice', $data);
			if ($result) {
				$this->session->set_flashdata('message', "notice added successfully !!!!");
				redirect('notice-list');
			}
		} else {
			redirect('notice-create');
		}


	}

    public function show($id)
    {

    }

	public function edit($id)
	{

		$data['galery'] = $this->MainModel->getSingleData('notice_id', $id, 'notice', '*');
		$galeryId = $data['galery']->notice_id;
		if (isset($galeryId)) {
			$data['title'] = "Notice update page ";
			$data['main'] = "Notice";
			$data['active'] = "Update Notice";
			$data['pageContent'] = $this->load->view('website/notice/notices_edit', $data, true);
			$this->load->view('adminwebsite/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('notice-list');
		}

	}

	public function noticeActive($id)
	{

		$dataa['notice'] = $this->MainModel->getSingleData('notice_id', $id, 'notice', '*');
		$galeryId = $dataa['notice']->notice_active;
//		var_dump($galeryId);exit();
		if ($galeryId==1) {
			$data['notice_active'] = 0;

		} else {
			$data['notice_active'] = 1;

		}
		$result = $this->MainModel->updateData('notice_id', $id, 'notice', $data);
		if ($result) {
			$this->session->set_flashdata('message', "notice updated successfully !!!!");
			redirect('notice-list');
		}

	}

	public function update()
	{
		$student_id = $this->input->post('notice_id');
		$Student = $this->MainModel->getSingleData('notice_id', $student_id, 'notice', '*');
		$studentId = $Student->notice_id;


		if (isset($studentId)) {

//			echo '<pre>';
//			print_r($_FILES["notice_pdf"]);exit();
			$old_student_picture_path=$this->input->post('old_notice_pdf');
			$data['notice_pdf']=$this->input->post('old_notice_pdf');
			if(isset($_FILES["notice_pdf"]["name"]))
			{
				if(($_FILES["notice_pdf"]["type"]=="application/pdf")){
					if(!empty($old_notice_pdf)){
						unlink($old_notice_pdf);

					}
					$uploaded_image_path = "uploads/".$_FILES["notice_pdf"]["name"];
					$config['allowed_types'] = 'pdf';
					$this->load->library('upload', $config);
					if ($_FILES["notice_pdf"]["error"] > 0) {
						echo "Return Code: " . $_FILES["notice_pdf"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["notice_pdf"]["tmp_name"],$uploaded_image_path);

						$data['notice_pdf']=$uploaded_image_path;

					}
				}
			}


			$data['notice_name'] = $this->input->post('notice_name');
			$this->form_validation->set_rules('notice_name', 'galery name','required' );
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('notice_id', $student_id, 'notice', $data);
				if ($result) {
					$this->session->set_flashdata('message', "notice updated successfully !!!!");
					redirect('notice-list');
				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('notice-update');
			}
		}
		else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('notice-list');
		}

	}

	public function destroy($id)
	{
        $memberData = $this->MainModel->getSingleData('notice_id', $id, 'notice', '*');
		$galeryId = $memberData->notice_id;
		if (isset($galeryId)) {
			$result = $this->MainModel->deleteData('notice_id', $galeryId, 'notice');
			if ($result) {
				$this->session->set_flashdata('message', "notice deleted successfully !!!!");
				redirect('notice-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('notice-list');
		}
	}
}
