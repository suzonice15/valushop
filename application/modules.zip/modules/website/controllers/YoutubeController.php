<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class YoutubeController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		
		$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');

	}
	}

	public function index()
	{
		$data['main'] = "Youtube";
		$data['active'] = "Youtube view";
		$data['youtubes'] = $this->MainModel->getAllData('', 'youtube', '*', 'youtube_id DESC');
		$data['pageContent'] = $this->load->view('website/youtube/youtube_index', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}

	public function create()
	{
		$data['title'] = "Youtube registration form ";
		$data['main'] = "Youtube";
		$data['active'] = "Add Youtube";
		$data['pageContent'] = $this->load->view('website/youtube/youtube_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}


	public function store()
	{


		$data['youtube_name'] = $this->input->post('youtube_name');
		$data['youtube_video'] = $this->input->post('youtube_video');
		$this->form_validation->set_rules('youtube_video', 'link name','required' );
		$this->form_validation->set_rules('youtube_name', 'link name','required' );

		if ($this->form_validation->run() ==true) {
			$result = $this->MainModel->insertData('youtube', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Youtube video added successfully !!!!");
				redirect('youtube-list');
			}
		} else {
			redirect('youtube-list');
		}


	}



	public function edit($id)
	{

		$data['youtube'] = $this->MainModel->getSingleData('youtube_id', $id, 'youtube', '*');
		$memberId = $data['youtube']->youtube_id;
		if (isset($memberId)) {
			$data['title'] = "Youtube update page ";
			$data['main'] = "Youtube";
			$data['active'] = "Update Youtube";
			$data['pageContent'] = $this->load->view('website/youtube/youtube_edit', $data, true);
			$this->load->view('adminwebsite/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('youtube-list');
		}

	}

	public function update()
	{
		$memberId = $this->input->post('youtube_id');

		$memberData = $this->MainModel->getSingleData('youtube_id', $memberId, 'youtube', '*');
		$memberId = $memberData->youtube_id;

		if (isset($memberId)) {
			$data['youtube_name'] = $this->input->post('youtube_name');
			$data['youtube_video'] = $this->input->post('youtube_video');
			$this->form_validation->set_rules('youtube_video', 'link name','required' );
			$this->form_validation->set_rules('youtube_name', 'link name','required' );

			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('youtube_id', $memberId, 'youtube', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Youbue viedo updated successfully !!!!");
					redirect('youtube-list');
				}
			} else {

               $this->edit();
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('youtube-list');
		}

	}

	public function destroy($id)
	{
        $memberData = $this->MainModel->getSingleData('youtube_id', $id, 'youtube', '*');
		$memberId = $memberData->youtube_id;
		if (isset($memberId)) {
			$result = $this->MainModel->deleteData('youtube_id', $memberId, 'youtube');
			if ($result) {
				$this->session->set_flashdata('message', "link deleted successfully !!!!");
				redirect('youtube-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('youtube-list');
		}
	}
}
