<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AchivementsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
		$this->load->library('image_lib');
				$userId=$this->session->userdata('user_role');
	if($userId ==null){
			redirect('login');

	}


	}

	public function index()
	{
		$data['main'] = "Achivement images";
		$data['active'] = "Achivement images view";
		$data['sliders'] = $this->MainModel->getAllData('', 'achivements', '*', 'achivement_id DESC');
		$data['pageContent'] = $this->load->view('website/achivements/achivements_index', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}

	public function create()
	{
		$data['title'] = "Achivement registration form ";
		$data['main'] = "Achivement";
		$data['active'] = "Add Achivement";
		$data['pageContent'] = $this->load->view('website/achivements/achivements_create', $data, true);
		$this->load->view('adminwebsite/main', $data);
	}


	public function store()
	{


		if (isset($_FILES["achivement_picture"]["name"])) {
			if ((($_FILES["achivement_picture"]["type"] == "image/jpg") || ($_FILES["achivement_picture"]["type"] == "image/jpeg") || ($_FILES["achivement_picture"]["type"] == "image/png") || ($_FILES["achivement_picture"]["type"] == "image/gif"))) {

				if ($_FILES["achivement_picture"]["error"] > 0) {
					echo "Return Code: " . $_FILES["achivement_picture"]["error"] . "<br />";
				} else {
					$uploaded_image_path = "uploads/galerys/" . time() . '-' . $_FILES["achivement_picture"]["name"];
					$uploaded_file_path = "uploads/galerys/" . $_FILES["achivement_picture"]["name"];

					if (!file_exists($uploaded_file_path)) {
						move_uploaded_file($_FILES["achivement_picture"]["tmp_name"], $uploaded_image_path);
						// resize image
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = FALSE;
						$config['maintain_ratio'] = FALSE;
						$config['new_image'] = $uploaded_image_path;
						$config['quality'] = '60%';
						$config['width'] = 800;
						$config['height'] = 500;
						$this->image_lib->clear();
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
						$data['achivement_picture'] = $config['source_image'];
					}
				}
			}
		}
		$data['achivement_name'] = $this->input->post('achivement_name');
		$data['achivement_description'] = trim($this->input->post('achivement_description'));
		$this->form_validation->set_rules('achivement_name', 'galery name','required' );

		if ($this->form_validation->run() ==true) {
			$result = $this->MainModel->insertData('achivements', $data);
			if ($result) {
				$this->session->set_flashdata('message', "achivements added successfully !!!!");
				redirect('achivement-list');
			}
		} else {
			redirect('achivement-create');
		}


	}

    public function show($id)
    {
        $data['member'] = $this->MainModel->getSingleData('galery_id', $id, 'galery', '*');
//print_r($data);exit();
        $galeryId = $data['member']->galery_id;
        if (isset($galeryId)) {
            $data['title'] = "Achivement profile page";
            $data['main'] = "Achivement";
            $data['active'] = "pofile of member";
            $data['pageContent'] = $this->load->view('website/Members/members_show', $data, true);
            $this->load->view('adminwebsite/main', $data);
        } else {
            $this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
            redirect('member-list');
        }
    }

	public function edit($id)
	{

		$data['galery'] = $this->MainModel->getSingleData('achivement_id', $id, 'achivements', '*');
		$galeryId = $data['galery']->achivement_id;
		if (isset($galeryId)) {
			$data['title'] = "Achivement update page ";
			$data['main'] = "Achivement";
			$data['active'] = "Update Achivement";
			$data['pageContent'] = $this->load->view('website/achivements/achivements_edit', $data, true);
			$this->load->view('adminwebsite/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('achivement-list');
		}

	}

	public function update()
	{
		$student_id = $this->input->post('achivement_id');
		$Student = $this->MainModel->getSingleData('achivement_id', $student_id, 'achivements', '*');
		$studentId = $Student->achivement_id;


		if (isset($studentId)) {

			$old_student_picture_path=$this->input->post('old_achivement_picture');
			$data['achivement_picture']=$this->input->post('old_achivement_picture');
			if(isset($_FILES["achivement_picture"]["name"]))
			{
				if((($_FILES["achivement_picture"]["type"]=="image/jpg") || ($_FILES["achivement_picture"]["type"]=="image/jpeg") || ($_FILES["achivement_picture"]["type"]=="image/png") || ($_FILES["achivement_picture"]["type"]=="image/gif"))){
					if(!empty($old_student_picture_path)){
						unlink($old_student_picture_path);

					}
					$uploaded_image_path = "uploads/galerys/".time().'-'.$_FILES["achivement_picture"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["achivement_picture"]["error"] > 0) {
						echo "Return Code: " . $_FILES["achivement_picture"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["achivement_picture"]["tmp_name"],$uploaded_image_path);

						//$picture = $this->upload->data();

						//var_dump($picture);exit();
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 800;
						$config['height'] = 500;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['achivement_picture']=$uploaded_image_path;

					}
				}
			}


			$data['achivement_name'] = $this->input->post('achivement_name');
		$data['achivement_description'] = trim($this->input->post('achivement_description'));
		$this->form_validation->set_rules('achivement_name', 'galery name','required' );
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('achivement_id', $studentId, 'achivements', $data);
				if ($result) {
					$this->session->set_flashdata('message', "achivements updated successfully !!!!");
					redirect('achivement-list');
				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('achivement-update');
			}
		}
		else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('achivement-list');
		}

	}

	public function destroy($id)
	{
        $memberData = $this->MainModel->getSingleData('achivement_id', $id, 'achivements', '*');
		$galeryId = $memberData->achivement_id;
		if (isset($galeryId)) {
			$result = $this->MainModel->deleteData('achivement_id', $galeryId, 'achivements');
			if ($result) {
				$this->session->set_flashdata('message', "achivements deleted successfully !!!!");
				redirect('achivement-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('achivement-list');
		}
	}
}
