<div class="col-md-offset-0 col-md-12 ">
	<div class="box  box-success">
		<div class="box-header with-border">

			<!--        <h3 class="box-title"><a class="btn btn-success" href="--><?php //echo base_url();?><!--mark-create"><i class="fa fa-plus-circle"></i>Add new</span></a></h3>-->


			<form action="<?php echo base_url()?>Management/MarkSheetController/mypdf" method="post" >
<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col">Class And Section </th>
						<th scope="col">Exam And Session</th>
						<th scope="col">Student</th>
					</tr>
					</thead>
					<tbody>
					<tr>

						<td>
							<select  name="classreg_section_id" id="classSectionId" class="form-control select2">
								<option value="" >Select Class </option>
								<?php if(isset($classsections)):
									foreach ($classsections as $class):
										?>
										<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
									<?php endforeach; else : ?>
									<option value="">Registration first class </option>
								<?php endif;?>
							</select>
						</td>

						<td>
							<select  name="exam_session_id"  id="examSessionId" class="form-control select2">
								<option value="" >Select Exam Session </option>
								<?php if(isset($examSessions)):
									foreach ($examSessions as $examSession):
										?>
										<option value="<?php echo $examSession->exam_session_id;?>"><?php echo $examSession->exam_session_name;?> </option>
									<?php endforeach; else : ?>
									<option value="">Registration first examsession </option>
								<?php endif;?>
							</select>

						</td>
						<td>
							<input type="hidden" name="student_id" id="student_id" value="<?php echo  $this->session->userdata('student_id');?>">
							<input type="hidden" id="studentName" value="<?php echo  $this->session->userdata('student_name');?>">

							<input type="submit" value="Print" class="btn btn-success">

						</td>

					</tr>


					</tbody>
				</table>
</div>

			</form>
			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-4 bg-success">
				<h4>Class    &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  :<span id="dateShow1"></span></h4>
				<h4>Student    &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    :<span id="dateShow4"></span></h4>				<h4>Examination:<span id="dateShow3"></span></h4>

			</div>

		</div>
		<div class="box-body">
			<div class="table-responsive" id="marklistId">
				<table id="example1"  class="table table-bordered table-striped table-responsive ">
					<thead>
					<tr>
						<th>Id</th>

						<th>Subject</th>
						<th>Mark</th>
						<th>GradePoint</th>
						<th>Grade</th>
					</tr>
					</thead>
					<tbody>
					

					</tbody>

				</table>
			</div>
		</div>

	</div>
</div>


<script>
$(document).ready(function () {



	$("#examSessionId").change(function () {

		var classSectionId = $("#classSectionId option:selected").text();
		var studentId = $("#studentName").val();
		var examSessionId = $("#examSessionId option:selected").text();
		var gpaId = $("#gpaId option:selected").text();
		$("#resultShow").show();
		$("#dateShow1").text(classSectionId);
		$("#dateShow3").text(examSessionId);
		$("#dateShow4").text(studentId);
	});

	$("#examSessionId,#classSectionId").change(function () {
		var student_id=$("#student_id").val();
		var classreg_section_id=$("#classSectionId").val();
		var exam_session_id=$("#examSessionId").val();
		$.ajax({
			type: "POST",
			data: {student_id: student_id,classreg_section_id:classreg_section_id,exam_session_id:exam_session_id},
			dataType: "json",
			url: '<?php echo base_url();?>student/StudentModuleController/studentMarkData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results['students'], function (key, result) {
					var key=key+1;
					str = '<tr>'+
						'<td>'+key+'</td>'+
						'<td>'+result['subject_name']+'</td>'+
						'<td>'+result['mark_obtained']+'</td>'+
						'<td>'+result['mark_grade_point']+'</td>'+
						'<td>'+result['mark_gpa']+'</td>'+

						'</tr>';
					str1=str1+str;

				});
				str1 +='<tr><td>Total :</td><td>'+results['subjectCount']+'</td><td>'+results['finalmark']+'</td><td>'+results['finalGpa']+'</td><td>'+results['gradePoint']+'</td></tr>';

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});

	});
});



</script>



