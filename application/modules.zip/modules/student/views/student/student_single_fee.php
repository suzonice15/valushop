
<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>
			<table class="table table-bordered">
				<thead>
				<tr>
					<th scope="col">Class</th>
					<th scope="col">From</th>
					<th scope="col">To</th>
				</tr>
				</thead>
				<tbody>
				<form action="<?php echo base_url()?>studentWiseFeePrint" method="post">
					<td>
						<select   id="classSectionId" name="classreg_section_id" class="form-control select2">
							<option value="" >Select Class </option>
							<?php if(isset($classsections)):
								foreach ($classsections as $class):
									?>
									<option value="<?php echo $class->classreg_section_id;?>"><?php echo $class->classreg_section_name;?> </option>
								<?php endforeach; else : ?>
								<option value="">Registration first class </option>
							<?php endif;?>
						</select>
					</td>


						<input type="hidden" name="student_id" id="student_id" value="<?php echo $this->session->userdata('student_id');?>">
						<input type="hidden" name="student_name" id="student_name" value="<?php echo $this->session->userdata('student_name');?>">



					<td>
						<div class="input-group date" >
							<input id="dateId1" required type="text" class="form-control datepicker" name="attendance_date1"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td>
						<div class="input-group date" >
							<input id="dateId2" required type="text" class="form-control datepicker" name="attendance_date2"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker" ></span>
							</div>
						</div>

					</td>
					<td> <input type="submit"  class="btn btn-success"  value="Print" /></td>
				</form>
				</tr>
				</tbody>
			</table>


			<div  style="display:none"  id="resultShow" class="col-md-offset-3 col-md-6 bg-success">

				<h4>class &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="ClaaShowId"></span></h4>
				<h4>Student :<span id="StudentShowId"></span></h4>
				<h4>From &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow1"></span></h4>
				<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow2"></span></h4>
			</div>



		</div>
		<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>
						<th>Sl</th>
						<th>Class</th>
						<th>Date</th>
						<th>Category</th>
						<th>Amount</th>
						<th>Amount paid</th>
						<th>Due</th>
						<th>Satus</th>
						<th>Invoice</th>
					</tr>
					</thead>
					<tbody>


					</tbody>

				</table>


			</div>
		</div>

	</div>
</div>


<script>


	$("#classSectionId").change(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var classSectionData = $("#classSectionId option:selected").text();
		var studentData = $("#student_name").val();
		$("#resultShow").show();
		$("#ClaaShowId").text(classSectionData);
		$("#StudentShowId").text(studentData);
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});

	$("#dateId2,#dateId2,#classSectionId").change(function () {
		var dateId1=$("#dateId1").val();
		var dateId2=$("#dateId2").val();
		var classreg_section_id=$("#classSectionId").val();
		var student_id=$("#student_id").val();
		$.ajax({
			type: "POST",
			data: {classreg_section_id:classreg_section_id,dateId1:dateId1,dateId2:dateId2,student_id:student_id},
			dataType: "json",
			url: '<?php echo base_url();?>student/StudentModuleController/singleStudentWiseData',
			success: function (results) {
				var str = "";
				var str1 = "";
				$.each(results['students'], function (key, result) {
					var key=key+1;
					if(result['invoice_amount']==result['invoice_amount_paid']) {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['classreg_section_name'] + '</td>' +
							'<td>' + result['invoice_creation_time'] + '</td>' +
							'<td>' + result['expense_category_name'] + '</td>' +
							'<td>' + result['invoice_amount'] + '</td>' +
							'<td>' + result['invoice_amount_paid'] + '</td>' +
							'<td>' + result['invoice_due'] + '</td>' +
							'<td><span class="btn-xs btn-success">Paid</span></td>' +
							'<td><a class="btn btn-success btn-sm" href="invoice-make/' + result['invoice_id'] + '" >  Invoice</a></td>' +
							'</tr>';
					}
					else if(result['invoice_amount'] > result['invoice_amount_paid']){
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['classreg_section_name'] + '</td>' +
							'<td>' + result['invoice_creation_time'] + '</td>' +
							'<td>' + result['expense_category_name'] + '</td>' +
							'<td>' + result['invoice_amount'] + '</td>' +
							'<td>' + result['invoice_amount_paid'] + '</td>' +
							'<td>' + result['invoice_due'] + '</td>' +
							'<td><span class="btn-xs btn-info">Partial paid</span></td>' +
							'</tr>';
					}
					else {
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['classreg_section_name'] + '</td>' +
							'<td></td>' +
							'<td></td>' +
							'<td></td>' +
							'<td></td>' +
							'<td><span class="btn-xs btn-danger">unpaid</span></td>' +
							'<td></td>' +
							// '<td><a class="btn btn-danger" href="invoice-create" > Add new </a></td>' +
							'</tr>';

					}
					str1=str1+str;

				});
				str1 +='<tr><td></td><td></td><td></td><td></td><td>'+results['amount']+'</td><td>'+results['amountPaid']+'</td><td>'+results['amountDue']+'</td><td></td><td></td></tr>'

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>



