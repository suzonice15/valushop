<div class="col-md-offset-1 col-md-10">
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">

			<input type="hidden" name="student_id" id="student_id" value="<?php echo $this->session->userdata('student_id');?>" />

			<input type="hidden" name="student_id" id="studentName" value="<?php echo $this->session->userdata('student_name');?>" />
			<div class="form-group">
				<label for="shiftName" class="col-sm-1 control-label">Session</label>
				<div class="col-md-5">
					<select required name="session" id="session_id" class="form-control select2 ">
						<option value="">Select Session Name</option>
						<?php if (isset($sessions)):
							foreach ($sessions as $session):
								?>
								<option
									value="<?php echo $session->session_id; ?>"> <?php echo $session->session_name; ?> </option>
							<?php endforeach; else : ?>
							<option value="">Registration first session name</option>
						<?php endif; ?>

					</select>
				</div>
			</div>
			<div class="col-md-4">
				<a  onclick="window.print()" class="btn btn-info btn-lg">
					<span  class="glyphicon glyphicon-print"></span> Print
				</a>

			</div>

			<div style="display:none" id="resultShow" class="col-md-offset-3 col-md-6 bg-success">
				<h4>Student :<span id="dateShow1"></span></h4>
				<h4>Session :&nbsp;&nbsp;<span id="dateShow2"></span></h4>
			</div>
		</div>

		<div class="table-responsive">

			<table id="studentList" class="table table-bordered table-responsive">
				<thead>
				<tr>
					<th scope="col"> Subject Name</th>
					<th scope="col">First Examination</th>
					<th scope="col">Second Examination</th>
					<th scope="col">Annual examination</th>
				</tr>
				</thead>
				<tbody>

				</tbody>
			</table>
		</div>


	</div>


</div>


<script>
$(function () {


	$("#session_id").change(function () {

		var session_id = $("#session_id option:selected").text();
		var studentName = $("#studentName").val();
		$("#resultShow").show();
		$("#dateShow1").text(studentName);
		$("#dateShow2").text(session_id);

	});

	$(document).on('change','#session_id', function () {
var session_id = $('#session_id').val();
var student_id = $('#student_id').val();
$.ajax({
	type: "POST",
	data: {session_id: session_id, student_id: student_id},
	dataType: "json",
	url: '<?php echo base_url();?>student/StudentModuleController/studentMarksheet',
	success: function (results) {
		var str = "";
		var str1 = "";
		$.each(results['marksheet'], function (key, result) {

			str = '<tr>' +
				'<td> ' + result['subject_name'] + '</td>' +
				'<td>' + result['firs'] + '</td>' +
				'<td>' + result['sec'] + '</td>' +
				'<td>' + result['ann'] + '</td>' +
				'</tr>';


			str1=str1+str;

		});
		str1 =str1+'<tr><td>Total Subject='+results['subjectCounter']+'</td><td>'+results['first']+'</td><td>'+results['second']+'</td>' +
			'<td>'+results['final']+'</td></tr>'
		$("#studentList tbody").empty();
		$("#studentList tbody").append(str1);
	}
});
});

});


</script>



