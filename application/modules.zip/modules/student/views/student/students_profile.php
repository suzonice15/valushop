<div class="col-md-offset-0 col-md-12">
	<div class="box box-success ">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">


			<form action="<?php echo base_url() ?>student-profile-update" class="form-horizontal" method="post"
				  enctype="multipart/form-data">

				<section class="content">

					<div class="row">
						<div class="col-md-3">

							<!-- Profile Image -->
							<div class="box box-primary">
								<div class="box-body box-profile">
									<?php if (isset($student->student_picture_path)): ?>
										<img class="profile-user-img img-responsive img-circle"
											 src="<?php echo base_url();
											 echo $student->student_picture_path; ?>" alt="User profile picture">
									<?php else : ?>
										<img class="profile-user-img img-responsive img-circle"
											 src="<?php echo base_url() ?>uploads/teachers/teacher.png"
											 alt="User profile picture">
									<?php endif; ?>

									<h3 class="profile-username text-center">

										<?php if (isset($student->student_name)):

											echo $student->student_name;
										endif;
										?>

									</h3>


								</div>
								<!-- /.box-body -->
							</div>
							<!-- /.box -->

							<!-- About Me Box -->
							<!-- /.box -->
						</div>
						<!-- /.col -->
						<div class="col-md-9">


							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Name<span style="color:red"> *</span></label>

								<div class="col-md-7">
									<input required type="text"  class="form-control" name="student_name" id="studentName"
										   value="<?php if (isset($student)) echo $student->student_name; ?>"
										   placeholder="Enter Studnet name :shahinul islam">
									<input type="hidden" name="student_id" value="<?php if (isset($student)) echo $student->student_id; ?>">
								</div>
							</div>

							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Father Name <span style="color:red"> *</span></label>

								<div class="col-md-7">
									<input required type="text" id="field-1" class="form-control" name="student_father_name"
										   value="<?php if (isset($student)) echo $student->student_father_name; ?>"
										   placeholder="Enter  Father Name :abdul Hamid">
								</div>
							</div>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Mother Name <span style="color:red"> *</span></label>

								<div class="col-md-7">
									<input required type="text" id="field-1" class="form-control" name="student_mother_name"
										   value="<?php if (isset($student)) echo $student->student_mother_name; ?>"
										   placeholder="Enter  Mother Name :Sunur Jan ">
								</div>
							</div>

							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Address<span style="color:red"> *</span></label>

								<div class="col-md-7">
									<input required type="text" id="field-1" class="form-control " name="student_address"
										   value="<?php if (isset($student)) echo $student->student_address; ?>"
										   placeholder="Enter  address: Mirpur 2,Dahaka">
								</div>
							</div>

							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Bairthday </label>

								<div class="col-md-7">
									<div class="input-group date" >
										<input type="text"  class="form-control withoutFixedDate" name="student_birthday"
											   value="<?php if (isset($student)) echo $student->student_birthday; ?>"
											   placeholder="enter session name : 2010">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-th"></span>
										</div>
									</div>
								</div>
							</div>

						
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Mobile <span style="color:red"> *</span></label>

								<div class="col-md-7">
									<input required type="text" id="studentMobile" class="form-control" name="student_phone"
										   value="<?php if (isset($student)) echo $student->student_phone; ?>"
										   placeholder="Enter  Mobile:01815330597">
									<span style="color:red" id="mobileEerror"></span>
								</div>
							</div>
							<div class="form-group">
								<label for="field-2" class="col-sm-3 control-label">Gender<span style="color:red"> *</span></label>
								<div class="col-md-7">
									<select required name="student_sex" id="gender_id" class="form-control select2 ">
										<option value="">Select Gender</option>
										<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Female" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="Female">Female
										</option>
										<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Male" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Male">Male</option>
										<option <?php $selected=isset($student->student_sex)? $student->student_sex == "Other" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Other">Other
										</option>

									</select>
								</div>

							</div>


							<div class="form-group">
								<label for="field-2" class="col-sm-3 control-label">Religion <span style="color:red"> *</span></label>
								<div class="col-md-7">
									<select required name="student_religion" id="religion_id" class="form-control select2">

										<option value="">Select Religion</option>
										<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Muslim" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="Muslim">
											Muslim
										</option>
										<option  <?php $selected=isset($student->student_religion)? $student->student_religion == "Buddist" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Buddist">
											Buddist
										</option>
										<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Christian" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Christian">
											Christian
										</option>
										<option <?php $selected=isset($student->student_religion)? $student->student_religion == "Hindu" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Hindu">Hindu
										</option>
									</select>
								</div>
							</div>



							<div class="form-group">
								<label for="student_blood_group" class="col-sm-3 control-label">Blood Group<span style="color:red"> *</span> </label>
								<div class="col-md-7">
									<select name="student_blood_group" id="student_blood_group" class="form-control select2 ">
										<option value="">Select blood group</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "AB-" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="AB-">AB-</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "AB+" ?  ' selected="selected"':"" :"" ; echo $selected?>  value="AB+">AB+</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "B-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="B-">B-</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "B+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="B+">B+</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "A-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="A-">A-</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "A+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="A+">A+</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "O-" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="O-">O-</option>
										<option <?php $selected=isset($student->student_blood_group)? $student->student_blood_group == "O+" ?  ' selected="selected"':"" :"" ; echo $selected ?> value="O+">O+</option>
									</select>
								</div>
							</div>
							<?php if(!empty($student->student_picture_path)):?>
								<div class="form-group">
									<label for="field-1" class="col-sm-3 control-label"> picture</label>
									<div class="col-md-7">
										<img width="70" height="50" src="<?php echo base_url(); if(isset($student)){ echo $student->student_picture_path;} ?>"/>

										<input type="hidden"  class="form-control" name="old_student_picture_path" value="<?php  if(isset($student)){ echo $student->student_picture_path;} ?>">
									</div>
								</div>
							<?php endif;?>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> picture</label>
								<div class="col-md-7">
									<input type="file"  class="form-control" name="student_picture_path">
								</div>
							</div>


						</div>
					<!-- /.row -->


				</section>
				<div class="alert alert-warning alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-warning"></i> Alert!</h4>
					You can change the following information .If you do not change no problem
				</div>
				<div class="form-group">
					<label for="field-1" class="col-sm-3 control-label">Email</label>

					<div class="col-md-7">
						<input required type="email" class="form-control" name="student_email"
							   id="student_email"
							   value="<?php if (isset($student)) echo $student->student_email; ?>"
							   placeholder="enter teacher name :shahinul@gmail.com">
						<span id="emailEerror" style="color:red"></span>

					</div>

				</div>

                <div class="form-group">
                    <label  class="col-sm-3 control-label">Password</label>

                    <div class="col-md-7">
   <input  type="password" class="form-control" name="user_password" value="" />



                    </div>
                </div>
                <input type="submit" value="Update profile" class="btn btn-success pull-right ">
		</div>


		</form>
	</div>
</div>
<script>

	$(document).ready(function () {
		$(document).on('input','#studentMobile',function () {
			checkMobile();
		});
		$(document).on('input','#student_email',function () {
			studentEmailCheck();
		});
	});

	function checkMobile() {
		var student_phone = $('#studentMobile').val();
		if(student_phone.length<11){
			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;

		}
		else if(student_phone.length>11){

			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled','disabled');
			return false;
		}
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url()?>Management/StudentsController/studentMobile/' + student_phone,
			success: function (result) {
				if (result) {
					$('#mobileEerror').html(result);
					$('input[type="submit"]').attr('disabled','disabled');
					return false;
				} else {
					$('#mobileEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});
		return false;
	}
	function studentEmailCheck() {
		var student_email = $('#student_email').val();
		debugger;
		$.ajax({
			type: 'POST',
			data:{student_email:student_email},
			url: '<?php echo base_url()?>management/StudentsController/studentEmailCheck',
			success: function (result) {
				if (result) {
					$('#emailEerror').html(result);
					$('input[type="submit"]').attr('disabled','disabled');
					return false;
				} else {
					$('#emailEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});


		return false;
	}


</script>


