<div class="col-md-offset-0 col-md-12">
	<div class="box  box-success">
		<div class="box-header with-border">
			<h3 class="box-title"></h3>
			<table class="table table-bordered">
				<thead>
				<tr>
					<th scope="col">From</th>
					<th scope="col">To</th>
				</tr>
				</thead>
				<tbody>
				<form action="<?php echo base_url() ?>student-fee-history" method="post">

					<input type="hidden" name="student_id" id="student_id"
						   value="<?php echo $this->session->userdata('student_id'); ?>">
					<input type="hidden" name="student_name" id="student_name"
						   value="<?php echo $this->session->userdata('student_name'); ?>">
					<td>
						<div class="input-group date">
							<input id="dateId1"  name="date1" required type="text" class="form-control datepicker"
								  placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker"></span>
							</div>
						</div>
					</td>
					<td>
						<div class="input-group date">
							<input id="dateId2" name="date2" required type="text" class="form-control datepicker"
								   placeholder="Enter date:12/12/2019">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th" id="datepicker"></span>
							</div>
						</div>

					</td>
					<td><input type="submit" class="btn btn-success" value="Print"/></td>
				</form>
				</tr>
				</tbody>
			</table>
			<div style="display:none" id="resultShow" class="col-md-offset-3 col-md-6 bg-success">

				<h4>Student :<span id="StudentShowId"></span></h4>
				<h4>From &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span id="dateShow1"></span></h4>
				<h4>To &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span
						id="dateShow2"></span></h4>
				<h4>Total Amount &nbsp;:<span
						id="totalAmount"></span></h4>
			</div>
		</div>
		<div class="box-body">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>
						<th>Sl</th>
						<th>Date</th>
						<th>Class</th>
						<th>Category</th>
						<th>Amount</th>
					</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script>


	$("#dateId2,#dateId2").click(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var studentData = $("#student_name").val();
		$("#resultShow").show();
		$("#StudentShowId").text(studentData);
		$("#dateShow1").text(dateId1);
		$("#dateShow2").text(dateId2);
	});

	$("#dateId2,#dateId2").click(function () {
		var dateId1 = $("#dateId1").val();
		var dateId2 = $("#dateId2").val();
		var student_id = $("#student_id").val();
		$.ajax({
			type: "POST",
			data: {
				date1: dateId1,
				date2: dateId2,
				student_id: student_id
			},
			dataType: "json",
			url: '<?php echo base_url();?>student/StudentModuleController/studentFeeHistory',
			success: function (results) {
				var str = "";
				var str1 = "";
				$("#totalAmount").text(results['totalAmount']);
				$.each(results['payments'], function (key, result) {
					var key = key + 1;
						str = '<tr>' +
							'<td>' + key + '</td>' +
							'<td>' + result['payment_date'] + '</td>' +
							'<td>' + result['classreg_section_name'] + '</td>' +
							'<td>' + result['expense_category_name'] + '</td>' +
							'<td>' + result['payment_amount'] + '</td>' +

							'</tr>';

					str1 = str1 + str;

				});

				$("#example1 tbody").empty();
				$("#example1 tbody").append(str1);
			}
		});
	});

</script>



