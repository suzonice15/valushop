<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentModuleController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
		$user_role=$this->session->userdata('user_role');
		if($user_role==1 or $user_role==2)
		{
			redirect('dashboard');
		}

	}

	public function index()
	{
		$data['main'] = "Teachers";
		$data['active'] = "Teachers view";
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');

		$data['pageContent'] = $this->load->view('management/teachers/teachers_index', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function singleStudentFee()
	{
		$data['main'] = "Student fee report";
		$data['active'] = "view fee report";
		$query="select invoice_id,student_name,expense_category_name,invoice_creation_time,classreg_section_name,invoice_amount,invoice_amount_paid,invoice_due,student_father_name from invoices
join classreg_section_com on classreg_section_com.classreg_section_id=invoices.classreg_section_id
join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
join students on students.student_id=invoices.student_id
join expense_category on expense_category.expense_category_id=invoices.expense_category_id
where student_classreg_section_com.student_classreg_section_isActive=1 order by invoice_id desc";
		$data['invoices'] = $this->MainModel->AllQueryDalta($query);
		$data['classsections']=$this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('student/student/student_single_fee', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function studentFeeHistoryForm()
	{
		$data['main'] = "Fee history";
		$data['active'] = "view fee history";
		$data['pageContent'] = $this->load->view('student/student/student_fee_history_form', $data, true);
		$this->load->view('layouts/main', $data);

	}

	public function studentFeeHistory()
	{

		$dateId1 = date('Y-m-d',strtotime($this->input->post('date1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('date2')));
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$student_id   = $this->input->post('student_id');
		$query ="select * from  payment 
join student_classreg_section_com on student_classreg_section_com.student_id=payment.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join expense_category on expense_category.expense_category_id=payment.expense_category_id
where payment.student_id=$student_id and payment.payment_date between '$dateId1' and '$dateId2'";
		$data['payments'] = $this->MainModel->AllQueryDalta($query);
		$data['totalAmount']=0;
		foreach ($data['payments'] as $student){

			$data['totalAmount']=$data['totalAmount']+$student->payment_amount;

		}
		echo json_encode($data);


	}



	public function studentFeeHistoryPdf()
	{

		$data['main'] = "Fee history";
		$data['active'] = "Fee history";

		$dateId1 = date('Y-m-d',strtotime($this->input->post('date1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('date2')));
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$student_id   = $this->input->post('student_id');
		$data['firstDate']   = $dateId1;
		$data['lastDate']   = $dateId2;
		$query ="select * from  payment 
join student_classreg_section_com on student_classreg_section_com.student_id=payment.student_id
join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join expense_category on expense_category.expense_category_id=payment.expense_category_id
join students on students.student_id=student_classreg_section_com.student_id 
where payment.student_id=$student_id and payment.payment_date between '$dateId1' and '$dateId2'";
		$data['payments'] = $this->MainModel->AllQueryDalta($query);
		$data['totalAmount']=0;
		foreach ($data['payments'] as $student){

			$data['totalAmount']=$data['totalAmount']+$student->payment_amount;

		}
		$data['pageContent'] = $this->load->view('student/student/student_fee_history_pdf', $data, true);
		$this->load->view('layouts/main', $data);

	}

    public function update()
    {
		$student_id = $this->input->post('student_id');
		$Student = $this->MainModel->getSingleData('student_id', $student_id, 'students', '*');
		$studentId = $Student->student_id;


		if (isset($studentId)) {

			$old_student_picture_path=$this->input->post('old_student_picture_path');
			$data['student_picture_path']=$this->input->post('old_student_picture_path');
			if(isset($_FILES["student_picture_path"]["name"]))
			{
				if((($_FILES["student_picture_path"]["type"]=="image/jpg") || ($_FILES["student_picture_path"]["type"]=="image/jpeg") || ($_FILES["student_picture_path"]["type"]=="image/png") || ($_FILES["student_picture_path"]["type"]=="image/gif"))){
					if(!empty($old_student_picture_path)){
						unlink($old_student_picture_path);

					}
					$uploaded_image_path = "uploads/students/".time().'-'.$_FILES["student_picture_path"]["name"];
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$this->load->library('upload', $config);
					if ($_FILES["student_picture_path"]["error"] > 0) {
						echo "Return Code: " . $_FILES["student_picture_path"]["error"] . "<br />";
					}
					else
					{
						move_uploaded_file ($_FILES["student_picture_path"]["tmp_name"],$uploaded_image_path);
						$config['image_library'] = 'gd2';
						$config['source_image'] = $uploaded_image_path;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = FALSE;
						$config['quality'] = '60%';
						$config['width'] = 300;
						$config['height'] = 300;
						$config['new_image'] = $uploaded_image_path;
						$this->load->library('image_lib', $config);
						$this->image_lib->resize();
						$data['student_picture_path']=$uploaded_image_path;

					}
				}
			}

			$userPassword = $this->input->post('user_password');
			if(isset($userPassword)){
				$userData['user_password'] =$userPassword;
				$this->MainModel->updateData('student_id', $studentId, 'user', $userData);

			}
			$data['student_name'] = $this->input->post('student_name');
			$data['student_father_name'] = $this->input->post('student_father_name');
			$data['student_mother_name'] = $this->input->post('student_mother_name');
			$data['student_birthday'] = $this->input->post('student_birthday');
			$data['student_sex'] = $this->input->post('student_sex');
			$data['student_religion'] = $this->input->post('student_religion');
			$data['student_blood_group'] = $this->input->post('student_blood_group');
			$data['student_address'] = $this->input->post('student_address');
			$data['student_phone'] = $this->input->post('student_phone');
			$data['student_email'] = $this->input->post('student_email');
//			$data['student_picture_path'] = $this->input->post('student_picture_path');
			$this->form_validation->set_rules('student_name', 'Student name', 'required');
			$this->form_validation->set_rules('student_father_name', 'Student name', 'required');
			$this->form_validation->set_rules('student_mother_name', 'Student name', 'required');
			$this->form_validation->set_rules('student_sex', 'Student name', 'required');
			$this->form_validation->set_rules('student_religion', 'Student name', 'required');
			$this->form_validation->set_rules('student_address', 'Student name', 'required');
			$this->form_validation->set_rules('student_phone', 'Student code', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('student_id', $studentId, 'students', $data);


				if ($result) {
					$this->session->set_flashdata('message', "Student profile updated successfully !!!!");
					redirect('student-profile');
				}
			} else {

				$this->session->set_flashdata('message', "value reqiured");
				redirect('student-profile');
			}
		}
		else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('student-profile');
		}


	}



	public function singleStudentWiseData()
	{
		$dateId1 = date('Y-m-d',strtotime($this->input->post('dateId1')));
		$dateId2 = date('Y-m-d',strtotime($this->input->post('dateId2')));
		$classreg_section_id   = $this->input->post('classreg_section_id');
		$student_id   = $this->input->post('student_id');
		$query = "select  invoices.*,classreg_section_name,expense_category_name ,student_name,student_father_name from invoices
join  expense_category on expense_category.expense_category_id=invoices.expense_category_id
 join student_classreg_section_com on student_classreg_section_com.student_id=invoices.student_id
 join classreg_section_com on classreg_section_com.classreg_section_id=student_classreg_section_com.classreg_section_id
join students on students.student_id=student_classreg_section_com.student_id
where student_classreg_section_com.classreg_section_id=$classreg_section_id and 
student_classreg_section_com.student_classreg_section_isActive=1 and invoices.invoice_creation_time between '$dateId1' and '$dateId2' and invoices.student_id=$student_id
";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		$amount=0;
		$amountPaid=0;
		$amountDue=0;
		foreach ($data['students'] as $student){
			$amount= $amount + $student->invoice_amount;
			$amountPaid= $amountPaid + $student->invoice_amount_paid;
			$amountDue=$amountDue + $student->invoice_due;
		}
		$data['amount']=$amount;
		$data['amountPaid']=$amountPaid;
		$data['amountDue']=$amountDue;
//		echo '<pre>';
//		print_r($data);exit();
		echo json_encode($data);
	}


	public function studentMarksheetForm()
	{

		$data['main'] = "Student marksheet";
		$data['active'] = "View Student marksheet";
		$student_id= $this->session->userdata('student_id');
		$data['sessions'] = $this->MainModel->getAllData('', 'sessions', '*', 'session_id DESC');

		$data['pageContent'] = $this->load->view('student/student/student_marksheet', $data, true);
		$this->load->view('layouts/main', $data);


	}

	public function singleStudentAttendce()
	{

		$data['main'] = "Student attendance";
		$data['active'] = "View student attendace";
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');

		$data['pageContent'] = $this->load->view('student/student/student_singleAttendce', $data, true);
		$this->load->view('layouts/main', $data);


	}
	 public  function  profile(){


		 $data['main'] = "Student profile";
		 $data['title'] = "Update student profile ";
		 $data['active'] = "View student profile";
		 $student_id= $this->session->userdata('student_id');
//			 $subjectQuery="select count(subject_id) as subject_id from teacher_subject_com where teacher_subject_com.teacher_id=$teacher_id";
		 $query="select * from user join  students on students.student_id=user.student_id  where user.student_id=$student_id";
		 $data['students'] = $this->MainModel->SingleQueryData($query);
		 $data['student'] = $this->MainModel->getSingleData('student_id', $student_id, 'students', '*');
		 $data['pageContent'] = $this->load->view('student/student/students_profile', $data, true);
		 $this->load->view('layouts/main', $data);
	 }

	public function studentMarkData()
	{
		$student_id = $this->input->post('student_id');
		$exam_session_id= $this->input->post('exam_session_id');
		$classreg_section_id= $this->input->post('classreg_section_id');
		$query = "select student_name,subject_name,mark_obtained,mark_grade_point,mark_gpa from marks 
join student_classreg_section_com on student_classreg_section_com.student_id=marks.student_id
join students on students.student_id=student_classreg_section_com.student_id
join subjects on subjects.subject_id=marks.subject_id
where marks.exam_session_id=$exam_session_id and student_classreg_section_com.classreg_section_id=$classreg_section_id  and student_classreg_section_com.student_classreg_section_isActive=1
and students.student_id=$student_id";
		$data['students'] = $this->MainModel->AllQueryDalta($query);
		$totalMarks=0;
		$totalGpa=0;
		$subjectCount=0;
		$finalgpa=0;
		foreach($data['students'] as $student){
			$subjectCount++;
			$totalMarks=$totalMarks+$student->mark_obtained;
			$totalGpa=$totalGpa+$student->mark_grade_point;
		}
//		echo $totalMarks;
//		echo $totalGpa;
		$finalgpa=$totalGpa/$subjectCount;
		if($finalgpa==5){
			$data['gradePoint']='A+';

		}
		else if($finalgpa<5 and $finalgpa>=4){
			$data['gradePoint']='A';

		}
		else if($finalgpa<4 and $finalgpa>=3.5){
			$data['gradePoint']='A-';

		}
		else if($finalgpa<3.5 and $finalgpa>=3){
			$data['gradePoint']='B';

		}
		else if($finalgpa<3 and $finalgpa>=2){
			$data['gradePoint']='C';

		}
		else if($finalgpa<2 and $finalgpa>=1){
			$data['gradePoint']='D';

		}
		else {
			$data['gradePoint']='F';
		}
		//echo $finalgpa;
		$data['finalGpa']=sprintf("%.2f", $finalgpa);
		$data['subjectCount']=$subjectCount;;
		$data['finalmark']=sprintf("%.2f", $totalMarks);
		//echo $data['gradePoint'];



		echo json_encode($data);


	}


	public function singleStudentMark()
	{

		$data['main'] = "Student mark";
		$data['active'] = "View student mark";
		$data['students'] = $this->MainModel->getAllData('', 'students', '*', 'student_id DESC');
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');
		$data['classsections'] = $this->MainModel->getAllData('', 'classreg_section_com', '*', 'classreg_section_id DESC');
		$data['pageContent'] = $this->load->view('student/student/student_single_mark', $data, true);
		$this->load->view('layouts/main', $data);


	}
	public function studentMarksheet()
	{
		$studentId = $this->input->post('student_id');
		$sessionId= $this->input->post('session_id');
		$examsessionQuery="select * from exam_session_com where exam_session_com.session_id=$sessionId order by exam_session_com.exam_session_id DESC";
		$examSession=$this->MainModel->AllQueryDalta($examsessionQuery);
			$first=$examSession[0]->exam_session_id;
			$second=$examSession[1]->exam_session_id;
			$third=$examSession[2]->exam_session_id;
		$query="select subject_name
,sum(firs) firs
,sum(sec) sec
,sum(ann) ann from
(SELECT
subject_name,subject_id,
SUM(IF(exam_session_id = $first, mark_obtained, 0)) AS firs,
SUM(IF(exam_session_id = $second, mark_obtained, 0)) AS sec,
SUM(IF(exam_session_id = $third, mark_obtained, 0)) AS ann
FROM
(select students.student_name,exam_session_com.exam_session_name,exam_session_com.exam_session_id,subjects.subject_id,subjects.subject_name,marks.mark_obtained,marks.mark_gpa,marks.mark_grade_point from marks
join exam_session_com on exam_session_com.exam_session_id=marks.exam_session_id
join sessions on sessions.session_id=exam_session_com.session_id
join subjects on subjects.subject_id=marks.subject_id
join students on students.student_id=marks.student_id
where sessions.session_id=$sessionId and marks.student_id=$studentId
) marks
GROUP BY
subject_id, exam_session_id) pivottable
group by subject_id";
		$data['marksheet']=$this->MainModel->AllQueryDalta($query);
		$data['first']=0;
		$data['second']=0;
		$data['final']=0;
		$i=0;

		foreach ($data['marksheet'] as $mark):
			$data['first']=$data['first']+$mark->firs;
			$data['second']=$data['second']+$mark->sec;
			$data['final']=$data['final']+$mark->ann;
			$i++;
		endforeach;
		$data['subjectCounter']=$i;
		echo json_encode($data);
	}



}
