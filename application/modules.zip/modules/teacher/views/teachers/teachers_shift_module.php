<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		

	</div>
	<div class="box-body">
<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped table-responsive ">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Shift</th>
				<th>Class</th>
				<th>Section</th>
			
			</tr>
			</thead>
			<tbody>
			<?php if (isset($teachersShiftData)):
				$count = 1;
				foreach ($teachersShiftData as $teacher):
					?>
					<tr>
						<td><?php echo $count; ?></td>						
						<td><?php echo $teacher->shift_name; ?></td>
						<td><?php echo $teacher->classreg_name; ?></td>
						<td><?php echo $teacher->section_name; ?></td>
					</tr>
					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>
</div>


	</div>

</div>
</div>
