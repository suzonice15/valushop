<div class="col-md-offset-0 col-md-12">
	<div class="box box-success ">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body">


			<form action="<?php echo base_url() ?>teacher-profile-update" class="form-horizontal" method="post"
				  enctype="multipart/form-data">

				<section class="content">

					<div class="row">
						<div class="col-md-3">

							<!-- Profile Image -->
							<div class="box box-primary">
								<div class="box-body box-profile">
									<?php if (isset($teachers->teacher_picture_path)): ?>
										<img class="profile-user-img img-responsive img-circle"
											 src="<?php echo base_url();
											 echo $teachers->teacher_picture_path; ?>" alt="User profile picture">
									<?php else : ?>
										<img class="profile-user-img img-responsive img-circle"
											 src="<?php echo base_url() ?>uploads/teachers/teacher.png"
											 alt="User profile picture">
									<?php endif; ?>

									<h3 class="profile-username text-center">

										<?php if (isset($teachers->teacher_full_name)):

											echo $teachers->teacher_full_name;
										endif;
										?>

									</h3>

									<p class="text-muted text-center">

										<?php if (isset($teachers->teacher_title)):

											echo $teachers->teacher_title;
										endif;
										?>
									</p>
									<ul class="list-group list-group-unbordered">
										<li class="list-group-item">
											<b>Subjects</b> <a class="pull-right">
												<?php if (isset($subjects->subject_id)):

													echo $subjects->subject_id;
												endif;
												?>

											</a>
										</li>
									</ul>

								</div>
								<!-- /.box-body -->
							</div>
							<!-- /.box -->

							<!-- About Me Box -->
							<!-- /.box -->
						</div>
						<!-- /.col -->
						<div class="col-md-9">

							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Name</label>

								<div class="col-md-7">
									<input required type="text" id="field-1" class="form-control"
										   name="teacher_full_name"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_full_name; ?>"
										   placeholder="enter teacher name :shahinul islam">
									<input type="hidden" name="teacher_id"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_id; ?>">
								</div>
							</div>

							<div class="form-group">
								<label for="teacher_contact_no" class="col-sm-3 control-label"> Mobile</label>

								<div class="col-md-7">
									<input required type="number" id="teacher_contact_no" class="form-control"
										   name="teacher_contact_no"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_contact_no; ?>"
										   placeholder="enter teacher mobile :01738306670">
									<span id="mobileEerror" style="color:red"></span>
									<?php form_error('teacher_contact_no', '<span style="color:red">', '</span>') ?>
								</div>
							</div>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Address</label>

								<div class="col-md-7">
									<input required type="text" id="field-1" class="form-control" name="teacher_address"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_address; ?>"
										   placeholder="enter teacher address :dhaka,bangladesh">
								</div>
							</div>

							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label">Email</label>

								<div class="col-md-7">
									<input required type="email" class="form-control" name="teacher_email"
										   id="teacher_email"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_email; ?>"
										   placeholder="enter teacher name :shahinul@gmail.com">
									<span id="emailEerror" style="color:red"></span>

								</div>
							</div>
							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> National Id Card</label>

								<div class="col-md-7">
									<input type="text" id="field-1" class="form-control" name="teacher_nid"
										   id="teacher_nid"
										   value="<?php if (isset($teachers)) echo $teachers->teacher_nid; ?>"
										   placeholder="enter teacher nid :1991968226644868">
									<span id="nidEerror" style="color:red"></span>

								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Job title<span style="color:red"> </span></label>
								<div class="col-md-7">
									<select required name="teacher_title" class="form-control select2"
											id="teacher_title" class="form-control">
										<option value="">Select Job title</option>
										<option <?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Principal" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Principal">Principal
										</option>
										<option<?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Vice principal" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Vice principal">Vice principal
										</option>
										<option <?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Professor" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Professor">Professor
										</option>
										<option <?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Junior teacher" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Junior teacher">Junior teacher
										</option>
										<option <?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Senior teacher" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Senior teacher">Senior teacher
										</option>
										<option <?php $selected = isset($teachers->teacher_title) ? $teachers->teacher_title == "Head teacher" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Head teacher">Head teacher
										</option>


									</select>
								</div>

							</div>

							<div class="form-group">
								<label for="field-2" class="col-sm-3 control-label">Gender</label>
								<div class="col-md-7">
									<select required name="teacher_sex" class="form-control select2" id="gender_id"
											class="form-control">
										<option value="">Select Gender</option>
										<option <?php $selected = isset($teachers->teacher_sex) ? $teachers->teacher_sex == "Female" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Female">Female
										</option>
										<option<?php $selected = isset($teachers->teacher_sex) ? $teachers->teacher_sex == "Male" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Male">Male
										</option>
										<option <?php $selected = isset($teachers->teacher_sex) ? $teachers->teacher_sex == "Other" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Other">Other
										</option>

									</select>
								</div>

							</div>


							<div class="form-group">
								<label for="field-2" class="col-sm-3 control-label">Religion </label>
								<div class="col-md-7">
									<select required name="teacher_religion" class="form-control select2"
											id="religion_id" class="form-control">

										<option value="">Select Religion</option>
										<option <?php $selected = isset($teachers->teacher_religion) ? $teachers->teacher_religion == "Muslim" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Muslim">Muslim
										</option>
										<option <?php $selected = isset($teachers->teacher_religion) ? $teachers->teacher_religion == "Buddist" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Buddist">
											Buddist
										</option>
										<option <?php $selected = isset($teachers->teacher_religion) ? $teachers->teacher_religion == "Christian" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Christian">
											Christian
										</option>
										<option <?php $selected = isset($teachers->teacher_religion) ? $teachers->teacher_religion == "Hindu" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="Hindu">Hindu
										</option>
									</select>
								</div>
							</div>


							<div class="form-group">
								<label for="field-2" class="col-sm-3 control-label">Blood Group </label>
								<div class="col-md-7">
									<select name="teacher_blood_group" class="form-control select2" id="blood_group_id"
											class="form-control">
										<option value="">Select blood group</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "AB-" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="AB-">AB-
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "AB+" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="AB+">AB+
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "B-" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="B-">B-
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "B+" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="B+">B+
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "A-" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="A-">A-
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "A+" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="A+">A+
										</option>
										<option <?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "O-" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="O-">O-
										</option>
										<option<?php $selected = isset($teachers->teacher_blood_group) ? $teachers->teacher_blood_group == "O+" ? ' selected="selected"' : "" : "";
										echo $selected ?> value="O+">O+
										</option>
									</select>
								</div>
							</div>


							<div class="form-group">
								<label for="field-1" class="col-sm-3 control-label"> Picture</label>

								<div class="col-md-7">
									<input type="file" id="field-1" class="form-control" name="teacher_picture_path">
								</div>
							</div>

						</div>
						<!-- /.col -->
					</div>
					<!-- /.row -->


				</section>
				<div class="alert alert-warning alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-warning"></i> Alert!</h4>
					You can change the following information .If you do not change no problem
				</div>
				<div class="form-group">
					<label for="field-1" class="col-sm-3 control-label">Email</label>

					<div class="col-md-7">
						<input required type="email" class="form-control" name="teacher_email"
							   id="teacher_email"
							   value="<?php if (isset($teachers)) echo $teachers->teacher_email; ?>"
							   placeholder="enter teacher name :shahinul@gmail.com">
						<span id="emailEerror" style="color:red"></span>

					</div>
				</div>

                <div class="form-group">
                    <label  class="col-sm-3 control-label">Password</label>

                    <div class="col-md-7">
   <input  type="password" class="form-control" name="user_password" value="" />



                    </div>
                </div>
                <input type="submit" value="Update profile" class="btn btn-success pull-right ">
		</div>


		</form>
	</div>
</div>
<script>

	$(document).ready(function () {
		$(document).on('blur', '#teacher_contact_no', function () {
			checkMobile();
		});
		$(document).on('input', '#teacher_nid', function () {
			checkNid();
		});
		$(document).on('input', '#teacher_email', function () {
			teacherEmailCheck();
		});

	});

</script>

<script>
	function checkMobile() {
		var teacher_contact_no = $('#teacher_contact_no').val();
		if (teacher_contact_no.length < 11) {
			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled', 'disabled');
			return false;

		} else if (teacher_contact_no.length > 11) {

			$("#mobileEerror").text("please insert mobile number with 11 digit ");
			$("#mobileEerror").delay(5000).fadeOut();
			$('input[type="submit"]').attr('disabled', 'disabled');
			return false;
		}
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url()?>management/TeachersController/teacherMobile/' + teacher_contact_no,
			success: function (result) {
				if (result) {
					$('#mobileEerror').html(result);
					return false;
				} else {
					$('#mobileEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});
		return false;
	}

	function checkNid() {
		var teacher_nid = $('#teacher_nid').val();
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url()?>management/TeachersController/teacherNid/' + teacher_nid,
			success: function (result) {
				if (result) {
					$('#nidEerror').html(result);
					$('input[type="submit"]').attr('disabled', 'disabled');
					return false;
				} else {
					$('#nidEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});


		return false;
	}

	function teacherEmailCheck() {
		var teacher_email = $('#teacher_email').val();
		debugger;
		$.ajax({
			type: 'POST',
			data: {teacher_email: teacher_email},
			url: '<?php echo base_url()?>management/TeachersController/teacherEmailCheck',
			success: function (result) {
				if (result) {
					$('#emailEerror').html(result);
					$('input[type="submit"]').attr('disabled', 'disabled');
					return false;
				} else {
					$('#emailEerror').html('');
					$('input[type="submit"]').removeAttr('disabled');
					return false;
				}
			}
		});


		return false;
	}
</script>






