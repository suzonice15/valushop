<div class="col-md-offset-1 col-md-10" >
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><?php if (isset($title)) echo $title ?></h3>


		</div>
		<div class="box-body " style="height:auto">

			<form action="<?php echo base_url()?>attendance-multiple-save" class="form-horizontal"  method="post" >

				<table class="table table-bordered">
					<thead>
					<tr>
						<th scope="col">Attendance Date</th>
						<th scope="col">Class </th>
						<th scope="col"></th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td>

							<div class="input-group date" >
								<input id="datepicker" required type="text" class="form-control datepicker" name="attendance_date"  value="<?php if(isset($attendance_date)){ echo   $attendance_date ;} ?>" placeholder="Enter date:12/12/2019">
								<div class="input-group-addon">
									<span class="glyphicon glyphicon-th" id="datepicker" ></span>
								</div>
							</div>
						</td>
						<td>
							<select required name="classreg_section_id" id="classregsection_id" class="form-control select2">
								<option value="" >Select class </option>
								<?php
								if($attendances):
								foreach ($attendances as $classSectionRelation):
									?>

									<option
										<?php $selectedData= isset($classreg_section_id) ? ($classreg_section_id == $classSectionRelation->classreg_section_id ) ? 'selected="selected"' :"":"" ; echo $selectedData ;?>


										value="<?php echo $classSectionRelation->classreg_section_id; ?>" > <?php echo $classSectionRelation->classreg_section_name;?> </option>
								<?php endforeach;
								endif;
								?>
							</select>

						</td>
						<td>		<input type="submit" value="Show Student" name="attendance" class="btn btn-success pull-right">
						</td>
					</tr>

					</tbody>
				</table>


				<?php

				if(isset($attendanceData)):
				?>
				<p id="checkId" class="btn btn-success col-md-offset-1" >Mark as present</p>
				<p type="button" id="uncheckId" class="btn btn-danger col-md-offset-4">Mark as absent</p>
				<table id="tableId" class="table table-bordered table-centered ">
					<thead>
					<th>Student Name</th>
					<th>Status</th>
					</thead>
					<tbody>
					</tbody>

					<?php

					foreach ($attendanceData as $attendance) :


						?>
						<tr>
							<td><?php echo $attendance->student_name;?></td>
							<td>   <div class="custom-control custom-radio">
									<input name="student_id[]" type="hidden" value="<?php echo $attendance->student_id;?>"/>
									<input name="clasgs_id" type="hidden" value="<?php if(isset($class_id)){ echo $class_id; }?>"/>
									<input name="section_id" type="hidden" value="<?php if(isset($section_id)){ echo $section_id; }?>"/>
									<input name="attendance_date" type="hidden" value="<?php if(isset($attendance_date)){ echo $attendance_date; }?>"/>

									<input
										type="radio" id="" class="checkItem" name="status_<?php echo $attendance->student_id;?>"  value="1" class=""> Present &nbsp;
									<input


										id="select" class="uncheackItem" type="radio" id="" name="status_<?php echo $attendance->student_id;?>" value="0" class="" > Absent &nbsp;
								</div></td>
						</tr>
					<?php endforeach;
					?>


					</tbody>
				</table>

		</div>

		<div class="box-footer">
			<input type="submit" value="Save Attendance" name="saveAttendance" class="btn btn-success pull-right">
			<a class="btn btn-danger " href="<?php echo base_url();?>attendance-list">Cancel</a>

		</div>
		</form>
	</div>

	<?php
	endif;
	?>

	<script>
		$(document).ready(function(){

			$("#checkId").click(function () {
				$(".checkItem").prop('checked',true)
			});
			$("#uncheckId").click(function () {
				$(".uncheackItem").prop('checked',true)
			});
			var class_id= $("#class_id").val();
			if(class_id>0) {
				$("#studentList").hide("fast");
			}

		});

		$("#classregsection_id").change(function () {
			var classreg_section_id=$("#classregsection_id").val();
			$.ajax({
				type: "POST",
				data: {classreg_section_id: classreg_section_id},
				url: '<?php echo base_url();?>Management/AttendancesController/studentSelectionlist',
				success: function (results) {
					//alert(classreg_section_id);
					var str ="";
					var str1 ="";
					$.each(results, function (key, result) {
						var key=key+1;

						str ='<tr>'+
							'<td>'+result['student_name']+'</td>'+
							'<td><div class="custom-control custom-radio">' +
							'<input name="student_id[]" type="hidden" value="'+result['student_id']+'"/>' +
							'<input	type="radio" id="" class="checkItem" name="status_'+result['student_id']+'"  value="1" class=""> Present	<input	id="select" class="uncheackItem" type="radio" id="" ' +
							'name="status_'+result['student_id']+'" value="0" class="" > Absent '+
							'</div></td></tr>';
						str1=str1+str;
					});
					$("#tableId tbody").empty();
					$("#tableId tbody").append(str1);
				}
			});
		});

	</script>

