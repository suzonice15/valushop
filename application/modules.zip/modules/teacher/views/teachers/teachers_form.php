

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher name<span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control" name="teacher_full_name"
			   value="<?php if (isset($teacher)) echo $teacher->teacher_full_name; ?>"
			   placeholder="enter teacher name :shahinul islam">
		<input type="hidden" name="teacher_id" value="<?php if (isset($teacher)) echo $teacher->teacher_id; ?>">
	</div>
</div>

<div class="form-group">
	<label for="teacher_contact_no" class="col-sm-3 control-label">Teacher mobile<span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="number" id="teacher_contact_no" class="form-control" name="teacher_contact_no"
			   value="<?php if (isset($teacher)) echo $teacher->teacher_contact_no; ?>"
			   placeholder="enter teacher mobile :01738306670">
        <span id="mobileEerror" style="color:red"></span>
		<?php form_error('teacher_contact_no','<span style="color:red">','</span>')?>
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher address<span style="color:red"> *</span></label>

	<div class="col-md-7">
		<input required type="text" id="field-1" class="form-control" name="teacher_address"
			   value="<?php if (isset($teacher)) echo $teacher->teacher_address; ?>"
			   placeholder="enter teacher address :dhaka,bangladesh">
	</div>
</div>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher's email</label>

	<div class="col-md-7">
		<input required type="email" id="field-1" class="form-control" name="teacher_email"
			   value="<?php if (isset($teacher)) echo $teacher->teacher_email; ?>"
			   placeholder="enter teacher name :shahinul@gmail.com">
	</div>
</div>
<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher National Id Card</label>

	<div class="col-md-7">
		<input type="text" id="field-1" class="form-control" name="teacher_nid" id="teacher_nid"
			   value="<?php if (isset($teacher)) echo $teacher->teacher_nid; ?>"
			   placeholder="enter teacher nid :1991968226644868">
		<span id="nidEerror" style="color:red"></span>

	</div>
</div>

<div class="form-group">
	<label for="field-2" class="col-sm-3 control-label">Gender<span style="color:red"> *</span></label>
	<div class="col-md-7">
		<select required name="teacher_sex" class="form-control select2" id="gender_id" class="form-control">
			<option value="">Select Gender</option>
			<option <?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Female" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Female">Female
			</option>
			<option<?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Male" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Male">Male</option>
			<option <?php $selected=isset($teacher->teacher_sex)? $teacher->teacher_sex == "Other" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Other">Other</option>

		</select>
	</div>

</div>


<div class="form-group">
	<label for="field-2" class="col-sm-3 control-label">Religion <span style="color:red"> *</span></label>
	<div class="col-md-7">
		<select required name="teacher_religion" class="form-control select2" id="religion_id" class="form-control">

			<option value="">Select Religion</option>
			<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Muslim" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Muslim">Muslim
			</option>
			<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Buddist" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Buddist">
				Buddist
			</option>
			<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Christian" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Christian">
				Christian
			</option>
			<option <?php $selected=isset($teacher->teacher_religion)? $teacher->teacher_religion == "Hindu" ?  ' selected="selected"':"" :"" ; echo $selected?> value="Hindu">Hindu
			</option>
		</select>
	</div>
</div>


<div class="form-group">
	<label for="field-2" class="col-sm-3 control-label">Blood Group </label>
	<div class="col-md-7">
		<select name="teacher_blood_group" class="form-control select2" id="blood_group_id" class="form-control">
			<option value="">Select blood group</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "AB-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="AB-">AB-
			</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "AB+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="AB+">AB+
			</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "B-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="B-">B-</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "B+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="B+">B+</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "A-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="A-">A-</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "A+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="A+">A+</option>
			<option <?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "O-" ?  ' selected="selected"':"" :"" ; echo $selected?> value="O-">O-</option>
			<option<?php $selected=isset($teacher->teacher_blood_group)? $teacher->teacher_blood_group == "O+" ?  ' selected="selected"':"" :"" ; echo $selected?> value="O+">O+</option>
		</select>
	</div>
</div>

<?php if(!empty($teacher->teacher_picture_path)):?>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher picture</label>
	<div class="col-md-7">
		<img width="70" height="60" src="<?php echo base_url(); if(isset($teacher)){ echo $teacher->teacher_picture_path;} ?>"/>

		<input type="hidden"  class="form-control" name="old_teacher_picture_path" value="<?php  if(isset($teacher)){ echo $teacher->teacher_picture_path;} ?>">
	</div>
</div>
<?php else :?>

<?php endif;?>

<div class="form-group">
	<label for="field-1" class="col-sm-3 control-label">Teacher picture</label>

	<div class="col-md-7">
		<input type="file" id="field-1" class="form-control" name="teacher_picture_path">
	</div>
</div>
