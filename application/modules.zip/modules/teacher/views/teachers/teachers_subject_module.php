<div class="col-md-offset-0 col-md-12">
<div class="box  box-success">
	<div class="box-header with-border">
		

	</div>
	<div class="box-body">
<div class="table-responsive">
		<table id="example1" class="table table-bordered table-striped table-responsive ">
			<thead>
			<tr>
				<th>Sl</th>
				<th>Class</th>
				<th>Subject</th>
				<th>Subject Code</th>

			</tr>
			</thead>
			<tbody>
			<?php if (isset($teachersSubjectsData)):
				$count = 1;
				foreach ($teachersSubjectsData as $teacher):
					?>
					<tr>
						<td><?php echo $count; ?></td>						
						<td><?php echo $teacher->classreg_name; ?></td>
						<td><?php echo $teacher->subject_name; ?></td>
						<td><?php echo $teacher->subject_code; ?></td>
					</tr>
					<?php
					$count++;
				endforeach;
			endif; ?>

			</tbody>

		</table>
</div>


	</div>

</div>
</div>
