<div class="form-group">
    <label for="shiftName" class="col-sm-3 control-label">Degingation Name</label>

    <div class="col-sm-8">
        <input  required type="text" id="shiftName" class="form-control" name="designation_name"
               value="<?php if (isset($designation)) echo $designation->designation_name; ?>" placeholder="Enter Degingation Name : Text">
        <input type="hidden"  name="designation_id" value="<?php if (isset($designation)) echo $designation->designation_id; ?>">
    </div>
</div>
					
