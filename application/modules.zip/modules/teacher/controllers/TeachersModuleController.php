<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TeachersModuleController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');



	}

	public function index()
	{
		$user_role=$this->session->userdata('user_role');
		if($user_role==1 or $user_role==0)
		{
			redirect('dashboard');
		}

		$data['main'] = "Teachers";
		$data['active'] = "Teachers view";
		$data['teachers'] = $this->MainModel->getAllData('', 'teachers', '*', 'teacher_id DESC');

		$data['pageContent'] = $this->load->view('management/teachers/teachers_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Teacher registration form ";
		$data['main'] = "Teacher";
		$data['active'] = "Add teacher";
		$data['class'] = $this->MainModel->getAllData('', 'class_registrations', '*', 'classreg_id DESC');
		$data['pageContent'] = $this->load->view('management/teachers/teachers_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{


	}

	public function show($id)
	{

	}

	public function edit($id)
	{

	}

    public function update()
    {
        $teacher_id = $this->input->post('teacher_id');
        // check if the element exists before trying to edit it
        $data_id['teacher'] = $this->MainModel->getSingleData('teacher_id', $teacher_id, 'teachers', '*');
        $teacherId = $data_id['teacher']->teacher_id;
        //var_dump($teacher_id);exit();

        if (isset($teacherId)) {
            $old_teacher_picture_path=$this->input->post('old_teacher_picture_path');
            $data['teacher_picture_path']=$this->input->post('old_teacher_picture_path');
            if(isset($_FILES["teacher_picture_path"]["name"]))
            {
                if((($_FILES["teacher_picture_path"]["type"]=="image/jpg") || ($_FILES["teacher_picture_path"]["type"]=="image/jpeg") || ($_FILES["teacher_picture_path"]["type"]=="image/png") || ($_FILES["teacher_picture_path"]["type"]=="image/gif"))){
                    if(!empty($old_teacher_picture_path)){
                        unlink($old_teacher_picture_path);

                    }
                    $uploaded_image_path = "uploads/teachers/".time().'-'.$_FILES["teacher_picture_path"]["name"];
                    $config['allowed_types'] = 'jpg|jpeg|png|gif';
                    $this->load->library('upload', $config);
                    if ($_FILES["teacher_picture_path"]["error"] > 0) {
                        echo "Return Code: " . $_FILES["teacher_picture_path"]["error"] . "<br />";
                    }
                    else
                    {
                        move_uploaded_file ($_FILES["teacher_picture_path"]["tmp_name"],$uploaded_image_path);								$config['image_library'] = 'gd2';
                        $config['source_image'] = $uploaded_image_path;
                        $config['create_thumb'] = false;
                        $config['maintain_ratio'] = FALSE;
                        $config['quality'] = '60%';
                        $config['width'] = 300;
                        $config['height'] = 300;
                        $config['new_image'] = $uploaded_image_path;
                        $this->load->library('image_lib', $config);
                        $this->image_lib->resize();
                        $data['teacher_picture_path']=$uploaded_image_path;

                    }
                }}
            $data['teacher_full_name'] = $this->input->post('teacher_full_name');
            $data['teacher_nid'] = $this->input->post('teacher_nid');
            $data['teacher_title'] = $this->input->post('teacher_title');
            $data['teacher_sex'] = $this->input->post('teacher_sex');
            $data['teacher_religion'] = $this->input->post('teacher_religion');
            $data['teacher_blood_group'] = $this->input->post('teacher_blood_group');
            $data['teacher_email'] = $this->input->post('teacher_email');
            $data['teacher_address'] = $this->input->post('teacher_address');
            $userPassword = $this->input->post('user_password');
            if(isset($userPassword)){
                $userData['user_password'] =$userPassword;
               $this->MainModel->updateData('teacher_id', $teacherId, 'user', $userData);

            }

            $data['teacher_contact_no'] = $this->input->post('teacher_contact_no');

            $this->form_validation->set_rules('teacher_full_name', 'Teacher name', 'required');
            $this->form_validation->set_rules('teacher_contact_no', 'Mobile Number ', 'required|regex_match[/^[0-9]{11}$/]'); //{10} for 10 digits number
            $this->form_validation->set_rules('teacher_address', 'Teacher name', 'required');
            $this->form_validation->set_rules('teacher_sex', 'Teacher name', 'required');
            $this->form_validation->set_rules('teacher_religion', 'Teacher code', 'required');
            if ($this->form_validation->run()) {
                $result = $this->MainModel->updateData('teacher_id', $teacherId, 'teachers', $data);
                if ($result) {
                    $this->session->set_flashdata('message', "Teacher updated successfully !!!!");
                    $this->profile();
                }
            } else {

                $this->session->set_flashdata('message', "value reqiured");
               $this->profile();
            }
        } else {
            $this->session->set_flashdata('message', "The element you are trying to edit does not exist.");
            $this->profile();
        }

    }



    public function teacherNid($nid)
	{


	}

	public function destroy($id)
	{

	}


	public function teacherShiftModule()
	{

		$data['main'] = "Teacher shifts";
		$data['active'] = "View teacher shifts";
		$teacher_id= $this->session->userdata('teacher_id');


		$query="
select teacher_full_name ,classreg_name,section_name,shift_name,teacher_contact_no from teacher_shift_com
join shifts on shifts.shift_id=teacher_shift_com.shift_id
 join shift_classreg_section_com on shift_classreg_section_com.shift_id=shifts.shift_id
join classreg_section_com on classreg_section_com.classreg_section_id=shift_classreg_section_com.classreg_section_id
join sections on sections.section_id=classreg_section_com.section_id
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join teachers on teachers.teacher_id=teacher_shift_com.teacher_id
where teacher_shift_com.teacher_id=$teacher_id and teacher_shift_com.teacher_shift_isActive=1";
		$data['teachersShiftData'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('teacher/teachers/teachers_shift_module', $data, true);
		$this->load->view('layouts/main', $data);


	}

	public function teacherSubjectModule()
	{

		$data['main'] = "Teacher subjects";
		$data['active'] = "View teacher subjects";
		$teacher_id= $this->session->userdata('teacher_id');


		$query="select classreg_name,subject_code,subject_name from teacher_subject_com
join subjects on subjects.subject_id=teacher_subject_com.subject_id
join class_registrations on class_registrations.classreg_id=subjects.classreg_id
where teacher_subject_com.teacher_id=$teacher_id and teacher_subject_com.teacher_subject_isActive=1";
		$data['teachersSubjectsData'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('teacher/teachers/teachers_subject_module', $data, true);
		$this->load->view('layouts/main', $data);


	}
	 public  function  profile(){


		$uerRole=$this->session->userdata('user_role');
		if($uerRole==1 or $uerRole==2):
		 $data['main'] = "Teacher profile";
		 $data['title'] = "Update teacher profile ";
		 $data['active'] = "View teacher profile";
		 $teacher_id= $this->session->userdata('teacher_id');
		 $subjectQuery="select count(subject_id) as subject_id from teacher_subject_com where teacher_subject_com.teacher_id=$teacher_id";
		 $query="select * from user join  teachers on teachers.teacher_id=user.teacher_id  where user.teacher_id=$teacher_id";
		 $data['teachers'] = $this->MainModel->SingleQueryData($query);
		 $data['subjects'] = $this->MainModel->SingleQueryData($subjectQuery);
		 $data['pageContent'] = $this->load->view('teacher/teachers/teachers_profile', $data, true);
		 $this->load->view('layouts/main', $data);
		 else :
		redirect('student-profile');
			 endif;
	 }

	public function teacherMarkModule()
	{
		$teacher_id= $this->session->userdata('teacher_id');

		$data['main'] = "Marks ";
		$data['active'] = "Add  marks";
		$query="select subject_code,subject_name,subjects.subject_id,classreg_name from teacher_subject_com
join subjects on subjects.subject_id=teacher_subject_com.subject_id
join class_registrations on class_registrations.classreg_id=subjects.classreg_id
where teacher_subject_com.teacher_id=$teacher_id and teacher_subject_com.teacher_subject_isActive=1";
		$data['teachersSubjectsData'] = $this->MainModel->AllQueryDalta($query);
		$data['examSessions'] = $this->MainModel->getAllData('', 'exam_session_com', '*', 'exam_session_id DESC');

		$data['pageContent'] = $this->load->view('teacher/teachers/teacher_mark_module', $data, true);
		$this->load->view('layouts/main', $data);


	}

	public function teacherAttendanceModule()
	{
		$teacher_id= $this->session->userdata('teacher_id');

		$data['main'] = "Attendance  ";
		$data['active'] = "Add  attendance";
		$query="select distinct(classreg_section_name),classreg_section_id from classreg_section_com
join class_registrations on class_registrations.classreg_id=classreg_section_com.classreg_id
join subjects on subjects.classreg_id=class_registrations.classreg_id
join teacher_subject_com on teacher_subject_com.subject_id=subjects.subject_id
where teacher_subject_com.teacher_id=$teacher_id and teacher_subject_com.teacher_subject_isActive=1";
		$data['attendances'] = $this->MainModel->AllQueryDalta($query);
		$data['pageContent'] = $this->load->view('teacher/teachers/teacher_attendance_module', $data, true);
		$this->load->view('layouts/main', $data);


	}
	public function MultipleStudentSelection()
	{
		$examSessionId = $this->input->post('exam_session_id');
		$subjectId = $this->input->post('subject_id');
		$query="select A.student_name,A.student_id,B.mark_obtained,B.mark_grade_point, B.mark_gpa,B.student_id as mark_student_id from  (select  students.student_name,students.student_id,students.student_roll,subjects.*  from subjects    
		join class_registrations on class_registrations.classreg_id=subjects.classreg_id 
	join classreg_section_com on classreg_section_com.classreg_id=class_registrations.classreg_id 
join student_classreg_section_com on student_classreg_section_com.classreg_section_id=classreg_section_com.classreg_section_id
join students on student_classreg_section_com.student_id=students.student_id 
where subjects.subject_id=$subjectId  and student_classreg_section_com.student_classreg_section_isActive=1  ) A  left join (select marks.*,marks.student_id as student_mark_id from marks  join subjects on subjects.subject_id=marks.subject_id join students on marks.student_id=students.student_id
where  subjects.subject_id=$subjectId and  exam_session_id=$examSessionId) B on A.student_id=B.student_id";
		$data['students']=$this->MainModel->AllQueryDalta($query);
		echo json_encode($data);
	}



}
