<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DegingationsController extends MX_Controller
{

	public function __construct()
	{
		$this->load->model('MainModel');
//		$userId=$this->session->userdata('user_id');
//		if($userId ==null){
//			redirect('admin');
//
//		}
	}

	public function index()
	{
		$data['main'] = "designations";
		$data['active'] = "designations view";
		$data['designations'] = $this->MainModel->getAllData('', 'designations', '*', 'designation_id DESC');
		$data['pageContent'] = $this->load->view('teacher/designations/designations_index', $data, true);
		$this->load->view('layouts/main', $data);
	}

	public function create()
	{
		$data['title'] = "Designation registration form ";
		$data['main'] = "Designation";
		$data['active'] = "Add designation";
		$data['pageContent'] = $this->load->view('teacher/designations/designations_create', $data, true);
		$this->load->view('layouts/main', $data);
	}


	public function store()
	{

		$data['designation_name'] = $this->input->post('designation_name');
		$this->form_validation->set_rules('designation_name', 'designation name', 'required');
		if ($this->form_validation->run()) {
			$result = $this->MainModel->insertData('designations', $data);
			if ($result) {
				$this->session->set_flashdata('message', "Designation added successfully !!!!");
				redirect('degingation-create');
			}
		} else {

			$this->session->set_flashdata('error', "value reqiured");
			redirect('degingation-create');
		}


	}

	public function show($id)
	{

	}

	public function edit($id)
	{


		$data['designation'] = $this->MainModel->getSingleData('designation_id', $id, 'designations', '*');
		$designationId = $data['designation']->designation_id;

		if ($designationId) {

			$data['title'] = "Designation update page ";
			$data['main'] = "Designation";
			$data['active'] = "Update designation";
			$data['pageContent'] = $this->load->view('teacher/designations/designations_edit', $data, true);
			$this->load->view('layouts/main', $data);
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('designation-list');
		}


	}

	public function update()
	{
		$designationId = $this->input->post('designation_id');
		// check if the element exists before trying to edit it
		$designationData = $this->MainModel->getSingleData('designation_id', $designationId, 'designations', '*');
		$designationId = $designationData->designation_id;

		if (isset($designationId)) {
			$data['designation_name'] = $this->input->post('designation_name');
			$this->form_validation->set_rules('designation_name', 'designation name', 'required');
			if ($this->form_validation->run()) {
				$result = $this->MainModel->updateData('designation_id', $designationId, 'designations', $data);
				if ($result) {
					$this->session->set_flashdata('message', "Designation updated successfully !!!!");
					redirect('degingation-list');
				}
			} else {
				//$data['message'] = "value reqiured";
				//  $this->session->set_userdata($data);
				$this->session->set_flashdata('error', "value reqiured");
				redirect('degingation-update');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to edit does not exist.");
			redirect('degingation-list');
		}


	}


	public function destroy($id)
	{
		$designationData = $this->MainModel->getSingleData('designation_id', $id, 'designations', '*');
		$designationId = $designationData->designation_id;

		if (isset($designationId)) {
			$result = $this->MainModel->deleteData('designation_id', $designationId, 'designations');
			if ($result) {


				$this->session->set_flashdata('message', "Designation deleted successfully !!!!");
				redirect('degingation-list');
			}
		} else {
			$this->session->set_flashdata('error', "The element you are trying to delete does not exist.");
			redirect('degingation-list');
		}
	}


}
