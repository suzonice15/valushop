<aside class="main-sidebar">
	<!-- sidebar: style can be found in sidebar.less -->
	<section class="sidebar">
		<!-- Sidebar user panel -->
		<div class="user-panel">
			<div class="pull-left image">
				<?php  if($this->session->userdata('teacher_picture_path')){ ?>
				<img src="<?php echo base_url(); ?><?php echo $this->session->userdata('teacher_picture_path')?>" class="img-circle"
					 alt="<?php echo $this->session->userdata('teacher_full_name')?>">
				<?php }  else { ?>

				<img src="<?php echo base_url(); ?><?php echo $this->session->userdata('student_picture_path')?>" class="img-circle"
					 alt="<?php echo $this->session->userdata('student_name')?>">
				<?php } ?>
			</div>
			<div class="pull-left info">
				<p>

					<?php
					$userRole=$this->session->userdata('user_role');

					if($userRole==2) {
						if (($this->session->userdata('teacher_full_name'))) {
							echo $this->session->userdata('teacher_full_name');
						}
						else {
							echo $this->session->userdata('student_name');
						}
						} else {
						if (($this->session->userdata('teacher_full_name'))) {
							echo $this->session->userdata('teacher_full_name');
						}
						else {
							echo $this->session->userdata('student_name');
						}

					}

					?>

				</p>
				<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
			</div>
		</div>

		<!-- /.search form -->
		<!-- sidebar menu: : style can be found in sidebar.less -->
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header"><a href="#">MAIN NAVIGATION </a></li>
			<li class="">
				<a href="<?php echo base_url(); ?>dashboard">
					<i class="fa fa-dashboard"></i> <span>Dashboard</span>

				</a>

			</li>



			<?php if($userRole==1):?>
			<li class=" ">
				<a href="<?php echo base_url(); ?>session-list">
					<i class="fa fa-user-secret"></i>
					<span>Sessions</span>

				</a>
			</li>
			<li class=" ">
				<a href="<?php echo base_url(); ?>shift-list">
					<i class="fa fa-user-secret"></i>
					<span>Shifts</span>

				</a>
			</li>

			<li class=" ">
				<a href="<?php echo base_url(); ?>section-list">
					<i class="fa fa-user-secret"></i>
					<span>Sections</span>

				</a>
			</li>

			<li class=" ">
				<a href="<?php echo base_url(); ?>class-list">
					<i class="fa fa-user-secret"></i>
					<span>Classes</span>

				</a>
			</li>

			<li class=" ">
				<a href="<?php echo base_url(); ?>subject-list">
					<i class="fa fa-user-secret"></i>
					<span>Subjects</span>

				</a>
			</li>

				<li class="treeview">
					<a href="#">
						<i class="fa fa-folder-o"></i>
						<span>Teachers </span>
						<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

					</a>
					<ul class="treeview-menu">
						<li>
						<a href="<?php echo base_url(); ?>degingation-list">
							<i
								class="fa fa-arrow-circle-o-right"></i>
							<span>designation </span>

						</a>
						</li>
						<li><a href="<?php echo base_url(); ?>teacher-create"><i
									class="fa fa-arrow-circle-o-right"></i> Add Teachers  </a></li>


						<li >
						<li><a href="<?php echo base_url(); ?>teacher-list"><i
									class="fa fa-arrow-circle-o-right"></i> Teachers list </a></li>


						<li >

						</li>



					</ul>
				</li>


			<li class="treeview">
				<a href="#">
					<i class="fa fa-folder-o"></i>
					<span>Students </span>
					<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

				</a>
				<ul class="treeview-menu">

					<li><a href="<?php echo base_url(); ?>student-list"><i
								class="fa fa-arrow-circle-o-right"></i> Student list </a></li>


					<li >
						<a href="<?php echo base_url(); ?>student-class-section-multiple-relation">
							<i
								class="fa fa-arrow-circle-o-right"></i>
							<span>Admit Student </span>

						</a>
					</li>

					<li >
						<a href="<?php echo base_url(); ?>promotion-create">
							<i
								class="fa fa-arrow-circle-o-right"></i>
							<span>promotion</span>

						</a>
					</li>

				</ul>
			</li>
			<li class=" ">
				<a href="<?php echo base_url(); ?>examination-list">
					<i class="fa fa-user-secret"></i>
					<span>Examinations</span>

				</a>
			</li>
				<li class="treeview">
					<a href="#">
						<i class="fa fa-folder-o"></i>
						<span>Class room </span>
						<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

					</a>
					<ul class="treeview-menu">
						<li>
							<a href="<?php echo base_url(); ?>class-room-create">
								<i class="fa fa-arrow-circle-o-right"></i>
								<span>Add room</span>

							</a>
						</li>
						<li><a href="<?php echo base_url(); ?>class-room-list"><i class="fa fa-arrow-circle-o-right"></i> View
								room </a></li>
					</ul>
				</li>
				<li class="treeview">
				<a href="#">
					<i class="fa fa-user-secret"></i> <span>Accounting</span>
					<span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
				</a>
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url(); ?>expense-list"><i
								class="fa fa-arrow-circle-o-right"></i>Income/Expense Category</a></li>
					<li class="treeview">
						<a href="#"><i class="fa fa-circle-o"></i> Incomes
							<span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
						</a>
						<ul  class="treeview-menu">
							<li><a href="<?php echo base_url(); ?>invoice-create"><i class="fa fa-plus"></i>Add Student Fee </a></li>
							<li><a href="<?php echo base_url(); ?>invoice-all"><i class="fa fa-plus"></i>View Student  Fee </a></li>
							<li><a href="<?php echo base_url(); ?>invoice-resident"><i class="fa fa-plus"></i>Add Resident Student Fee </a></li>
							<li><a href="<?php echo base_url(); ?>invoice-resident-all"><i class="fa fa-plus"></i>View Resident Student  Fee </a></li>

							<li><a href="<?php echo base_url(); ?>income-money-create"><i class="fa fa-plus"></i>Add Money   Received </a></li>
							<li><a href="<?php echo base_url(); ?>income-money-list"><i class="fa fa-plus"></i>View Money   Received </a></li>


							<li><a href="<?php echo base_url(); ?>income-create"><i class="fa fa-plus"></i>Add Madrasah income </a></li>
							<li><a href="<?php echo base_url(); ?>income-all"><i class="fa fa-plus"></i>View Madrasah income </a></li>
						</ul>
					</li>

					<li class="treeview" >
						<a href="#"><i class="fa fa-circle-o"></i> Expenses
							<span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
						</a>
						<ul class="treeview-menu">
							<li><a href="<?php echo base_url(); ?>expenses-create"><i class="fa fa-plus"></i>Add expense </a></li>
							<li><a href="<?php echo base_url(); ?>expenses-all"><i class="fa fa-plus"></i>View expenses </a></li>
						</ul>
							<li  class="treeview">
								<a href="#"><i class="fa fa-circle-o"></i> Income/Expenses report
									<span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
								</a>
								<ul class="treeview-menu" >
									<li><a href="<?php echo base_url(); ?>student-invoice"><i class="fa fa-plus"></i>Student fee report</a></li>
									<li><a href="<?php echo base_url(); ?>invoice-list"><i class="fa fa-plus"></i>Class wise fee report</a></li>

									<li><a href="<?php echo base_url(); ?>resident-student-invoice"><i class="fa fa-plus"></i> Resident Student fee report</a></li>
									<li><a href="<?php echo base_url(); ?>resident-invoice-list"><i class="fa fa-plus"></i>Resident Class wise fee report</a></li>
									<li><a href="<?php echo base_url(); ?>income-money-recieved-report"><i class="fa fa-plus"></i>Money received report</a></li>

									<li><a href="<?php echo base_url(); ?>madrasah-income-list"><i class="fa fa-plus"></i> Madrasah Income report</a></li>
									<li><a href="<?php echo base_url(); ?>income-list"><i class="fa fa-plus"></i>Total Income Report</a></li>

									<li><a href="<?php echo base_url(); ?>expenses-list"><i class="fa fa-plus"></i> Total Expense report</a></li>
									<li><a href="<?php echo base_url(); ?>income-report-form"><i class="fa fa-plus"></i>Profit /loss</a></li>
									<li><a href="<?php echo base_url(); ?>income-expense-report-page"><i class="fa fa-plus"></i>Total Income/Expense repost one page </a></li>


						</ul>
					</li>
				</ul>
			</li>

			<li class="treeview">
				<a href="#">
					<i class="fa fa-folder-o"></i>
					<span>Report </span>
					<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

				</a>
				<ul class="treeview-menu">
					<!--					<li><a href="-->
					<?php //echo base_url(); ?><!--class-section-list"><i class="fa fa-arrow-circle-o-right"></i>-->
					<!--							Class report </a></li>-->

					<li><a href="<?php echo base_url(); ?>class-section-shift-list"><i
								class="fa fa-arrow-circle-o-right"></i> Class report </a></li>

					<li><a href="<?php echo base_url(); ?>teacher-shift-list"><i class="fa fa-arrow-circle-o-right"></i>Shifts
							report</a>
					</li>

					<li><a href="<?php echo base_url(); ?>teacher-subject-list"><i
								class="fa fa-arrow-circle-o-right"></i>Teacher report</a></li>

					<li><a href="<?php echo base_url(); ?>student-class-section-list"><i
								class="fa fa-arrow-circle-o-right"></i>Students report</a></li>
					<li><a href="<?php echo base_url(); ?>exam-session-list"><i class="fa fa-arrow-circle-o-right"></i>Session
							reports</a></li>

				</ul>
			</li>

			<?php endif;?>

			<?php if($userRole==1):?>

				<li class="treeview">
					<a href="#">
						<i class="fa fa-folder-o"></i>
						<span>Holiday </span>
						<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

					</a>
					<ul class="treeview-menu">
						<li>
							<a href="<?php echo base_url(); ?>holiday-create">
								<i class="fa fa-user-secret"></i>
								<span>Add holiday</span>

							</a>
						</li>

						<li><a href="<?php echo base_url(); ?>holiday-list"><i class="fa fa-arrow-circle-o-right"></i> view holiday </a></li>

					</ul>
				</li>
			<li class=" ">
					<a href="<?php echo base_url(); ?>attendance-list">
						<i class="fa fa-user-secret"></i>
						<span>Attendance</span>

					</a>
				</li>
				<li class=" ">
					<a href="<?php echo base_url(); ?>attendence-monthly">
						<i class="fa fa-user-secret"></i>
						<span>Montly attendance</span>

					</a>
				</li>
				<li class=" ">
					<a href="<?php echo base_url(); ?>marksheet">
						<i class="fa fa-user-secret"></i>
						<span>Marksheet</span>

					</a>
				</li>

			<li class="treeview">
				<a href="#">
					<i class="fa fa-folder-o"></i>
					<span>Marks </span>
					<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

				</a>
				<ul class="treeview-menu">
					<li>
						<a href="<?php echo base_url(); ?>mark-multiple-form">
							<i class="fa fa-user-secret"></i>
							<span>Add mark</span>

						</a>
					</li>
					<li>
						<a href="<?php echo base_url(); ?>mark-written-mcq-form">
							<i class="fa fa-user-secret"></i>
							<span>Add mark for Written and MCQ </span>

						</a>
					</li>
					<li>
						<a href="<?php echo base_url(); ?>practical-mark-form">
							<i class="fa fa-user-secret"></i>
							<span>Add Practical mark</span>

						</a>
					</li>

					<li><a href="<?php echo base_url(); ?>mark-list"><i class="fa fa-arrow-circle-o-right"></i> Subject
							wise </a></li>

					<li><a href="<?php echo base_url(); ?>mark-student"><i class="fa fa-arrow-circle-o-right"></i>student
							wise </a></li>


				</ul>
			</li>
<?php endif;?>





			<?php if($userRole==2) : ?>

				<li class=" ">
					<a href="<?php echo base_url(); ?>mark-sheet-create">
						<i class="fa fa-user-secret"></i>
						<span>marksheet</span>
					</a>
				</li>
				<li class="">
					<a href="<?php echo base_url(); ?>class-routine-list">
						<i class="fa fa-user-secret"></i>
						<span>View class routine</span>

					</a>
				</li>
				<li class="">
					<a href="<?php echo base_url(); ?>holiday-list">
						<i class="fa fa-user-secret"></i>
						<span>View Holiday</span>

					</a>
				</li>
			<li class="">
				<a href="<?php echo base_url(); ?>teacher-shift-module">
					<i class="fa fa-user-secret"></i>
					<span>Teachers shift</span>

				</a>
			</li>
			<li class="">
				<a href="<?php echo base_url(); ?>teacher-subject-module">
					<i class="fa fa-user-secret"></i>
					<span>Teachers subject</span>

				</a>
			</li>

			<li class="">
				<a href="<?php echo base_url(); ?>teacher-mark-module">
					<i class="fa fa-user-secret"></i>
					<span>Teachers mark</span>

				</a>
			</li>

			<li class="">
				<a href="<?php echo base_url(); ?>teacher-attendance-module">
					<i class="fa fa-user-secret"></i>
					<span>Attendance</span>

				</a>
			</li>
			<?php endif;?>
			<?php if($userRole==0) : ?>
				<li class=" ">
					<a href="<?php echo base_url(); ?>single-student-attendce">
						<i class="fa fa-user-secret"></i>
						<span>Attendace report</span>
					</a>
				</li>
				<li class=" ">
					<a href="<?php echo base_url(); ?>single-student-mark">
						<i class="fa fa-user-secret"></i>
						<span>Student Mark</span>
					</a>
				</li>

			<li class=" ">
				<a href="<?php echo base_url(); ?>student-marksheet">
					<i class="fa fa-user-secret"></i>
					<span>Student marksheet</span>
				</a>
			</li>
			<li class="">
				<a href="<?php echo base_url(); ?>class-routine-list">
					<i class="fa fa-user-secret"></i>
					<span>View class routine</span>

				</a>
			</li>
				<li class=" ">
					<a href="<?php echo base_url(); ?>single-student-fee">
						<i class="fa fa-user-secret"></i>
						<span>Student fee</span>
					</a>
				</li>
				<li class=" ">
					<a href="<?php echo base_url(); ?>single-student-fee-history">
						<i class="fa fa-user-secret"></i>
						<span>Fee history</span>
					</a>
				</li>
				<li class="">
					<a href="<?php echo base_url(); ?>holiday-list">
						<i class="fa fa-user-secret"></i>
						<span>View Holiday</span>

					</a>
				</li>
			<?php endif;?>



			<?php if($userRole==1):?>
			<li class="treeview">
				<a href="#">
					<i class="fa fa-user-secret"></i>
					<span>Class routine </span>
					<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

				</a>
				<ul class="treeview-menu">


					<li>
						<a href="<?php echo base_url(); ?>class-routine-create">
							<i class="fa fa-arrow-circle-o-right"></i>
							<span>Add routine</span>

						</a>
					</li>


					<li><a href="<?php echo base_url(); ?>class-routine-list"><i class="fa fa-arrow-circle-o-right"></i> View
							routine </a></li>



				</ul>
			</li>
			<?php endif;?>
<?php if($userRole==1):?>
			<li class="treeview">
				<a href="#">
					<i class="fa fa-user-secret"></i>
					<span>Users </span>
					<span class="pull-right-container">
			 <i class="fa fa-angle-left pull-right"></i>
			 </span>

				</a>
				<ul class="treeview-menu">
					<li>
						<a href="<?php echo base_url(); ?>user-create">
							<i class="fa fa-arrow-circle-o-right"></i>
							<span>Add User</span>

						</a>
					</li>

					<li><a href="<?php echo base_url(); ?>user-list"><i class="fa fa-arrow-circle-o-right"></i> View
							User </a></li>



				</ul>
			</li>
			<?php endif;?>
			<?php if($userRole==1 or $userRole==2):?>
			<li class="">
				<a href="<?php echo base_url(); ?>sating-create">
					<i class="fa fa-user-secret"></i>
					<span>Settings </span>

				</a>
			</li>
			<?php endif;?>



		</ul>
	</section>
	<!-- /.sidebar -->
</aside>
