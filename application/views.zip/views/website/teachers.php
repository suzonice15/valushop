<div class="container-fluid body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<li><?php  echo 'শিক্ষকবৃন্দ'; ?></li>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg">

				<div class="row">
					<div class="col-md-12">
						<div class="panel_box min_height clearfix">


							<?php if(isset($teachers)) :foreach ($teachers as $teacher):?>
								<div class="col-md-3 col-lg-3 col-sm-4 col " style="padding: 10px">
									<div>
										<img style="height: 263px;" class="img-thumbnail" src="<?php echo base_url();echo $teacher->teacher_picture_path;?>" width="100%" >
									</div>
									<div class="left bg-success " style="padding:5px ">
										<h3><i class="fa fa-user"> </i> <?php echo  $teacher->teacher_full_name;?></h3>
										<h3><i class="fa fa-phone"> </i> <?php echo  $teacher->teacher_contact_no;?></h3>
										<h3><i class="fa fa-envelope"> </i> <?php echo  $teacher->teacher_email;?></h3>
										<h3><i class="fa fa-map-marker"> </i> <?php echo  $teacher->teacher_address;?></h3>


									</div>
								</div>

							<?php endforeach;endif;?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
