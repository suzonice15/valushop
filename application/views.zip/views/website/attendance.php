<div class="container body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<li><?php  echo 'আজকের  উপস্থিতি'; ?></li>
		</ul>
	</section>
    <section>
        <div class="row">
            <div class="col-md-12 bg">

                <div class="row">
                    <div class="col-md-12">
                        <div style="border:none" class="panel_box min_height clearfix">

                            <table class="table table-bordered">
                                <tr>

                                    <th>ক্রমিক</th>
                                    <th>শ্রেণী</th>
                                    <th>মোট</th>
                                    <th>উপস্থিতি</th>
                                    <th>অনুপস্থিত</th>
                                </tr>
                                <tbody>
                                <?php



                                $total=0;
                                $className=array();
                                $i=0;
                                foreach ($classSections as $classSection):
                                    $prsent=0;
                                    $absent=0;
                                    foreach ($attendaces as $attendace):
                                        if($classSection->classreg_section_id==$attendace->classreg_section_id) {
                                            if ($attendace->attendance_type == 1) {
                                                $prsent = $prsent + 1;
                                            } else {
                                                $absent = $absent + 1;
                                            }

                                        }
                                    endforeach;
                                    $query="select count(student_classreg_section_id) as totalStudent from student_classreg_section_com 
where student_classreg_section_com.classreg_section_id=$classSection->classreg_section_id 
and student_classreg_section_com.student_classreg_section_isActive=1";
                                    $studentTotal = $this->MainModel->SingleQueryData($query);



                                    ?>

                                    <tr>
                                        <td><?php echo ++$i;?></td>
                                        <td><?php echo $classSection->classreg_section_name;?></td>
                                        <td><?php echo $studentTotal->totalStudent;?></td>
                                        <td><?php echo $prsent;?></td>
                                        <td><?php echo $absent;?></td>



                                    </tr>
                                <?php   endforeach; ?>
                                </tbody>
                            </table>



                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
