<!--<div class="container-fluid">-->
<!--	<div class="row">-->
<!--		<div class="col-md-3">-->
<!--			<img  width="300" src="--><?php //echo base_url()?><!--uploads/aminul.jpg"/>-->
<!---->
<!--		</div><div class="col-md-3">-->
<!--			<img width="300" src="--><?php //echo base_url()?><!--uploads/aminul.jpg"/>-->
<!---->
<!--		</div><div class="col-md-3">-->
<!--			<img width="300" src="--><?php //echo base_url()?><!--uploads/aminul.jpg"/>-->
<!---->
<!--		</div><div class="col-md-3">-->
<!--			<img width="300" src="--><?php //echo base_url()?><!--uploads/aminul.jpg"/>-->
<!---->
<!--		</div>-->
<!--	</div>-->
<!--</div>-->

<div class="inner-banner">
	<div class="container">
		<div class="col-sm-12">
			<h2>Our Marketing Officer</h2>
		</div>
		<div class="col-sm-12 inner-breadcrumb">
			<ul>
				<li><a href="<?php echo base_url()?>">Home</a></li>
				<li>marketing officer</li>
			</ul>
		</div>
	</div>
</div>
<section class="inner-wrapper">
	<div class="inner-wrapper-main">
		<div class="row">

		<?php if(isset($marketers)) : foreach ($marketers as $marketer):?>
		<div class="col-md-3 col-lg-3 col-sm-4 col " style="padding: 10px">
			<div>
				<img class="img-thumbnail" width="100%" height="10%" src="<?php echo base_url();echo $marketer->marketer_picture_path;?>"/>
			</div>
				<div class="left bg-success "  style="padding:5px ">
					<h3><i class="fa fa-user"></i><?php echo  $marketer->marketer_name;?></h3>
					<h3><i class="fa fa-phone"></i><?php echo  $marketer->marketer_mobile;?></h3>
					<h3><i class="fa fa-envelope"></i><?php echo  $marketer->marketer_email;?></h3>
					<h3><i class="fa fa-map-marker"></i><?php echo  $marketer->d_name;?></h3>
					<h3><i class="fa fa-location-arrow"></i><?php echo  $marketer->marketer_address;?></h3>

				</div>
				</div>
		<?php endforeach;endif;?>



	</div>
	</div>
	</div>
</div>
<div class="call-to-action">
	<div class="container">
		<h3>Welcome to Amana Agro Science</h3>
		<p>We need some merketing officer apply now </p>
		<a href="javascript:void(0)">Apply</a> </div>
</div>
