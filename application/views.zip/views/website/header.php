<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title> Bandaria siddikia kamil madrasah  - Leading Madrasha in Bangladesh</title>
	<meta name="Description" content=" Bandaria siddikia kamil madrasah  is a non-profitable and non-political organization approved by the government of the people’s republic of Bangladesh; which has been working as an education mission since 1999."/>
	<meta name="keywords" content="Madrasha in Bangladesh, BD cadate madrasha list, list of education board, Bangaldesh madrasha education board, new top list of Madrasha, usbd tech ltd, software development of usbdtech.org, madrasha news, tanzim news, allbanglanewspaperlist.com "/>	<link href="img/favicon.ico" rel='icon' type='image/x-icon'/>
	<!--|Font Family (Google Fonts)|-->
	<link href='https://fonts.googleapis.com/css?family=Arvo:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
	<!-- Bootstrap -->
	<link href="<?php echo base_url()?>assets/fontend/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/fontend/css/fonts.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/fontend/css/SiyamRupali.css" rel="stylesheet">
	<!--Font Icon (font-awesome)-->
<!--	<link rel="stylesheet" href="--><?php //echo base_url()?><!--assets/fontend/css/font-awesome.min.css">-->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/bower_components/font-awesome/css/font-awesome.min.css">
	<script src="<?php echo base_url()?>assets/fontend/js/jquery.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {

			$("a#example1").fancybox();

			$("a#example2").fancybox({
				'overlayShow'	: false,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'elastic'
			});

			$("a#example3").fancybox({
				'transitionIn'	: 'none',
				'transitionOut'	: 'none'
			});

			$("a#example4").fancybox({
				'opacity'		: true,
				'overlayShow'	: false,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'none'
			});

			$("a#example5").fancybox();

			$("a#example6").fancybox({
				'titlePosition'		: 'outside',
				'overlayColor'		: '#000',
				'overlayOpacity'	: 0.9
			});

			$("a#example7").fancybox({
				'titlePosition'	: 'inside'
			});

			$("a#example8").fancybox({
				'titlePosition'	: 'over'
			});

			$("a[rel=example_group]").fancybox({
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'titlePosition' 	: 'over',
				'titleFormat'		: function(title, currentArray, currentIndex, currentOpts) {
					return '<span id="fancybox-title-over">Image ' + (currentIndex + 1) + ' / ' + currentArray.length + (title.length ? ' &nbsp; ' + title : '') + '</span>';
				}
			});

			/*
			*   Examples - various
			*/

			$("#various1").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});

			$("#various2").fancybox();

			$("#various3").fancybox({
				'width'				: '75%',
				'height'			: '75%',
				'autoScale'			: false,
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'type'				: 'iframe'
			});

			$("#various4").fancybox({
				'padding'			: 0,
				'autoScale'			: false,
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
		});
	</script>

	<!--preloader-->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/fontend/css/preloader.css">
	<script src="<?php echo base_url()?>assets/fontend/js/modernizr-2.6.2.min.js"></script>
	<!--Owl Carousel-->
	<link href="<?php echo base_url()?>assets/fontend/css/owl.carousel.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/bower_components/fullcalendar/dist/fullcalendar.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>assets/bower_components/fullcalendar/dist/fullcalendar.print.min.css" media="print">
	<!-- magnific popup -->

	<link rel="stylesheet" href="<?php echo base_url()?>assets/fontend/css/magnific-popup.css">
	<!--custom css-->
	<link href="<?php echo base_url()?>assets/fontend/css/menu.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/fontend/css/style.css?var=2" rel="stylesheet">


	<link rel="stylesheet" href="<?php echo base_url()?>assets/fontend/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="<?php echo base_url()?>assets/fontend/js/html5shiv.min.js"></script>
	<script src="<?php echo base_url()?>assets/fontend/js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
<!--preloader-->
<!--<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>--><!--end preloader-->

<a href="#top" id="toTop"></a>
<div class="container-fluid padding-lr-0">
	<header class="header" >
		<div class="container">
			<div class="row" >

				<div class="col-md-2">
					<div class="logo"><a   href="<?php echo base_url();?>"><img  src="<?php echo base_url();echo $headers[0]->logo; ?>" alt=""></a></div>
				</div>

				<div class="col-md-10">
					<div class="banner">
						<h3 style="text-transform:uppercase;font-size: 40px;"><?php echo  $headers[0]->header_one; ?> </h3>
						<h3  style="text-transform:uppercase;font-size: 40px;"><?php echo  $headers[0]->header_arrabic; ?>  </h3>
						<h3 style="text-transform:uppercase;font-size: 20px;"><?php echo  $headers[0]->header_address; ?></h3>
					</div>
				</div>

			</div>
		</div>
	</header>
	<div class="main_navbar">
		<div class="container">
			<div id='cssmenu'>
				<ul>
					<!--<li class="active"><a href='#'><span>Home</span></a></li>-->
					<li><a href='<?php echo base_url()?>'><span>হোম</span></a></li>
					<li class='has-sub'><a href='#'><span>আমাদের বিষয়</span></a>
						<ul>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>about-us" title="মাদরাসা সম্পর্কে">
									মাদরাসা সম্পর্কে                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>purpose" title="লক্ষ্য ও উদ্দেশ্য">
									লক্ষ্য ও উদ্দেশ্য                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>principal-rule" title="মূলনীতি">
									মূলনীতি                                                                            </a>
							</li>


							<li>
								<a target="_#" class="" href="<?php echo base_url()?>message" title="অধ্যক্ষের বাণী">
									অধ্যক্ষের বাণী                                                                            </a>
							</li>
						</ul>
					</li>

					<li class='has-sub'><a href='#'><span>কার্যাবলী</span></a>
						<ul>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>anual-happay" title="বার্ষিক অনুষ্ঠান">
									বার্ষিক অনুষ্ঠান                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>education-travel" title="শিক্ষা সফর">
									শিক্ষা সফর                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>play" title="ক্রীড়া">
									ক্রীড়া                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>club" title="ক্লাব">
									ক্লাব                                                                            </a>
							</li>


						</ul>
					</li>
					<li class='has-sub'><a href='#'><span>  গ্যালারি</span></a>
						<ul>
							<li>
					<a target="_#" class="" href="<?php echo base_url()?>anual-happay" title="বার্ষিক অনুষ্ঠান">
									বার্ষিক অনুষ্ঠান                                                                            </a>
							</li>
							<li>
								<a target="_#" class="" href="<?php echo base_url()?>gelary-picture" title="শিক্ষা সফর">
									গ্যালারি ছবি                                                                            </a>
							</li>



						</ul>
					</li>
					<li><a href='<?php echo base_url()?>teacher'><span>শিক্ষকবৃন্দ </span></a></li>
					<li><a href='<?php echo base_url()?>department-head'><span>বিভাগীয় দায়িত্বশীল</span></a></li>
					<li><a href='<?php echo base_url()?>government-body'><span>গভরনিং বডি  </span></a></li>
					<li><a href='<?php echo base_url()?>calender'><span>শিক্ষা পঞ্জিকা</span></a></li>
					<li><a href='<?php echo base_url()?>attendance'><span>উপস্থিতি</span></a></li>
					<li><a href='<?php echo base_url()?>routine-view'><span>ক্লাস রুটিন</span></a></li>
					<li><a href='<?php echo base_url()?>contact'><span>যোগাযোগ</span></a></li>
				</ul>
			</div>
		</div>
	</div>	  </div>
<!--header-->

<div class="container body_bg">
	<div class="row">
		<?php
				if(isset($newsActiveStatus)){


		?>
		<div class="breaking_box">
			<ul id="newsticker">

				<?php
				if(isset($newsInactive)): foreach ($newsInactive as $news):?>
			<li><a href="<?php echo base_url()?>detail/<?php echo $news->news_id; ?>"><?php echo $news->news_name;?></a></li>
				<?php endforeach;endif;  ?>

			</ul>
		</div>
	<?php 	}  else {  } ?>



