<?php $this->load->view('website/header');?>
<?php echo $main;?>
<?php $this->load->view('website/footer');?>
