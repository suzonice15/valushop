<div class="container body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<?php if($heads[0]->marketer_status==1):?>
				<li><?php  echo 'বিভাগীয় দায়িত্বশীল'; ?></li>
			<?php else:?>
			<li><?php  echo 'গভরনিং বডি'; ?></li>
		<?php endif;?>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg">

				<div class="row">
					<div class="col-md-12">
						<div class="panel_box min_height clearfix">


							<?php if(isset($heads)) :foreach ($heads as $head):?>
							<div class="col-md-3 col-lg-3 col-sm-4 col " style="padding: 10px">
								<div>
									<img style="height: 263px;" class="img-thumbnail" src="<?php echo base_url();echo $head->marketer_picture_path;?>" width="100%" >
								</div>
								<div class="left bg-success " style="padding:5px ">
									<h3><i class="fa fa-user"> </i> <?php echo  $head->marketer_name;?></h3>
									<h3><i class="fa fa-phone"> </i> <?php echo  $head->marketer_mobile;?></h3>
									<h3><i class="fa fa-envelope"> </i> <?php echo  $head->marketer_email;?></h3>
									<h3><i class="fa fa-location-arrow"> </i> <?php echo  $head->designation_name;?></h3>


								</div>
							</div>

							<?php endforeach;endif;?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
