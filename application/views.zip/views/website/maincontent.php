<div class="col-md-12 no-padding">
	<div class="slider">

		<div id="myCarousel" class="carousel slide" data-ride="carousel">
			<!-- Indicators -->
			<ol class="carousel-indicators">
				<?php if(isset($sliders)) :
					$i=0;
					foreach ($sliders as $slider):?>
				<li data-target="#myCarousel" data-slide-to="<?php echo $i;?>" class="<?php if($i==0){ echo 'active'; }else { echo '';}  ?>"></li>

		<?php $i++;
		endforeach;endif;?>


			</ol>

			<!-- Wrapper for slides -->
			<div class="carousel-inner" role="listbox">
				<?php if(isset($sliders)) :
				$i=0;
				foreach ($sliders as $slider):?>
				<div class="item <?php if($i==0){ echo 'active'; }else { echo '';}  ?>">

					<img  src='<?php echo base_url();echo $slider->slider_image;?>' width='1135' height='450' />

				</div>

					<?php $i++;
				endforeach;endif;?>

			<!-- Left and right controls -->
			<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				<span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>

	</div>
</div>

</div>

<div class="dividers"></div>

<section class="welcome_bg_b">
	<div class="row">
		<div  class="col-md-12">
			<h4>Welcome to Bandaria Siddikia Fazil Madrasah. </h4>
			<?php if(isset($headers[0])){

				$welcome= $headers[0]->welcome;
				echo $welcome;
			}?>
			<div class="clearfix"></div>
		</div>
	</div>
</section>
<div class="dividers"></div>
<section>
	<div class="row">
		<div class="col-md-9 bg">
			<div class="row">
				<div class="col-md-12">
					<div class="achievement">
						<div class="title_achievement">আমাদের অর্জনসমূহ</div>
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

							<?php if($achivements):

							foreach ($achivements as $achivement):
								$i=	2;

								?>


							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="<?php echo $i;?>">

									<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $achivement->achivement_id;?>" aria-expanded="false" aria-controls="collapse<?php echo $achivement->achivement_id;?>">
										<h4 class="panel-title"><i class="fa fa-arrow-right"></i><?php echo $achivement->achivement_name;?></h4>
									</a>

								</div>
								<div id="collapse<?php echo $achivement->achivement_id;?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="<?php echo $i;?>">
									<div class="panel-body">

										<?php if(!empty($achivement->achivement_picture)):?>
										<img src="<?php echo base_url();echo $achivement->achivement_picture;?>"  alt='<?php echo $achivement->achivement_name;?>' />

										<?php endif;?><?php echo $achivement->achivement_description;?>

										<div class="adetails_btn">
<!--											<a href="details.php?item_id=211">Details</a>-->
										</div>
									</div>
								</div>
							</div>
							<?php
								$i++;
							endforeach;

							endif;?>
						</div>

					</div>

				</div>
			</div>
			<div class="dividers"></div>
			<div class="row">
				<div class="col-md-6">
					<div class="newsupdate">
						<div class="newsupdate_title">সাম্প্রতিক খরব</div>
						<marquee behavior="scroll" direction="up" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" class="marq">
						<?php if(isset($newsActive)):
							foreach ($newsActive as $news):
							?>
						<h3><a href="<?php echo base_url()?>detail/<?php echo $news->news_id; ?>">

								<?php echo $news->news_name;?></a>

						</h3>
						<?php endforeach;endif;?>
						</marquee>

					</div>
				</div>
				<div class="col-md-6">

					<div class="notice">
						<div class="title_notice">বিজ্ঞপ্তি</div>
						<marquee behavior="scroll" direction="up" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" class="marq">
						<ul class="notice_list">
							<?php if(isset($notices)): foreach ($notices as $notice):?>
						<li><?php echo $notice->notice_name;?><br><a target='_blank' href='<?php base_url();echo $notice->notice_pdf;?>' download class='notice_btn'> <i class='fa fa-download'></i>Download</a></li>
							<?php endforeach;endif;?>
						</ul>
						</marquee>
					</div>

				</div>
			</div>


			<div class="dividers"></div>
			<div class="row">
				<div class="col-md-12">
					<div class="notice_img">
						<a target='_blank' href='http://www.tanzimulummah.org/details.php?item_id=205'><img src='<?php if(isset($headers)){echo $headers[0]->advicetiment_image;}?>' /></a>              </div>
				</div>
			</div>

		</div>

		<!--Start of Right Site-->
		<div class="col-md-3 padding_right-0">
			<div class="right_site_bg">
				<div class="title_right">ভিডিও সংগ্রহশালা</div>
				<div class="VideoGallery">
					<?php if(isset($youtube)): foreach ($youtube as $you) :?>
					<div class="videos_box item">
						<div class="videos">
							<a href="<?php echo base_url()?>video/<?php echo $you->youtube_id; ?>">
								<iframe src="<?php echo $you->youtube_video; ?>" allow="autoplay; encrypted-media" allowfullscreen="" width="250" height="200" frameborder="0"></iframe>
								<div class="videos_icon"></div></a>
						</div>
						<h4><a href="<?php echo base_url()?>video/<?php echo $you->youtube_id; ?>"><?php echo $you->youtube_name;?>
							</a></h4>
					</div>
					<?php endforeach;endif;?>


				</div>
				<div class="dividers"></div>
				<div class="dividers"></div>
				<div class="dividers"></div>

				<div class="dividers"></div>

				<div class="dividers"></div>
				<div class="title_right_doc">সামাজিক মিডিয়া</div>
				<ul class="social_media">
					<li class="facebook_color"><a target="_blank" title="Facebook" href="<?php if(isset($headers)){echo $headers[0]->front_end_setting_facebook;}?>"><i class="fa fa-facebook social"></i></a></li>
					<li class="twitter_color"><a target="_blank" title="Twitter" href="<?php if(isset($headers)){echo $headers[0]->front_end_setting_linked;}?>"><i class="fa fa-twitter social"></i></a></li>
					<li class="youtube_color"><a target="_blank" title="Youtube" href="<?php if(isset($headers)){echo $headers[0]->front_end_setting_youtube;}?>"><i class="fa fa-youtube social"></i></a></li>
					<li class="google_plus_color"><a target="_blank" title="Google Plus" href="<?php if(isset($headers)){echo $headers[0]->front_end_setting_google;}?>"><i class="fa fa-google-plus social"></i></a></li>
					<li class="linkedin_color"><a target="_blank" title="Linkedin" href="<?php if(isset($headers)){echo $headers[0]->front_end_setting_linked;}?>"><i class="fa fa-linkedin social"></i></a></li>
				</ul>


				<div class="dividers"></div>
				<div class="title_right_doc">পরিদর্শক</div>

				<ul class="social_media">
					<li>Today visitors: <?php echo $todayQueryData->today;?></li>
					<li>Last week visitors: <?php echo $lastWeekQueryData->lastWeek;?></li>
					<li>This month visitors: <?php echo $thisMonthQueryData->thisMonth;?></li>
					<li>Last month visitors: <?php echo $lastMonthQueryData->lastMonth;?></li>
					<li>Last year visitors: <?php echo $lastYearQueryData->year;?></li>
					<li>This year visitors: <?php echo $thisYearQueryData->thisyear;?></li>
					<li>Total visitors: <?php echo $totalQueryData->total;?></li>
				</ul>
			</div>


		</div><!--End of Right Site-->

	</div>
</section>


</div>
