<div style="background-color: #ffffff" class="container body_bg">

	<section class="allpage_nav clearfix" >
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<?php if($galery[0]->galery_status==1 ) { ?>
				<li><?php  echo 'বার্ষিক অনুষ্ঠান'; ?></li>
			<?php } else { ?>
			<li><?php  echo 'গ্যালারি ছবি'; ?></li>
			<?php }  ?>
		</ul>
	</section>
		<section>
			<br/>
			<br/>
			<br/>
			<div class="row">
				<?php if($galery): foreach ($galery as $gel):?>

				<div class="col-md-3">
<a href="<?php echo base_url();echo $gel->galery_image_path;?>">
	<img  width="100%"  height="250" alt="example1" src="<?php echo base_url();echo $gel->galery_image_path;?>" />

				<div class="bg-success text-white text-center"><?php echo $gel->galery_name;?></div>
</a>
				</div>
					<?php endforeach;endif;?>






			</div>
		</section>

	</div>
