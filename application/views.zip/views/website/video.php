<div class="container-fluid body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url()?>">Home</a> | </li>
			<li><a href="javascript://">Video Gallery</a> |</li>
			<li><a href="javascript://"><?php echo $youtube->youtube_name;?></a></li>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg min-height">

				<div class="row">
					<div class="col-md-9">
						<div class="video_play_gallery">
							<iframe src="<?php echo $youtube->youtube_video;?>" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" width="871" height="490" frameborder="0"></iframe>                </div>
					</div>

					<div class="col-md-3">
						<div style="height:470px;width:100%;overflow-x:auto;padding-right:2px;">

							<?php if(isset($youtubes)) : foreach ($youtubes as $youtube):?>

							<div class="video_gallery">
								<a href="<?php echo base_url()?>video/<?php echo $youtube->youtube_id; ?>">
									<iframe src="<?php echo $youtube->youtube_video; ?>" allow="autoplay; encrypted-media" allowfullscreen="" width="200" height="200" frameborder="0"></iframe>
									<div class="video_gallery_icon"></div>
								</a>
							</div>
							<?php endforeach;endif;?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

</div>
