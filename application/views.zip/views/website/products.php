

<div class="inner-banner">
	<div class="container">
		<div class="col-sm-12">
			<h2>Our Products list</h2>
		</div>
		<div class="col-sm-12 inner-breadcrumb">
			<ul>
				<li><a href="<?php echo base_url()?>">Home</a></li>
				<li>product list</li>
			</ul>
		</div>
	</div>
</div>
<section class="inner-wrapper">
	<div class="container">
		<div class="row">
		<div class="table-responsive">
			<div class="col-md-6 col-lg-12 ">

			</div>

			<?php

				foreach ($catogories as $catogory) :
					foreach ($products as $product):
static   $i=1;
					if($catogory->category_id==$product->category_id):

						?>
			<table style="margin-bottom: 1px;" class="table table-bordered">

				<caption style="text-align: center;
background-color: #e78d8d;
line-height: 66px;color:black;
border: 1px solid #000;" ><?php echo  $catogory->category_name;?></caption>

				<thead class="thead" style="background-color:#DAD175">
				<tr>
					<th></th>
					<th>পণ্য</th>
					<th>পণ্যের ছবি </th>
					<th>সক্রিয় উপাদান </th>
					<th>ক্রিয়ার দরন </th>
					<th>দমনযোগ্য বালাই ের নাম </th>
					<th>একর প্রতি</th>
					<th width="10%">১০  লিটার প্রতি </th>

				</tr>
				</thead>

				<tbody>
				<tr style="color:white:background-color:blue;background: #22a13e;color: white;border: 1px solid #ddd;"`>
					<td><?php  echo ++$i;?>	</td>
					<td>  <?php echo $product->product_name.'-'.$product->product_poriman;?>   </td>
					<td><img src="http://amana-agro.com/uploads/logo.png" width="100" height="100"></td>

					<td>   <?php echo $product->product_element;?> </td>


					<td>   <?php echo$product->product_work;?>  </td>
					<td>   <?php echo $product->product_kill;?>   </td>
					<td>   <?php echo $product->product_akor;?> </td>
					<td>   <?php echo $product->product_liter;?> </td>
				</tr>

				</tbody>

			</table>
			<?php

			endif;

			endforeach;

			endforeach;

			?>
		</div>
		</div>
		</div>
		</div>
