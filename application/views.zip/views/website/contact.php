<div class="container-fluid body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="index.php">Home</a> | </li>
			<li><a href="#">Contact Us</a></li>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg min-height">
				<div id="messegeId" class="alert alert-success alert-dismissible col-md-offset-1 col-md-10">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-check"></i> Success!</h4>
					<p id="messegeSent"></p>

				</div>
				<div class="row">
					
					<div class="col-md-6">
						<div class="headoffice_width">
							<h2>অফিসের ঠিকানা:</h2>
							<p><?php echo $headers[0]->header_two;?>
								<br>
								E-Mail:<?php echo $headers[0]->header_email;?><br>
								Mobile : <?php echo $headers[0]->header_mobile;?></p>
							<div class="contact_form">
								<h2>অধ্যক্ষ মহোদয় কে ই-মেইল করতে নিম্নের ফরমটি পুরণ করুন</h2>
								<form method="post" id="contactFrm" name="contactFrm" >
									<div class="form-group">
										<label for="FName">Name  <span style="color:red"> * </span>:</label>
										<input required type="text" class="form-control " id="firstname" name="Name"  placeholder="Enter your name...">
									</div>

									<div class="form-group">
										<label for="Phone">Phone  <span style="color:red"> * </span>:</label>
										<input required type="text" class="form-control " id="Phone" name="Phone"  placeholder="Enter your phone number...">
									</div>
									<div class="form-group">
										<label for="email">Email address <span style="color:red"> * </span>:</label>
										<input required type="email" class="form-control " id="email" name="email"  placeholder="Enter your email address...">
									</div>
									<div class="form-group">
										<label for="Subject">Subject <span style="color:red"> * </span>: </label>
										<input required type="text" class="form-control " id="Subject" name="Subject"  placeholder="Enter your name...">
									</div>
									<div class="form-group">
										<label for="Message">Message <span style="color:red"> * </span>: </label>
										<textarea  required class="form-control " rows="7 id="Message" name="Message"  placeholder="Enter your message..."></textarea>
									</div>


									<input type="button"  id="submit" value="Send Message" class="btn btn-success pull-right">
								</form>

							</div>
						</div>
					</div>


					<div class="col-md-6">
						<div class="googlemap_width">

							<iframe width="100%"  height="100%" src="<?php echo $headers[0]->header_location;?>" allowfullscreen=""></iframe>
						</div>
					</div>

				</div>


				</div>

			</div>
		</div>
	</section>

</div>

