
<footer style="background-color: #367fa9;">

	<div class="container" style="color: white">
		<div class="col-md-3"><img style="width: 156px;"  src="<?php echo base_url();echo $headers[0]->logo; ?>" alt="World Education"></div>
		<div style="color: white" class="col-md-5">
			<div class="contactus">
				<h2 style="color: white">যোগাযোগ</h2>

				<ul style="list-style: none" class="list-ul">
					<li><i class="fa fa-map-marker"></i> <?php echo $headers[0]->header_two;?></li>
					<li><i class="fa fa-phone"></i> +88<?php echo $headers[0]->header_mobile;?></li>
					<li><i class="fa fa-envelope"></i><a style="color: white" href="mailto:<?php echo $headers[0]->header_email;?>"> <?php echo $headers[0]->header_email;?></a></li>
				</ul>
			</div>
		</div>
		<div  style="color: white" class="col-md-4">
			<h2 style="color: white" >গুরুত্বপূর্ণ ওয়েব সাইট</h2>
			<ul class="inportagnt_link">
				<?php if(isset($links)): foreach ($links as $link):?>
					<li style="list-style: none"><a target="_blank"  style="color: white"  href="<?php echo $link->link;?>"><?php echo $link->link_title;?></a> </li>

				<?php endforeach;endif;?>
			</ul>
		</div>


	</div>
</footer>
<footer>



	<div class="footer-copyright">
		Copyright &copy; 2019 Bandaria Siddikia Kamil Madrasah. All rights reserved. || Powered by: <a href="http://isolutionsbd.com/" target="_blank">Isolutionbd.</a>

	</div>



</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url()?>assets/fontend/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url()?>assets/fontend/js/bootstrap.min.js"></script>

<script src="<?php echo base_url()?>assets/fontend/js/jquery.carouFredSel-6.0.4-packed.js?var=2"></script>
<!--Owl Carousel-->
<script src="<?php echo base_url()?>assets/fontend/js/owl.carousel.js"></script>
<!-- magnific popup -->
<script src="<?php echo base_url()?>assets/fontend/js/jquery.magnific-popup.min.js"></script>
<!-- scrollTo Top -->
<script src="<?php echo base_url()?>assets/fontend/js/jquery.scrollToTop.min.js"></script>
<script src="<?php echo base_url()?>assets/bower_components/moment/min/moment.min.js"></script>

<script src="<?php echo base_url()?>assets/bower_components/fullcalendar/dist/fullcalendar.min.js"></script>


<script src="<?php echo base_url()?>assets/fontend/js/custom.js"></script>

</body>
</html>


<script type="text/javascript">
	$(document).ready(function () {

		$("#messegeId").hide();
		$("#submit").click(function () {
			var first_name=$("#firstname").val();
			var subject=$("#Subject").val();
			var mess=$("#Message").val();
			var phone=$("#Phone").val();
			var email=$("#email").val();
			if(first_name.length ==""){
				alert("Enter Your Name");
			}
			if(subject.length ==""){
				alert("Enter Subject Name");
			}
			if(phone.length ==""){
				alert("Enter Phone Number");
			}
			if(mess.length ==""){
				alert("Enter Your Message");
			}
			var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			if(!regex.test(email)){
				alert('Invalid Email Enter valid Email ');
			}
			else {
				$.ajax({

					type: "POST",
					data: {first: first_name, phone: phone, mes: mess, email: email,subject:subject},
					url: '<?php echo base_url()?>Home/Mail',
					success: function (results) {
						$("#messegeSent").html(results);
						//$("#messegeId").show();
						$("#messegeId").show().fadeOut(5000);

					},
					error: function (results) {
						$("#messegeSent").html(results);
						$("#messegeId").hide();
						$("#messegeId").show().fadeOut(5000);
					}
				});
			}
		});

		$('.photoGallery').magnificPopup({
			delegate: 'a',
			type: 'image',
			tLoading: 'Loading image #%curr%...',
			mainClass: 'mfp-img-mobile',
			gallery: {
				enabled: true,
				navigateByImgClick: true,
				preload: [0,1]
			},
			image: {
				tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
				titleSrc: function(item) {
					return item.el.attr('title');
				}
			}
		});



	});

</script>







