<div class="container body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<li><?php if(isset($news) ) { echo $news->news_name; }?></li>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg">

				<div class="row">
					<div class="col-md-12">
						<div class="panel_box min_height clearfix">
							<h3 class="details_title"><?php if(isset($news) ) {  echo $news->news_name;} ?> </h3>

<!--							<div class="details_img_box"><img src="media/16-04-2019-2031115-_3_6.jpg" alt=""></div>-->
							<p><?php if(isset($news) ) { echo $news->news_body;}?></p>
							<p><?php if(isset($headers) ) { echo $headers[0]->welcome;}?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
