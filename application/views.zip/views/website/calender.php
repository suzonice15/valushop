<div class="container-fluid body_bg">

	<section class="allpage_nav clearfix">
		<ul class="pagenavbar">
			<li><a href="<?php echo base_url();?>">Home</a> | </li>
			<?php if(isset($pages[0]->page_anual_happy) ) { ?>
				<li><?php  echo 'শিক্ষা পঞ্জিকা'; ?></li>
			<?php } ?>
		</ul>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12 bg">

				<div class="row">
					<div class="col-md-12">
						<div class="panel_box min_height clearfix">
							<div class="container">

								<h1>শিক্ষা পঞ্জিকা</h1>

								<div class="row">



									<div id="calender"></div>


								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>

<script>

	$(document).ready(function () {

	var events = <?php echo json_encode($event) ?>;



	var date = new Date()

	var d    = date.getDate(),

		m    = date.getMonth(),

		y    = date.getFullYear()



	$("#calender").fullCalendar({

		header    : {

			left  : 'prev,next today',

			center: 'title',

			right : 'month,agendaWeek,agendaDay'

		},

		buttonText: {

			today: 'today',

			month: 'month',

			week : 'week',

			day  : 'day'

		},

		events    : events

	});
	});

</script>

